# ⊛ Cognitive Weave Kernel

**Authorial research programme and executable reference architecture for resource-rational digital cognitive objects.**

Founder and Principal Architect: **Ярослав Василенко**  
Repository status: **canonical candidate / pre-empirical**  
Version: **0.4.0**

## Mission

Cognitive Weave Kernel (CWK) is a falsifiable architecture for constructing digital cognitive objects that do not activate every component for every input. It combines sparse local–global communication, conditional expert activation, bounded hierarchical memory, explicit structural plasticity, adaptive compute budgets, and evidence-governed claims.

The project does **not** assert that these mechanisms reproduce a biological brain or constitute general intelligence. It tests a narrower thesis:

> A digital cognitive system can improve functional capability per unit of activated computation, communication, memory and adaptation by learning both representations and resource-bounded routes through a modular computational fabric.

## Canonical intellectual objects

1. **Adaptive Cognitive Fabric** — weighted graph of functional components and communication edges.
2. **Activation Budget Contract** — hard per-request limits for active experts, attention edges, memory reads, latency and energy proxies.
3. **Transit Governor** — context-conditioned router that selects computational paths and records route evidence.
4. **Expert Ecology** — shared and specialized experts with measurable specialization, redundancy and collapse.
5. **Memory Stratigraphy** — working, episodic and persistent memory with explicit write, read, eviction and provenance policies.
6. **Structural Plasticity Cycle** — prune–grow–stabilize procedure executed only at controlled adaptation boundaries.
7. **Metacognitive Budget Governor** — chooses depth, memory access and routing budget from task uncertainty and cost.
8. **World Coupling Port** — typed interface for text, vision, audio, state and action without pretending modalities are interchangeable.
9. **Evidence Spine** — immutable records binding code, data, configuration, environment, metrics and artifacts.
10. **Claim Firewall** — fail-closed release gate that blocks claims unsupported by preregistered evidence.

## Repository map

```text
CHARTER.md                    normative mission, authority and invariants
GOVERNANCE.md                 decision rights and change control
ARCHITECTURE.md               executable system decomposition
ROADMAP.md                    staged research programme
CLAIMS.md                     architecture claims bound to CWC-CLM-* evidence rows
research/                     hypotheses, source register and novelty matrix
research/EXPERIMENTAL_SUBSTRATE_NANOCHAT.md  nanochat-based falsification substrate (WP-0..WP-7)
docs/adr/                     architecture decision records
docs/BIBLIOGRAPHY_US_CN.md    primary-source evidence bibliography (CWC-BIB-USCN-001)
docs/claim_source_matrix.json machine-readable claim-to-source mapping
docs/adr/0007-*.md            value-function gate ADR (Q_transfer/Q_adapt/Q_robust/Q_agency)
experiments/cwc_lite_pareto_v1.yaml  frozen CWC-lite preregistration (routing+depth+memory+budget, no plasticity)
schemas/                      machine-verifiable research contracts (incl. value_function.schema.json, cwc_lite_protocol.schema.json)
src/cwk/                      reference implementation
src/cwk/instrumentation/      WP-1 measurement reification: FlopLedger, RoutingTrace, VRAMMeter, EnergySampler, RunMeter
benchmarks/                   falsification-oriented benchmark suite
experiments/                  preregistration templates
scripts/                      validation and reproducibility tools
tests/                        unit, invariant and smoke tests
evidence/                     generated evidence bundles
```

## Local start

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev]'
pytest
python -m cwk.cli smoke --config configs/smoke.yaml
python scripts/validate_repository.py
python scripts/check_claim_source_matrix.py
python scripts/check_value_function_report.py evidence/examples/value_function_report.valid.json
python scripts/check_cwc_lite_protocol.py experiments/cwc_lite_pareto_v1.yaml
```

## Non-negotiable research rule

A benchmark result is not a scientific claim. A claim becomes eligible for release only when the Claim Firewall validates its preregistration, frozen data identity, deterministic configuration, negative controls, uncertainty estimates, ablations, provenance and independent reproduction status.

See [CHARTER.md](CHARTER.md) and [research/FALSIFICATION_PROTOCOL.md](research/FALSIFICATION_PROTOCOL.md).
