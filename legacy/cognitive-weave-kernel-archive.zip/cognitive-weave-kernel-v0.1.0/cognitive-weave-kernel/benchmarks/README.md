# Benchmark Suite

The initial suite is intentionally causal and small:

1. **Associative Recall** — tests whether bounded memory retrieves delayed keys.
2. **Modular Composition** — tests whether experts specialize across composable subfunctions.
3. **Sparse Dependency Graph** — tests local/global communication against dense attention.
4. **Regime Shift** — tests controlled topology adaptation and forgetting.
5. **Router Stress** — tests collapse, overflow, churn and fallback.

Every benchmark must publish a dense baseline, randomized control and complete resource vector.
