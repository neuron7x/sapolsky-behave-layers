# Governance and Research Authority

## Roles

### Founder / Principal Architect

Owns the canonical thesis, architectural coherence, acceptance thresholds and release authority. May veto changes that increase conceptual ambiguity, evidence debt or irreversible coupling.

### Research Implementer

Implements preregistered mechanisms without changing hypotheses or thresholds. Must preserve baseline comparability.

### Adversarial Reviewer

Attempts to falsify the mechanism, detect leakage, identify confounds and propose stronger controls.

### Evidence Auditor

Validates provenance, data identity, metric computation, statistical procedure and claim scope. The auditor does not optimize the model under audit.

### Independent Reproducer

Executes the frozen protocol without private implementation guidance. A result is independently reproduced only after artifact hashes and deviations are recorded.

One person may perform multiple roles during exploration, but a release claim SHALL disclose role overlap and cannot be marked independently reproduced.

## Decision classes

| Class | Examples | Required record |
|---|---|---|
| Normative | objective, invariants, claim policy | Statute amendment + ADR |
| Architectural | module boundary, routing protocol | ADR + tests |
| Experimental | dataset, threshold, metric | preregistration |
| Operational | dependency, CI, packaging | issue/PR + CI evidence |
| Editorial | wording without semantic change | reviewed commit |

## Change lifecycle

```text
proposal → red-team → decision → implementation → verification → canonicalization
```

No benchmark result may directly alter a normative rule. A rule change must be justified independently of whether it improves the current headline metric.

## Versioning

- MAJOR: thesis, objective or evidence semantics change.
- MINOR: backward-compatible architectural capability.
- PATCH: defect correction without claim change.
- EXPERIMENTAL: non-canonical branch or configuration.

## Conflict rule

When performance, reproducibility and claim integrity conflict, claim integrity has priority, then reproducibility, then performance.
