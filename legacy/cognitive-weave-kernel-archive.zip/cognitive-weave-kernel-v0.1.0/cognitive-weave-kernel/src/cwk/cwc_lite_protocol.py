from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from jsonschema import Draft202012Validator

_REQUIRED_BASELINES = {
    "dense_transformer",
    "static_moe",
    "dynamic_depth",
}

_REQUIRED_COMPONENTS = {
    "shared_backbone",
    "sparse_routed_experts",
    "token_depth_budgeting",
    "paged_or_quantized_kv_policy",
    "hard_budget_controller",
}

_REQUIRED_SYSTEM_METRICS = {
    "train_flops",
    "p95_latency_ms",
    "peak_vram_gb",
    "joules_per_1k_tokens",
}

_REQUIRED_NEGATIVE_CONTROLS = {
    "random_router",
    "frozen_router",
    "hard_budget_to_soft_penalty",
}

_REQUIRED_ABLATIONS = {
    "shared_experts_removed",
    "dynamic_depth_off",
    "memory_policy_off",
}


def load_protocol(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("protocol must be a mapping")
    return payload


def validate_cwc_lite_protocol(protocol_path: Path, schema_root: Path) -> list[str]:
    """Validate the CWC-lite protocol shape and its non-negotiable research semantics."""

    errors: list[str] = []
    protocol = load_protocol(protocol_path)
    schema = load_protocol(schema_root / "cwc_lite_protocol.schema.json")
    validator = Draft202012Validator(schema)
    schema_errors = [error.message for error in sorted(validator.iter_errors(protocol), key=str)]
    if schema_errors:
        return schema_errors

    if protocol["status"] != "frozen":
        errors.append("CWC-lite protocol must be frozen before confirmatory execution")
    if protocol["phase"] != "cwc_lite":
        errors.append("this validator only accepts phase=cwc_lite")

    candidate = protocol["candidate"]
    if candidate["topology_plasticity_enabled"]:
        errors.append("CWC-lite must disable topology_plasticity_enabled; plasticity is phase two")

    components = set(candidate["components"])
    missing_components = sorted(_REQUIRED_COMPONENTS - components)
    if missing_components:
        errors.append(f"candidate is missing required CWC-lite components: {missing_components}")

    baselines = set(protocol["baselines"])
    missing_baselines = sorted(_REQUIRED_BASELINES - baselines)
    if missing_baselines:
        errors.append(f"protocol is missing compute-equivalent baselines: {missing_baselines}")

    budgets = protocol["budgets"]
    if budgets["hard_constraints"] is not True:
        errors.append("budgets.hard_constraints must be true; soft penalties cannot prove CWC")

    system_metrics = set(protocol["metrics"]["systems"])
    missing_system_metrics = sorted(_REQUIRED_SYSTEM_METRICS - system_metrics)
    if missing_system_metrics:
        errors.append(f"protocol is missing required system metrics: {missing_system_metrics}")

    negative_controls = set(protocol["negative_controls"])
    missing_controls = sorted(_REQUIRED_NEGATIVE_CONTROLS - negative_controls)
    if missing_controls:
        errors.append(f"protocol is missing required negative controls: {missing_controls}")

    ablations = set(protocol["ablations"])
    missing_ablations = sorted(_REQUIRED_ABLATIONS - ablations)
    if missing_ablations:
        errors.append(f"protocol is missing required ablations: {missing_ablations}")

    stats = protocol["statistics"]
    if "bootstrap" not in stats["primary_test"]:
        errors.append("statistics.primary_test must use a bootstrap procedure")
    if "hypervolume" not in stats["pareto_summary"]:
        errors.append("statistics.pareto_summary must include hypervolume")

    claim_rule = protocol["claim_rule"].lower()
    for required_phrase in ("non-worse", "95", "strictly better", "hypervolume"):
        if required_phrase not in claim_rule:
            errors.append(f"claim_rule is missing required phrase: {required_phrase}")

    if len(protocol["seeds"]) < 5:
        errors.append("final CWC-lite protocol requires at least 5 seeds")

    return errors
