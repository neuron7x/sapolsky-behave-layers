from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class ObjectiveWeights:
    task: float = 1.0
    wiring: float = 0.01
    active: float = 0.01
    route_instability: float = 0.01
    redundancy: float = 0.0


@dataclass
class ObjectiveBreakdown:
    total: torch.Tensor
    task: torch.Tensor
    wiring: torch.Tensor
    active: torch.Tensor
    route_instability: torch.Tensor


def joint_objective(
    task_loss: torch.Tensor,
    *,
    normalized_wiring_cost: float,
    active_fraction: float,
    route_entropy: torch.Tensor,
    weights: ObjectiveWeights | None = None,
) -> ObjectiveBreakdown:
    w = weights or ObjectiveWeights()
    wiring = task_loss.new_tensor(normalized_wiring_cost)
    active = task_loss.new_tensor(active_fraction)
    max_entropy = task_loss.new_tensor(1.0)
    route_instability = (max_entropy - route_entropy.mean()).abs()
    total = (
        w.task * task_loss
        + w.wiring * wiring
        + w.active * active
        + w.route_instability * route_instability
    )
    return ObjectiveBreakdown(total, task_loss, wiring, active, route_instability)
