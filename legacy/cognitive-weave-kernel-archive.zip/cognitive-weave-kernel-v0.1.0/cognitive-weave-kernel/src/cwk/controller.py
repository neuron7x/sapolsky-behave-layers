from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from .types import ActivationBudget, ActiveGraphState, RouteDecision


@dataclass(frozen=True)
class ControllerTelemetry:
    active_token_fraction: float
    depth_fraction: float
    memory_read_fraction: float
    budget_violation: bool

    def to_dict(self) -> dict[str, float | bool]:
        return {
            "active_token_fraction": self.active_token_fraction,
            "depth_fraction": self.depth_fraction,
            "memory_read_fraction": self.memory_read_fraction,
            "budget_violation": self.budget_violation,
        }


class AdaptiveController(nn.Module):
    """Learned policy for token activity, compute depth and memory-read gates."""

    def __init__(self, d_model: int, max_depth: int) -> None:
        super().__init__()
        if max_depth < 1:
            raise ValueError("max_depth must be positive")
        self.max_depth = max_depth
        self.trunk = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
            nn.GELU(),
        )
        self.gate_head = nn.Linear(d_model, 3)
        self.role_head = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.GELU(),
            nn.Linear(d_model, d_model),
        )

    def forward(
        self,
        x: torch.Tensor,
        route: RouteDecision,
        budget: ActivationBudget,
        *,
        mode: str = "learned",
    ) -> tuple[ActiveGraphState, ControllerTelemetry]:
        features = self.trunk(x)
        logits = self.gate_head(features)
        role_code = self.role_head(features)
        token_scores = logits[..., 0]
        depth_scores = logits[..., 1]
        memory_scores = logits[..., 2]
        if mode == "random":
            token_scores = torch.rand_like(token_scores)
            depth_scores = torch.rand_like(depth_scores)
            memory_scores = torch.rand_like(memory_scores)
            role_code = torch.rand_like(role_code) * 2.0 - 1.0
        elif mode == "inverted":
            token_scores = -token_scores
            depth_scores = -depth_scores
            memory_scores = -memory_scores
            role_code = -role_code
        elif mode == "static":
            static_scores = -torch.arange(
                token_scores.numel(),
                dtype=token_scores.dtype,
                device=token_scores.device,
            ).reshape_as(token_scores)
            token_scores = static_scores
            depth_scores = static_scores
            memory_scores = static_scores
            role_code = torch.zeros_like(role_code)
        elif mode != "learned":
            raise ValueError(f"unsupported controller mode: {mode}")

        active_token_gate, active_token_mask = self._budgeted_straight_through_gate(
            token_scores,
            budget.max_active_tokens,
        )
        depth_gate, depth_mask = self._budgeted_straight_through_gate(
            depth_scores,
            budget.max_active_tokens,
        )
        memory_read_gate, memory_read_mask = self._budgeted_straight_through_gate(
            memory_scores,
            budget.max_memory_reads,
        )
        if budget.max_depth < self.max_depth:
            depth_limit = depth_scores >= torch.quantile(depth_scores.detach(), 0.5)
            depth_mask = depth_mask & depth_limit
            depth_limit_gate = depth_limit.to(depth_gate.dtype)
            depth_gate = depth_gate * depth_limit_gate

        telemetry = ControllerTelemetry(
            active_token_fraction=float(active_token_mask.float().mean().detach().cpu().item()),
            depth_fraction=float(depth_mask.float().mean().detach().cpu().item()),
            memory_read_fraction=float(memory_read_mask.float().mean().detach().cpu().item()),
            budget_violation=False,
        )
        graph = ActiveGraphState(
            expert_indices=route.indices,
            expert_weights=route.weights,
            depth_mask=depth_mask,
            memory_read_mask=memory_read_mask,
            active_token_mask=active_token_mask,
            depth_gate=depth_gate,
            memory_read_gate=memory_read_gate,
            active_token_gate=active_token_gate,
            controller_logits=logits,
            role_logits=torch.stack((token_scores, depth_scores, memory_scores), dim=-1),
            role_code=role_code,
            policy=mode,
        )
        return graph, telemetry

    @staticmethod
    def _budgeted_straight_through_gate(
        scores: torch.Tensor,
        budget: int | None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        probs = torch.sigmoid(scores)
        flat = scores.reshape(-1)
        if budget is None or budget >= flat.numel():
            hard_mask = torch.ones_like(scores, dtype=torch.bool)
        elif budget <= 0:
            hard_mask = torch.zeros_like(scores, dtype=torch.bool)
        else:
            threshold = torch.topk(flat, k=budget).values.min()
            hard_mask = scores >= threshold
        hard = hard_mask.to(scores.dtype)
        gate = hard + probs - probs.detach()
        return gate, hard_mask
