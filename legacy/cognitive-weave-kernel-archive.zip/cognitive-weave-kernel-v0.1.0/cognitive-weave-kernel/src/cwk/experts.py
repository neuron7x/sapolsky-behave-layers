from __future__ import annotations

import torch
from torch import nn

from .types import RouteDecision


class FeedForwardExpert(nn.Module):
    def __init__(self, d_model: int, hidden_dim: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_model, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, d_model),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        output: torch.Tensor = self.net(x)
        return output


class ExpertEcology(nn.Module):
    def __init__(
        self,
        d_model: int,
        hidden_dim: int,
        num_experts: int,
        role_dim: int | None = None,
    ) -> None:
        super().__init__()
        role_dim = role_dim or d_model
        self.shared = FeedForwardExpert(d_model, hidden_dim)
        self.routed = nn.ModuleList(
            [FeedForwardExpert(d_model, hidden_dim) for _ in range(num_experts)]
        )
        self.shared_scale = nn.Parameter(torch.tensor(1.0))
        self.role_modulator = nn.Sequential(
            nn.LayerNorm(role_dim),
            nn.Linear(role_dim, max(8, d_model // 2)),
            nn.GELU(),
            nn.Linear(max(8, d_model // 2), 2 * d_model),
        )

    def forward(
        self,
        x: torch.Tensor,
        route: RouteDecision,
        role_code: torch.Tensor | None = None,
    ) -> torch.Tensor:
        expert_input = self._role_conditioned_input(x, role_code)
        shared_output: torch.Tensor = self.shared(expert_input) * self.shared_scale
        routed_output = torch.zeros_like(x)
        for slot in range(route.indices.shape[-1]):
            slot_indices = route.indices[..., slot]
            slot_weights = route.weights[..., slot].unsqueeze(-1)
            slot_output = torch.zeros_like(x)
            for expert_id, expert in enumerate(self.routed):
                mask = slot_indices == expert_id
                if mask.any():
                    slot_output[mask] = expert(expert_input[mask])
            routed_output = routed_output + slot_weights * slot_output
        return x + shared_output + routed_output

    def _role_conditioned_input(
        self,
        x: torch.Tensor,
        role_code: torch.Tensor | None,
    ) -> torch.Tensor:
        if role_code is None:
            return x
        gamma, beta = self.role_modulator(role_code).chunk(2, dim=-1)
        scale = 1.0 + 0.1 * torch.tanh(gamma)
        shift = 0.1 * torch.tanh(beta)
        return x * scale + shift
