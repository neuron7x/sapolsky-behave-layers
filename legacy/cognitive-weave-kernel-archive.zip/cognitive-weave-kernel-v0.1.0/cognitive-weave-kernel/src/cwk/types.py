from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class ActivationBudget:
    max_active_experts: int
    max_attention_density: float
    max_memory_reads: int
    max_memory_writes: int
    max_depth: int = 1
    max_active_tokens: int | None = None

    def validate(self) -> None:
        if self.max_active_experts < 1:
            raise ValueError("max_active_experts must be positive")
        if not 0.0 < self.max_attention_density <= 1.0:
            raise ValueError("max_attention_density must be in (0, 1]")
        if self.max_memory_reads < 0 or self.max_memory_writes < 0:
            raise ValueError("memory budgets cannot be negative")
        if self.max_depth < 1:
            raise ValueError("max_depth must be positive")
        if self.max_active_tokens is not None and self.max_active_tokens < 1:
            raise ValueError("max_active_tokens must be positive when set")


@dataclass
class RouteDecision:
    indices: torch.Tensor
    weights: torch.Tensor
    entropy: torch.Tensor
    utilization: torch.Tensor
    overflow_count: int
    fallback_used: bool


@dataclass
class ActiveGraphState:
    expert_indices: torch.Tensor
    expert_weights: torch.Tensor
    depth_mask: torch.Tensor
    memory_read_mask: torch.Tensor
    active_token_mask: torch.Tensor
    depth_gate: torch.Tensor
    memory_read_gate: torch.Tensor
    active_token_gate: torch.Tensor
    controller_logits: torch.Tensor
    role_logits: torch.Tensor
    role_code: torch.Tensor
    policy: str


@dataclass
class SlowStructuralState:
    topology_version: int
    plasticity_enabled: bool
    churn: float
