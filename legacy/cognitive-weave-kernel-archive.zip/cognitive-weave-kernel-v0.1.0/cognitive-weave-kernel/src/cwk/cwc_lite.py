from __future__ import annotations

import copy
import random
from dataclasses import dataclass
from typing import Any

import torch
import torch.nn.functional as F

from .core import CognitiveWeaveKernel
from .objective import ObjectiveWeights, joint_objective
from .semiotics import semantic_route_metrics, semiotic_salience_weights
from .types import ActivationBudget


@dataclass(frozen=True)
class CwcLiteConfig:
    vocab_size: int = 64
    d_model: int = 32
    num_heads: int = 4
    num_experts: int = 4
    top_k: int = 2
    hidden_dim: int = 64
    local_window: int = 3
    global_tokens: int = 1
    memory_capacity: int = 64
    memory_top_k: int = 2
    batch_size: int = 4
    sequence_length: int = 12
    train_steps: int = 12
    eval_batches: int = 4
    learning_rate: float = 1e-3
    seed: int = 19
    active_token_cap_fraction: float = 0.75
    semantic_alignment_weight: float = 0.05


@dataclass(frozen=True)
class CwcLiteResult:
    mode: str
    train_loss_final: float
    eval_loss: float
    active_token_fraction: float
    depth_fraction: float
    memory_read_fraction: float
    route_entropy: float
    semantic_salience_lift: float
    high_salience_coverage: float
    task_tokens: int

    def to_dict(self) -> dict[str, float | int | str]:
        return {
            "mode": self.mode,
            "train_loss_final": self.train_loss_final,
            "eval_loss": self.eval_loss,
            "active_token_fraction": self.active_token_fraction,
            "depth_fraction": self.depth_fraction,
            "memory_read_fraction": self.memory_read_fraction,
            "route_entropy": self.route_entropy,
            "semantic_salience_lift": self.semantic_salience_lift,
            "high_salience_coverage": self.high_salience_coverage,
            "task_tokens": self.task_tokens,
        }


def run_cwc_lite_comparison(config: CwcLiteConfig | None = None) -> dict[str, Any]:
    cfg = config or CwcLiteConfig()
    _set_seed(cfg.seed)
    base_model = _build_model(cfg)
    modes = ("dense", "learned", "random", "static", "inverted")
    results: list[CwcLiteResult] = []
    for mode in modes:
        model = copy.deepcopy(base_model)
        results.append(_train_and_eval(model, cfg, mode=mode))
    learned = next(item for item in results if item.mode == "learned")
    dense = next(item for item in results if item.mode == "dense")
    random_control = next(item for item in results if item.mode == "random")
    static_control = next(item for item in results if item.mode == "static")
    return {
        "schema_version": "cwk.cwc_lite_comparison.v1",
        "config": cfg.__dict__,
        "results": [item.to_dict() for item in results],
        "deltas": {
            "learned_minus_dense_eval_loss": learned.eval_loss - dense.eval_loss,
            "learned_minus_random_eval_loss": learned.eval_loss - random_control.eval_loss,
            "learned_minus_static_eval_loss": learned.eval_loss - static_control.eval_loss,
            "learned_active_token_reduction_vs_dense": (
                dense.active_token_fraction - learned.active_token_fraction
            ),
            "learned_minus_random_semantic_salience_lift": (
                learned.semantic_salience_lift - random_control.semantic_salience_lift
            ),
            "learned_minus_static_semantic_salience_lift": (
                learned.semantic_salience_lift - static_control.semantic_salience_lift
            ),
        },
        "interpretation": "training_smoke_not_pareto_claim",
    }


def _train_and_eval(
    model: CognitiveWeaveKernel,
    cfg: CwcLiteConfig,
    *,
    mode: str,
) -> CwcLiteResult:
    budget = _budget_for_mode(cfg, mode)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.learning_rate)
    final_loss = 0.0
    for step in range(cfg.train_steps):
        tokens, targets = _task_batch(cfg, step=step)
        optimizer.zero_grad(set_to_none=True)
        output = model(
            tokens,
            budget,
            controller_mode="learned" if mode == "dense" else mode,
            read_memory=True,
            write_memory=step == 0,
        )
        per_token_loss = F.cross_entropy(
            output.logits.reshape(-1, cfg.vocab_size),
            targets.reshape(-1),
            reduction="none",
        ).reshape_as(targets)
        task_weights = semiotic_salience_weights(tokens)
        task_loss = (per_token_loss * task_weights).sum() / task_weights.sum()
        active_fraction = (
            1.0 if mode == "dense" else float(output.telemetry["controller_active_token_fraction"])
        )
        objective = joint_objective(
            task_loss,
            normalized_wiring_cost=float(output.telemetry["attention_density"]),
            active_fraction=active_fraction,
            route_entropy=output.route.entropy,
            weights=ObjectiveWeights(task=1.0, wiring=0.01, active=0.05, route_instability=0.01),
        )
        differentiable_resource = (
            output.graph.active_token_gate.mean()
            + 0.5 * output.graph.depth_gate.mean()
            + 0.25 * output.graph.memory_read_gate.mean()
        )
        semantic_alignment = _semantic_alignment_loss(tokens, output.graph.active_token_gate)
        total = (
            objective.total
            + 0.0 * differentiable_resource
            + cfg.semantic_alignment_weight * semantic_alignment
        )
        total.backward()
        optimizer.step()
        model.router.update_load_bias(output.route.utilization)
        final_loss = float(total.detach().item())
    return _evaluate(model, cfg, mode=mode, budget=budget, final_loss=final_loss)


def _evaluate(
    model: CognitiveWeaveKernel,
    cfg: CwcLiteConfig,
    *,
    mode: str,
    budget: ActivationBudget,
    final_loss: float,
) -> CwcLiteResult:
    model.eval()
    losses: list[float] = []
    active: list[float] = []
    depth: list[float] = []
    memory: list[float] = []
    entropy: list[float] = []
    salience_lift: list[float] = []
    high_salience_coverage: list[float] = []
    with torch.no_grad():
        for offset in range(cfg.eval_batches):
            tokens, targets = _task_batch(cfg, step=10_000 + offset)
            output = model(
                tokens,
                budget,
                controller_mode="learned" if mode == "dense" else mode,
                read_memory=True,
            )
            per_token_loss = F.cross_entropy(
                output.logits.reshape(-1, cfg.vocab_size),
                targets.reshape(-1),
                reduction="none",
            ).reshape_as(targets)
            task_weights = semiotic_salience_weights(tokens)
            losses.append(
                float(
                    ((per_token_loss * task_weights).sum() / task_weights.sum()).item()
                )
            )
            active.append(
                1.0
                if mode == "dense"
                else float(output.telemetry["controller_active_token_fraction"])
            )
            depth.append(
                1.0
                if mode == "dense"
                else float(output.telemetry["controller_depth_fraction"])
            )
            memory.append(float(output.telemetry["controller_memory_read_fraction"]))
            entropy.append(float(output.telemetry["route_entropy_mean"]))
            semantic_metrics = semantic_route_metrics(tokens, output.graph.active_token_mask)
            salience_lift.append(semantic_metrics.salience_lift)
            high_salience_coverage.append(semantic_metrics.high_salience_coverage)
    model.train()
    return CwcLiteResult(
        mode=mode,
        train_loss_final=final_loss,
        eval_loss=sum(losses) / len(losses),
        active_token_fraction=sum(active) / len(active),
        depth_fraction=sum(depth) / len(depth),
        memory_read_fraction=sum(memory) / len(memory),
        route_entropy=sum(entropy) / len(entropy),
        semantic_salience_lift=sum(salience_lift) / len(salience_lift),
        high_salience_coverage=sum(high_salience_coverage) / len(high_salience_coverage),
        task_tokens=cfg.eval_batches * cfg.batch_size * cfg.sequence_length,
    )


def _build_model(cfg: CwcLiteConfig) -> CognitiveWeaveKernel:
    return CognitiveWeaveKernel(
        vocab_size=cfg.vocab_size,
        d_model=cfg.d_model,
        num_heads=cfg.num_heads,
        num_experts=cfg.num_experts,
        top_k=cfg.top_k,
        hidden_dim=cfg.hidden_dim,
        local_window=cfg.local_window,
        global_tokens=cfg.global_tokens,
        memory_capacity=cfg.memory_capacity,
        memory_top_k=cfg.memory_top_k,
    )


def _budget_for_mode(cfg: CwcLiteConfig, mode: str) -> ActivationBudget:
    if mode == "dense":
        return ActivationBudget(
            max_active_experts=cfg.top_k,
            max_attention_density=0.60,
            max_memory_reads=cfg.memory_top_k,
            max_memory_writes=16,
            max_depth=2,
            max_active_tokens=None,
        )
    return ActivationBudget(
        max_active_experts=cfg.top_k,
        max_attention_density=0.60,
        max_memory_reads=cfg.memory_top_k,
        max_memory_writes=16,
        max_depth=1,
        max_active_tokens=max(
            1,
            int(cfg.batch_size * cfg.sequence_length * cfg.active_token_cap_fraction),
        ),
    )


def _task_batch(cfg: CwcLiteConfig, *, step: int) -> tuple[torch.Tensor, torch.Tensor]:
    base = torch.arange(cfg.batch_size * cfg.sequence_length, dtype=torch.long).reshape(
        cfg.batch_size,
        cfg.sequence_length,
    )
    tokens = (base * ((step % 5) + 1) + step * 7) % cfg.vocab_size
    if step % 2 == 0:
        tokens = torch.flip(tokens, dims=(1,))
    targets = (tokens + torch.roll(tokens, shifts=1, dims=1) + step) % cfg.vocab_size
    return tokens, targets


def _semantic_alignment_loss(tokens: torch.Tensor, active_gate: torch.Tensor) -> torch.Tensor:
    salience = semiotic_salience_weights(tokens).to(active_gate.device)
    centered_salience = salience - salience.mean()
    scale = centered_salience.abs().mean().clamp_min(1e-6)
    normalized_salience = centered_salience / scale
    centered_gate = active_gate - active_gate.mean()
    return -(centered_gate * normalized_salience).mean()


def _set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(1)
