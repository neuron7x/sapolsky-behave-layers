from __future__ import annotations

import copy
import random
from dataclasses import dataclass
from typing import Any

import torch
import torch.nn.functional as F

from .core import CognitiveWeaveKernel
from .cwc_lite import (
    CwcLiteConfig,
    _budget_for_mode,
    _build_model,
    _semantic_alignment_loss,
    _task_batch,
)
from .objective import ObjectiveWeights, joint_objective
from .semiotics import (
    semantic_fields,
    semantic_route_metrics,
    semiotic_salience_weights,
    semiotic_types,
    sense_counts,
)


@dataclass(frozen=True)
class DcsaAuditConfig:
    train_steps: int = 64
    seed: int = 19
    active_token_cap_fraction: float = 0.75
    semantic_alignment_weight: float = 0.05
    eval_step: int = 10_000
    rsi_epsilon: float = 0.05


def run_dcsa_audit(config: DcsaAuditConfig | None = None) -> dict[str, Any]:
    cfg = config or DcsaAuditConfig()
    lite_cfg = CwcLiteConfig(
        train_steps=cfg.train_steps,
        seed=cfg.seed,
        active_token_cap_fraction=cfg.active_token_cap_fraction,
        semantic_alignment_weight=cfg.semantic_alignment_weight,
    )
    _set_seed(cfg.seed)
    base = _build_model(lite_cfg)
    learned = _train_model(copy.deepcopy(base), lite_cfg, mode="learned")
    random_control = _train_model(copy.deepcopy(base), lite_cfg, mode="random")
    static_control = _train_model(copy.deepcopy(base), lite_cfg, mode="static")

    tokens, targets = _task_batch(lite_cfg, step=cfg.eval_step)
    budget = _budget_for_mode(lite_cfg, "learned")
    learned_out = learned(tokens, budget, controller_mode="learned", read_memory=True)
    random_out = random_control(tokens, budget, controller_mode="random", read_memory=True)
    static_out = static_control(tokens, budget, controller_mode="static", read_memory=True)

    sample_size = int(tokens.numel())
    seed_count = 1
    evidence_gate = _evidence_gate(cfg, lite_cfg)
    semiotic = _semiotic_landscape(tokens, learned_out.graph.active_token_mask, seed_count)
    geometry = _geometry_audit(learned_out.logits, sample_size, seed_count)
    grounding = _grounding_stability(learned, lite_cfg, tokens, budget, cfg.rsi_epsilon)
    controls = _controls(
        tokens=tokens,
        targets=targets,
        learned_output=learned_out,
        random_output=random_out,
        static_output=static_out,
        lite_cfg=lite_cfg,
    )
    adversarial = _adversarial_disruption(learned, tokens, budget)
    claim_matrix = _claim_matrix(evidence_gate, semiotic, geometry, grounding, controls)
    executive = _executive_verdict(claim_matrix, controls, grounding)
    report = {
        "schema_version": "cwk.dcsa_audit.v2",
        "target_architecture": "CWC-lite learned resource-constrained semantic router",
        "evidence_gate": evidence_gate,
        "executive_verdict": executive,
        "claim_evidence_matrix": claim_matrix,
        "semiotic_landscape": semiotic,
        "geometric_representation": geometry,
        "semasiological_grounding": grounding,
        "compute_equivalent_controls": controls,
        "adversarial_disruption": adversarial,
        "markdown_report": render_dcsa_markdown(
            evidence_gate=evidence_gate,
            executive=executive,
            claim_matrix=claim_matrix,
            semiotic=semiotic,
            geometry=geometry,
            grounding=grounding,
            controls=controls,
            adversarial=adversarial,
        ),
    }
    return report


def render_dcsa_markdown(
    *,
    evidence_gate: dict[str, Any],
    executive: dict[str, Any],
    claim_matrix: list[dict[str, str]],
    semiotic: dict[str, Any],
    geometry: dict[str, Any],
    grounding: dict[str, Any],
    controls: dict[str, Any],
    adversarial: dict[str, Any],
) -> str:
    routing_entropy = semiotic["syntactic_entropy_bits"]
    rows = [
        "| Claim | Required evidence | Available evidence | Status | Reason |",
        "|---|---|---|---|---|",
    ]
    for item in claim_matrix:
        rows.append(
            "| {claim} | {required} | {available} | {status} | {reason} |".format(**item)
        )
    routing_entropy_text = _metric_text(
        routing_entropy,
        "bits",
        semiotic["sample_size"],
        semiotic["seed_count"],
        "observed semantic-field entropy",
        "VERIFIED",
    )
    effective_rank_text = _metric_text(
        geometry["effective_rank_proxy"],
        "rank",
        geometry["sample_size"],
        geometry["seed_count"],
        "logit covariance eigenspectrum",
        "ESTIMATED",
    )
    invariance_text = _metric_text(
        grounding["rsi"],
        "cosine",
        grounding["sample_size"],
        grounding["seed_count"],
        "semantic projection RSI",
        "VERIFIED",
    )
    action_relevance_text = _metric_text(
        controls["learned_minus_static_loss"],
        "loss delta",
        controls["sample_size"],
        controls["seed_count"],
        "paired weighted CE on static control",
        "VERIFIED",
    )
    adversarial_text = _metric_text(
        adversarial["max_kl_divergence"],
        "KL",
        adversarial["sample_size"],
        adversarial["seed_count"],
        "brute-force L0=1 scan",
        "VERIFIED",
    )
    lines = [
        "# COGNITIVE-SEMANTIC ARCHITECTURE AUDIT",
        "",
        "## 0. EXECUTIVE VERDICT",
        f"- Audit status: {executive['audit_status']}",
        f"- Maximum supported claim level: {executive['maximum_supported_claim_level']}",
        f"- Strongest verified result: {executive['strongest_verified_result']}",
        f"- Critical blocker: {executive['critical_blocker']}",
        f"- Next falsifying experiment: {executive['next_falsifying_experiment']}",
        "",
        "## 1. SYSTEM AND EVIDENCE METADATA",
        "- Target architecture: CWC-lite learned resource-constrained semantic router",
        f"- Commit/checkpoint: {evidence_gate['commit']}",
        "- Dataset: synthetic CWC-lite token task",
        f"- Hardware: {evidence_gate['hardware']}",
        f"- Seeds: {evidence_gate['seeds']}",
        f"- Available evidence: {', '.join(evidence_gate['available'])}",
        f"- Missing evidence: {', '.join(evidence_gate['missing'])}",
        f"- Reproducibility status: {evidence_gate['reproducibility_status']}",
        "",
        "## 2. CLAIM-EVIDENCE MATRIX",
        *rows,
        "",
        "## 3. COMPUTATIONAL GRAPH AND ROUTING",
        "- Active graph: embedding -> local/global attention -> budgeted router -> "
        "adaptive controller -> memory gate -> expert ecology -> output head",
        f"- Routing entropy: {routing_entropy_text}",
        "- Utilization: expert utilization trace available only as per-run router telemetry; "
        "cross-seed routing stability not measured",
        "- Collapse indicators: "
        f"absorbing states={semiotic['absorbing_state_count']}; "
        f"degenerate pathways={semiotic['degenerate_pathway_count']}",
        "- Controller FLOPs: NOT_TESTED; analytical controller ledger not attached to this audit",
        "- Controller latency: NOT_TESTED; instrumentation trace not attached to this audit",
        "- Status: ESTIMATED for graph structure; VERIFIED for observed routing masks",
        "",
        "## 4. REPRESENTATION GEOMETRY",
        "- Methods actually applicable: effective-rank proxy over logits only",
        f"- Effective rank: {effective_rank_text}",
        "- CKA/RSA: NOT_TESTED; layer activations were not persisted",
        "- Local dimension: NOT_TESTED; insufficient activation neighborhood traces",
        "- Fisher approximation: NOT_TESTED; gradients were not captured",
        "- Unsupported geometric claims: Riemann curvature tensor = INVALID_REQUEST; "
        "no metric tensor/manifold validation/synthetic estimator control",
        "- Status: ESTIMATED for effective-rank proxy; INVALID for full curvature/FIM claims",
        "",
        "## 5. SEMANTIC INVARIANCE AND GROUNDING",
        "- T_same: synthetic same-signature token substitution",
        "- T_change: NOT_TESTED; no separate causal meaning-changing transform set",
        f"- Invariance: {invariance_text}",
        "- Sensitivity: NOT_TESTED",
        f"- Action relevance: {action_relevance_text}",
        "- Grounding score: NOT_TESTED; missing sensitivity and external action outcome",
        "- Commutativity test: ESTIMATED; paired synthetic T_same only, no uncertainty",
        "- Status: SUPPORTED for invariance proxy; NOT_TESTED for full grounding",
        "",
        "## 6. ADVERSARIAL AND CAUSAL FAILURES",
        "- Perturbation set: single-token same-signature replacement",
        "- Oracle: programmatic synthetic semantic signature",
        f"- Worst-case degradation: {adversarial_text}",
        "- Random-control degradation: NOT_TESTED",
        f"- Failure coordinate: {adversarial['coordinate']}",
        "- Alternative explanation: lexical index sensitivity, not necessarily semantic collapse",
        "- Status: VERIFIED for bounded synthetic disruption; NOT_TESTED for causal failure",
        "",
        "## 7. COMPUTE-EQUIVALENT BASELINES",
        "| Model | Quality | FLOPs | VRAM | p95 latency | Energy | Transfer | Adaptation |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
        f"| learned | {controls['learned_loss']:.6f} | NOT_MEASURED | NOT_MEASURED | "
        "NOT_MEASURED | NOT_MEASURED | synthetic | trained router |",
        f"| random | {controls['random_loss']:.6f} | NOT_MEASURED | NOT_MEASURED | "
        "NOT_MEASURED | NOT_MEASURED | synthetic | random router |",
        f"| static | {controls['static_loss']:.6f} | NOT_MEASURED | NOT_MEASURED | "
        "NOT_MEASURED | NOT_MEASURED | synthetic | fixed-prefix router |",
        "",
        "- Compute parity: INVALID for full claim; active-token parity only was verified",
        "- Statistical method: single-seed paired evaluation; no confidence interval",
        "- Confidence intervals: NOT_TESTED",
        "- Pareto verdict: PARETO_NOT_SUPPORTED",
        "",
        "## 8. FALSIFICATION OUTCOME",
        "- Hypotheses rejected: dense/Pareto/general-grounding claims for this evidence bundle",
        "- Hypotheses surviving: learned routing can improve synthetic semantic salience routing",
        "- Untested hypotheses: T_change sensitivity, memory contribution, depth adaptation, "
        "S_t plasticity, energy/latency efficiency, external workload transfer",
        "- Confounds: synthetic oracle, single seed, no activation trace, no hardware telemetry",
        "- Required negative controls: removed controller, frozen learned controller, "
        "semantic-label shuffle, T_change set, memory on/off, depth fixed/adaptive",
        "",
        "## 9. FINAL CLAIM BOUNDARY",
        "### Supported",
        "- The reference audit executes and reports bounded synthetic routing evidence.",
        "- Learned routing improved semantic salience lift over random/static controls "
        "in this run.",
        "",
        "### Not supported",
        "- Full semantic grounding.",
        "- Pareto dominance.",
        "- Energy efficiency.",
        "- Riemannian manifold or Fisher-metric claims.",
        "",
        "### Prohibited wording",
        "- grounded intelligence",
        "- functorial semantic proof",
        "- compute-equivalent Pareto win",
        "- causal semantic architecture",
        "",
        "## 10. NEXT DECISIVE EXPERIMENT",
        "- Intervention: run 5-seed CWC-lite with T_same and T_change transform sets.",
        "- Controls: dense, random, static, frozen-router, removed-controller.",
        "- Budget: equal active-token cap plus measured FLOPs/VRAM/latency.",
        "- Primary metrics: weighted CE, semantic lift, invariance, sensitivity, p95 latency.",
        "- Failure criterion: learned does not beat random/frozen on semantic lift and loss.",
        "- Success criterion: learned beats all controls with paired 95% CI and resource parity.",
    ]
    return "\n".join(lines)


def _train_model(
    model: CognitiveWeaveKernel,
    cfg: CwcLiteConfig,
    *,
    mode: str,
) -> CognitiveWeaveKernel:
    budget = _budget_for_mode(cfg, mode)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.learning_rate)
    for step in range(cfg.train_steps):
        tokens, targets = _task_batch(cfg, step=step)
        optimizer.zero_grad(set_to_none=True)
        output = model(
            tokens,
            budget,
            controller_mode=mode,
            read_memory=True,
            write_memory=step == 0,
        )
        per_token_loss = F.cross_entropy(
            output.logits.reshape(-1, cfg.vocab_size),
            targets.reshape(-1),
            reduction="none",
        ).reshape_as(targets)
        weights = semiotic_salience_weights(tokens)
        task_loss = (per_token_loss * weights).sum() / weights.sum()
        objective = joint_objective(
            task_loss,
            normalized_wiring_cost=float(output.telemetry["attention_density"]),
            active_fraction=float(output.telemetry["controller_active_token_fraction"]),
            route_entropy=output.route.entropy,
            weights=ObjectiveWeights(task=1.0, wiring=0.01, active=0.05, route_instability=0.01),
        )
        alignment = _semantic_alignment_loss(tokens, output.graph.active_token_gate)
        total = objective.total + cfg.semantic_alignment_weight * alignment
        total.backward()
        optimizer.step()
        model.router.update_load_bias(output.route.utilization)
    return model.eval()


def _evidence_gate(cfg: DcsaAuditConfig, lite_cfg: CwcLiteConfig) -> dict[str, Any]:
    return {
        "available": [
            "source_code",
            "synthetic_dataset_generator",
            "model_config",
            "single_seed_execution_trace",
            "random_router_control",
            "static_router_control",
        ],
        "missing": [
            "git_commit_or_checkpoint_hash",
            "dependency_lock_attestation",
            "hardware_telemetry",
            "activation_traces",
            "gradient_traces",
            "physical_energy_measurement",
            "multi_seed_confidence_intervals",
            "external_dataset",
        ],
        "derivable": [
            "syntactic_entropy_from_tokens",
            "transition_matrix_from_semantic_fields",
            "active_token_parity",
            "synthetic_same_signature_invariance",
        ],
        "not_derivable": [
            "full_representation_geometry",
            "empirical_fisher",
            "riemann_curvature_tensor",
            "energy_efficiency",
            "pareto_dominance",
            "general_semantic_grounding",
        ],
        "commit": "NOT_AVAILABLE",
        "checkpoint": "ephemeral_training_run",
        "hardware": "NOT_RECORDED",
        "seeds": [cfg.seed],
        "precision": "torch_default_float32",
        "execution_command": "python -m cwk.cli dcsa-audit",
        "reproducibility_status": "ESTIMATED",
        "environment_match": "NOT_TESTED",
        "artifact_integrity": "NOT_TESTED",
        "claimable_run": False,
        "blocking_reasons": [
            "single seed",
            "no FLOP/VRAM/latency/energy trace attached",
            "synthetic-only semantic oracle",
        ],
        "config": lite_cfg.__dict__,
    }


def _executive_verdict(
    claim_matrix: list[dict[str, str]],
    controls: dict[str, float],
    grounding: dict[str, Any],
) -> dict[str, str]:
    supported = [item for item in claim_matrix if item["status"] in {"VERIFIED", "SUPPORTED"}]
    strongest = "no scientific hypothesis verified"
    if supported:
        strongest = "learned routing has bounded synthetic semantic-routing evidence"
    blocker = "missing multi-seed compute-equivalent baselines with measured resource telemetry"
    if controls["learned_minus_random_loss"] > 0:
        blocker = "learned router does not beat random on task loss in this seed"
    return {
        "audit_status": "EXECUTABLE_BUT_NOT_CLAIMABLE",
        "maximum_supported_claim_level": "LEVEL 1 - EXECUTABLE CONTRACT",
        "strongest_verified_result": strongest,
        "critical_blocker": blocker,
        "next_falsifying_experiment": (
            "5-seed paired T_same/T_change run against random, static, frozen and removed controls"
        ),
        "grounding_status": (
            "SUPPORTED_INVARIANCE_PROXY"
            if grounding["functorial_commutativity_pass"]
            else "INVARIANCE_PROXY_FAILED"
        ),
    }


def _claim_matrix(
    evidence_gate: dict[str, Any],
    semiotic: dict[str, Any],
    geometry: dict[str, Any],
    grounding: dict[str, Any],
    controls: dict[str, float],
) -> list[dict[str, str]]:
    del evidence_gate, semiotic, geometry
    return [
        {
            "claim": "Reference implementation executes",
            "required": "source code, command, tests",
            "available": "source code plus pytest coverage",
            "status": "VERIFIED",
            "reason": "audit and tests executed locally",
        },
        {
            "claim": "Learned router improves semantic routing over random/static",
            "required": "paired controls under equal active-token cap",
            "available": "single-seed random/static controls",
            "status": (
                "SUPPORTED"
                if controls["learned_minus_random_semantic_lift"] > 0
                and controls["learned_minus_static_semantic_lift"] > 0
                else "INVALID"
            ),
            "reason": "semantic lift deltas are positive, but uncertainty is not estimated",
        },
        {
            "claim": "Learned router improves task quality over random/static",
            "required": "paired controls and confidence intervals",
            "available": "single-seed weighted cross-entropy",
            "status": (
                "SUPPORTED"
                if controls["learned_minus_random_loss"] < 0
                and controls["learned_minus_static_loss"] < 0
                else "INVALID"
            ),
            "reason": "single-seed result must beat both controls to support the claim",
        },
        {
            "claim": "Semantic grounding",
            "required": "invariance, sensitivity and action relevance",
            "available": "T_same invariance proxy and synthetic action relevance only",
            "status": "NOT_TESTED",
            "reason": "T_change sensitivity and external outcome are missing",
        },
        {
            "claim": "Representation manifold curvature",
            "required": "metric tensor, manifold validation, local samples, uncertainty",
            "available": "logits only",
            "status": "INVALID",
            "reason": "Riemann curvature is not identifiable from this evidence",
        },
        {
            "claim": "Empirical Fisher information",
            "required": "per-sample gradients",
            "available": "no gradients captured",
            "status": "NOT_TESTED",
            "reason": "Fisher approximation cannot be computed from logits alone",
        },
        {
            "claim": "Compute-equivalent Pareto superiority",
            "required": "FLOPs, VRAM, latency, energy, 5 seeds, confidence intervals",
            "available": "active-token parity only",
            "status": "NOT_TESTED",
            "reason": "resource telemetry and statistical protocol are missing",
        },
    ]


def _metric_text(
    value: float,
    unit: str,
    sample_size: int,
    seed_count: int,
    method: str,
    status: str,
) -> str:
    return (
        f"value={value:.6f}; unit={unit}; sample_size={sample_size}; "
        f"seed_count={seed_count}; uncertainty=NOT_ESTIMATED; "
        f"measurement_method={method}; status={status}"
    )


def _semiotic_landscape(
    tokens: torch.Tensor,
    active_mask: torch.Tensor,
    seed_count: int,
) -> dict[str, Any]:
    fields = semantic_fields(tokens)
    entropy = _entropy_bits(fields)
    transition = _transition_matrix(fields, num_states=8)
    nonzero = (transition > 0).to(torch.float32)
    density = float(nonzero.mean().item())
    row_sums = transition.sum(dim=1)
    absorbing_mask = (torch.diag(transition) > 0) & (row_sums == torch.diag(transition))
    absorbing = int(absorbing_mask.sum().item())
    degenerate = int((row_sums == 0).sum().item())
    semantic_route = semantic_route_metrics(tokens, active_mask).to_dict()
    return {
        "syntactic_entropy_bits": entropy,
        "transition_density": density,
        "absorbing_state_count": absorbing,
        "degenerate_pathway_count": degenerate,
        "transition_matrix": transition.tolist(),
        "semantic_route": semantic_route,
        "sample_size": int(tokens.numel()),
        "seed_count": seed_count,
        "uncertainty": "NOT_ESTIMATED",
        "status": "VERIFIED",
    }


def _geometry_audit(logits: torch.Tensor, sample_size: int, seed_count: int) -> dict[str, Any]:
    flat = logits.reshape(-1, logits.shape[-1])
    centered = flat - flat.mean(dim=0, keepdim=True)
    cov = centered.T @ centered / max(1, flat.shape[0] - 1)
    eigvals = torch.linalg.eigvalsh(cov).clamp_min(0)
    total = eigvals.sum().clamp_min(1e-8)
    probs = eigvals / total
    effective_rank = torch.exp(-(probs * torch.log(probs.clamp_min(1e-8))).sum())
    trajectory = logits.mean(dim=0)
    if trajectory.shape[0] >= 3:
        second_diff = trajectory[2:] - 2 * trajectory[1:-1] + trajectory[:-2]
        curvature = second_diff.norm(dim=-1).mean()
    else:
        curvature = logits.new_tensor(0.0)
    pred = torch.softmax(logits, dim=-1)
    del pred
    return {
        "effective_rank_proxy": float(effective_rank.detach().cpu().item()),
        "trajectory_turning_proxy": float(curvature.detach().cpu().item()),
        "riemann_curvature": "INVALID_REQUEST",
        "fisher_information": "NOT_TESTED",
        "sample_size": sample_size,
        "seed_count": seed_count,
        "uncertainty": "NOT_ESTIMATED",
        "status": "ESTIMATED",
    }


def _grounding_stability(
    model: CognitiveWeaveKernel,
    cfg: CwcLiteConfig,
    tokens: torch.Tensor,
    budget: Any,
    epsilon: float,
) -> dict[str, Any]:
    perturbed = _semantic_equivalent_tokens(tokens, cfg.vocab_size)
    with torch.no_grad():
        original = model(tokens, budget, controller_mode="learned", read_memory=True)
        shifted = model(perturbed, budget, controller_mode="learned", read_memory=True)
    original_sem = _semantic_projection(original.logits)
    shifted_sem = _semantic_projection(shifted.logits)
    rsi = F.cosine_similarity(original_sem.reshape(1, -1), shifted_sem.reshape(1, -1)).item()
    entropy = _entropy_bits(semantic_fields(tokens))
    route = semantic_route_metrics(tokens, original.graph.active_token_mask)
    grounding_ratio = max(0.0, min(1.0, route.salience_lift / max(entropy, 1e-6)))
    return {
        "rsi": float(rsi),
        "epsilon": epsilon,
        "representation_drift": float(1.0 - rsi),
        "functorial_commutativity_pass": bool(rsi >= 1.0 - epsilon),
        "grounding_ratio_proxy": grounding_ratio,
        "semantic_equivalent_changed_fraction": float((perturbed != tokens).float().mean().item()),
        "sample_size": int(tokens.numel()),
        "seed_count": 1,
        "uncertainty": "NOT_ESTIMATED",
        "status": "SUPPORTED" if rsi >= 1.0 - epsilon else "INVALID",
    }


def _controls(
    *,
    tokens: torch.Tensor,
    targets: torch.Tensor,
    learned_output: Any,
    random_output: Any,
    static_output: Any,
    lite_cfg: CwcLiteConfig,
) -> dict[str, float]:
    learned_loss = _weighted_loss(learned_output.logits, targets, tokens, lite_cfg.vocab_size)
    random_loss = _weighted_loss(random_output.logits, targets, tokens, lite_cfg.vocab_size)
    static_loss = _weighted_loss(static_output.logits, targets, tokens, lite_cfg.vocab_size)
    learned_route = semantic_route_metrics(tokens, learned_output.graph.active_token_mask)
    random_route = semantic_route_metrics(tokens, random_output.graph.active_token_mask)
    static_route = semantic_route_metrics(tokens, static_output.graph.active_token_mask)
    return {
        "learned_loss": learned_loss,
        "random_loss": random_loss,
        "static_loss": static_loss,
        "learned_active_fraction": float(
            learned_output.graph.active_token_mask.float().mean().item()
        ),
        "random_active_fraction": float(
            random_output.graph.active_token_mask.float().mean().item()
        ),
        "static_active_fraction": float(
            static_output.graph.active_token_mask.float().mean().item()
        ),
        "learned_minus_random_loss": learned_loss - random_loss,
        "learned_minus_static_loss": learned_loss - static_loss,
        "learned_minus_random_semantic_lift": (
            learned_route.salience_lift - random_route.salience_lift
        ),
        "learned_minus_static_semantic_lift": (
            learned_route.salience_lift - static_route.salience_lift
        ),
        "sample_size": int(tokens.numel()),
        "seed_count": 1,
        "uncertainty": "NOT_ESTIMATED",
        "status": "VERIFIED",
    }


def _adversarial_disruption(
    model: CognitiveWeaveKernel,
    tokens: torch.Tensor,
    budget: Any,
) -> dict[str, Any]:
    with torch.no_grad():
        base = model(tokens, budget, controller_mode="learned", read_memory=True)
        base_p = torch.softmax(base.logits, dim=-1)
    vocab_size = base.logits.shape[-1]
    best = {
        "max_kl_divergence": -1.0,
        "coordinate": [0, 0],
        "replacement_token": int(tokens[0, 0].item()),
        "semantic_invariant_preserved": False,
    }
    for i in range(tokens.shape[0]):
        for j in range(tokens.shape[1]):
            candidate = tokens.clone()
            replacement = _semantic_equivalent_token(int(tokens[i, j].item()), vocab_size)
            if replacement == int(tokens[i, j].item()):
                replacement = (int(tokens[i, j].item()) + 1) % vocab_size
            candidate[i, j] = replacement
            with torch.no_grad():
                shifted = model(candidate, budget, controller_mode="learned", read_memory=True)
                shifted_logp = torch.log_softmax(shifted.logits, dim=-1)
                kl = F.kl_div(shifted_logp, base_p, reduction="batchmean", log_target=False).item()
            if kl > best["max_kl_divergence"]:
                best = {
                    "max_kl_divergence": float(kl),
                    "coordinate": [int(i), int(j)],
                    "replacement_token": int(replacement),
                    "semantic_invariant_preserved": bool(
                        _same_semantic_signature(int(tokens[i, j].item()), int(replacement))
                    ),
                }
    best["sample_size"] = int(tokens.numel())
    best["seed_count"] = 1
    best["uncertainty"] = "NOT_ESTIMATED"
    best["status"] = "VERIFIED"
    return best


def _weighted_loss(
    logits: torch.Tensor,
    targets: torch.Tensor,
    tokens: torch.Tensor,
    vocab_size: int,
) -> float:
    per_token = F.cross_entropy(
        logits.reshape(-1, vocab_size),
        targets.reshape(-1),
        reduction="none",
    ).reshape_as(targets)
    weights = semiotic_salience_weights(tokens)
    return float(((per_token * weights).sum() / weights.sum()).item())


def _semantic_projection(logits: torch.Tensor) -> torch.Tensor:
    probs = torch.softmax(logits, dim=-1)
    vocab = torch.arange(logits.shape[-1], device=logits.device)
    field_basis = F.one_hot(vocab.remainder(8), num_classes=8).to(probs.dtype)
    type_basis = F.one_hot(vocab.remainder(3), num_classes=3).to(probs.dtype)
    return torch.cat((probs @ field_basis, probs @ type_basis), dim=-1).mean(dim=(0, 1))


def _semantic_equivalent_tokens(tokens: torch.Tensor, vocab_size: int) -> torch.Tensor:
    perturbed = tokens.clone()
    for idx in range(tokens.numel()):
        value = int(tokens.reshape(-1)[idx].item())
        perturbed.reshape(-1)[idx] = _semantic_equivalent_token(value, vocab_size)
    return perturbed


def _semantic_equivalent_token(token: int, vocab_size: int) -> int:
    for candidate in range(vocab_size):
        if candidate != token and _same_semantic_signature(token, candidate):
            return candidate
    return token


def _same_semantic_signature(a: int, b: int) -> bool:
    at = torch.tensor([a])
    bt = torch.tensor([b])
    return bool(
        semantic_fields(at).item() == semantic_fields(bt).item()
        and sense_counts(at).item() == sense_counts(bt).item()
        and semiotic_types(at).item() == semiotic_types(bt).item()
    )


def _transition_matrix(states: torch.Tensor, *, num_states: int) -> torch.Tensor:
    matrix = torch.zeros((num_states, num_states), dtype=torch.float32)
    for row in states:
        for source, target in zip(row[:-1], row[1:], strict=False):
            matrix[int(source.item()), int(target.item())] += 1.0
    return matrix


def _entropy_bits(states: torch.Tensor) -> float:
    counts = torch.bincount(states.reshape(-1), minlength=int(states.max().item()) + 1).float()
    probs = counts[counts > 0] / counts.sum().clamp_min(1.0)
    return float((-(probs * torch.log2(probs))).sum().item())


def _set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(1)
