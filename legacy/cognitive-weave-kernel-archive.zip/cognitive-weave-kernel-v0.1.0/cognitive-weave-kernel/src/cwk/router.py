from __future__ import annotations

import math

import torch
from torch import nn

from .types import RouteDecision


class BudgetedRouter(nn.Module):
    """Top-K token router with observable utilization and loss-free load bias state."""

    load_bias: torch.Tensor

    def __init__(
        self, d_model: int, num_experts: int, top_k: int, temperature: float = 1.0
    ) -> None:
        super().__init__()
        if not 1 <= top_k <= num_experts:
            raise ValueError("top_k must be within [1, num_experts]")
        self.num_experts = num_experts
        self.top_k = top_k
        self.temperature = temperature
        self.projection = nn.Linear(d_model, num_experts, bias=False)
        self.register_buffer("load_bias", torch.zeros(num_experts))

    def forward(self, x: torch.Tensor, max_active_experts: int) -> RouteDecision:
        if max_active_experts < self.top_k:
            raise ValueError("activation budget is smaller than router top_k")
        logits = self.projection(x) + self.load_bias
        values, indices = torch.topk(logits, k=self.top_k, dim=-1)
        weights = torch.softmax(values / self.temperature, dim=-1)
        entropy = -(weights * weights.clamp_min(1e-12).log()).sum(dim=-1)
        flat = indices.reshape(-1)
        utilization = torch.bincount(flat, minlength=self.num_experts).to(x.dtype)
        utilization = utilization / utilization.sum().clamp_min(1.0)
        return RouteDecision(
            indices=indices,
            weights=weights,
            entropy=entropy,
            utilization=utilization,
            overflow_count=0,
            fallback_used=False,
        )

    @torch.no_grad()
    def update_load_bias(self, utilization: torch.Tensor, step_size: float = 0.01) -> None:
        if utilization.shape != self.load_bias.shape:
            raise ValueError("utilization shape mismatch")
        target = torch.full_like(utilization, 1.0 / self.num_experts)
        self.load_bias.add_(step_size * (target - utilization))
        self.load_bias.sub_(self.load_bias.mean())
        self.load_bias.clamp_(-math.log(self.num_experts), math.log(self.num_experts))
