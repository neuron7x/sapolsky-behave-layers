from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F
from torch import nn


@dataclass
class MemoryRead:
    values: torch.Tensor
    scores: torch.Tensor
    indices: torch.Tensor
    reads: int


class EpisodicMemory(nn.Module):
    """Bounded session memory with explicit writes and cosine retrieval."""

    keys: torch.Tensor
    values: torch.Tensor

    def __init__(self, d_model: int, capacity: int, top_k: int) -> None:
        super().__init__()
        if capacity < 1 or top_k < 1:
            raise ValueError("capacity and top_k must be positive")
        self.capacity = capacity
        self.top_k = top_k
        self.register_buffer("keys", torch.empty(0, d_model), persistent=False)
        self.register_buffer("values", torch.empty(0, d_model), persistent=False)

    @property
    def size(self) -> int:
        return int(self.keys.shape[0])

    @torch.no_grad()
    def clear(self) -> None:
        self.keys = self.keys[:0]
        self.values = self.values[:0]

    @torch.no_grad()
    def write(self, keys: torch.Tensor, values: torch.Tensor, max_writes: int) -> int:
        if keys.shape != values.shape or keys.ndim != 2:
            raise ValueError("keys and values must be matching rank-2 tensors")
        count = min(max_writes, keys.shape[0])
        if count == 0:
            return 0
        new_keys = keys[:count].detach()
        new_values = values[:count].detach()
        self.keys = torch.cat((self.keys.to(new_keys.device), new_keys), dim=0)[-self.capacity :]
        self.values = torch.cat((self.values.to(new_values.device), new_values), dim=0)[
            -self.capacity :
        ]
        return count

    def read(self, queries: torch.Tensor, max_reads: int) -> MemoryRead:
        if self.size == 0 or max_reads == 0:
            shape = (*queries.shape[:-1], 0)
            empty_values = queries.new_zeros((*queries.shape[:-1], queries.shape[-1]))
            return MemoryRead(
                values=empty_values,
                scores=queries.new_zeros(shape),
                indices=torch.empty(shape, dtype=torch.long, device=queries.device),
                reads=0,
            )
        k = min(self.top_k, max_reads, self.size)
        normalized_queries = F.normalize(queries, dim=-1)
        normalized_keys = F.normalize(self.keys.to(queries.device), dim=-1)
        similarity = torch.matmul(normalized_queries, normalized_keys.transpose(-1, -2))
        scores, indices = torch.topk(similarity, k=k, dim=-1)
        selected = self.values.to(queries.device)[indices]
        weights = torch.softmax(scores, dim=-1).unsqueeze(-1)
        aggregated = (weights * selected).sum(dim=-2)
        return MemoryRead(aggregated, scores, indices, k)
