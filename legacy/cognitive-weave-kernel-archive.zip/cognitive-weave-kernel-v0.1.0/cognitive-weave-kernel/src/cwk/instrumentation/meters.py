from __future__ import annotations

import json
import statistics
import subprocess
import threading
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import torch

from .trace import FlopLedger, InferenceLatencyBreakdown, RoutingTrace


def _percentile(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    if len(values) == 1:
        return values[0]
    ordered = sorted(values)
    index = (len(ordered) - 1) * q
    lower = int(index)
    upper = min(lower + 1, len(ordered) - 1)
    weight = index - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


@dataclass
class VRAMMeter:
    device: str | torch.device = "cuda"

    @property
    def available(self) -> bool:
        return torch.cuda.is_available()

    def reset_peak(self) -> None:
        if self.available:
            torch.cuda.reset_peak_memory_stats(self.device)

    def snapshot(self) -> dict[str, int | bool]:
        if not self.available:
            return {
                "available": False,
                "allocated_bytes": 0,
                "reserved_bytes": 0,
                "peak_allocated_bytes": 0,
                "peak_reserved_bytes": 0,
            }
        return {
            "available": True,
            "allocated_bytes": int(torch.cuda.memory_allocated(self.device)),
            "reserved_bytes": int(torch.cuda.memory_reserved(self.device)),
            "peak_allocated_bytes": int(torch.cuda.max_memory_allocated(self.device)),
            "peak_reserved_bytes": int(torch.cuda.max_memory_reserved(self.device)),
        }


@dataclass
class EnergySampler:
    """GPU power sampler with total-energy fallback via power integration."""

    device_index: int = 0
    interval_s: float = 0.1
    _samples: list[tuple[float, float]] = field(default_factory=list, init=False)
    _stop: threading.Event = field(default_factory=threading.Event, init=False)
    _thread: threading.Thread | None = field(default=None, init=False)

    def start(self) -> None:
        self._samples.clear()
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> dict[str, Any]:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=max(1.0, self.interval_s * 4))
        joules = self._integrated_joules()
        return {
            "available": bool(self._samples),
            "method": "nvidia_smi_power_integration" if self._samples else "unavailable",
            "sample_count": len(self._samples),
            "duration_s": (
                self._samples[-1][0] - self._samples[0][0] if len(self._samples) >= 2 else 0.0
            ),
            "joules": joules,
            "average_watts": (
                joules / (self._samples[-1][0] - self._samples[0][0])
                if len(self._samples) >= 2 and self._samples[-1][0] > self._samples[0][0]
                else 0.0
            ),
        }

    def _run(self) -> None:
        while not self._stop.is_set():
            watts = self._read_power_watts()
            now = time.perf_counter()
            if watts is not None:
                self._samples.append((now, watts))
            self._stop.wait(self.interval_s)

    def _read_power_watts(self) -> float | None:
        try:
            completed = subprocess.run(
                [
                    "nvidia-smi",
                    f"--id={self.device_index}",
                    "--query-gpu=power.draw",
                    "--format=csv,noheader,nounits",
                ],
                check=True,
                text=True,
                capture_output=True,
                timeout=1.0,
            )
        except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
            return None
        text = completed.stdout.strip().splitlines()
        if not text:
            return None
        try:
            return float(text[0])
        except ValueError:
            return None

    def _integrated_joules(self) -> float:
        if len(self._samples) < 2:
            return 0.0
        total = 0.0
        for (t0, w0), (t1, w1) in zip(self._samples, self._samples[1:], strict=False):
            total += 0.5 * (w0 + w1) * max(0.0, t1 - t0)
        return total


@dataclass
class RunMeter:
    """Request/run-level instrumentation with explicit warm-up and synchronized GPU timing."""

    warmup_steps: int = 2
    device: str | torch.device = "cuda"
    jsonl_path: Path | None = None
    latency_end_to_end_ms: list[float] = field(default_factory=list)
    latency_gpu_kernel_ms: list[float] = field(default_factory=list)
    inference_breakdowns: list[InferenceLatencyBreakdown] = field(default_factory=list)
    records: list[dict[str, Any]] = field(default_factory=list)

    @property
    def cuda_available(self) -> bool:
        return torch.cuda.is_available()

    def benchmark(
        self,
        fn: Callable[[], Any],
        *,
        steps: int,
        routing_trace: RoutingTrace | None = None,
        flop_ledger: FlopLedger | None = None,
        use_energy_sampler: bool = False,
    ) -> dict[str, Any]:
        if steps < 1:
            raise ValueError("steps must be positive")
        for _ in range(max(0, self.warmup_steps)):
            fn()
        self._synchronize()

        vram = VRAMMeter(self.device)
        vram.reset_peak()
        energy = EnergySampler() if use_energy_sampler else None
        if energy is not None:
            energy.start()

        for step in range(steps):
            self.measure_step(fn, step=step)

        self._synchronize()
        energy_report = energy.stop() if energy is not None else {"available": False}
        summary = self.summary(
            routing_trace=routing_trace,
            flop_ledger=flop_ledger,
            vram=vram.snapshot(),
            energy=energy_report,
        )
        self.write_jsonl(summary)
        return summary

    def record_inference_breakdown(self, breakdown: InferenceLatencyBreakdown) -> None:
        self.inference_breakdowns.append(breakdown)
        self.records.append({"type": "inference_breakdown", **breakdown.to_dict()})

    def measure_step(self, fn: Callable[[], Any], *, step: int) -> Any:
        self._synchronize()
        start_wall = time.perf_counter()
        start_event = end_event = None
        if self.cuda_available:
            start_event = torch.cuda.Event(enable_timing=True)  # type: ignore[no-untyped-call]
            end_event = torch.cuda.Event(enable_timing=True)  # type: ignore[no-untyped-call]
            start_event.record()
        result = fn()
        if end_event is not None:
            end_event.record()
        self._synchronize()
        end_wall = time.perf_counter()
        end_to_end_ms = (end_wall - start_wall) * 1000.0
        gpu_ms = float(start_event.elapsed_time(end_event)) if start_event and end_event else 0.0
        self.latency_end_to_end_ms.append(end_to_end_ms)
        self.latency_gpu_kernel_ms.append(gpu_ms)
        self.records.append(
            {
                "type": "step",
                "step": step,
                "latency_end_to_end_ms": end_to_end_ms,
                "latency_gpu_kernel_ms": gpu_ms,
            }
        )
        return result

    @contextmanager
    def section(self, name: str) -> Iterator[None]:
        self._synchronize()
        start = time.perf_counter()
        try:
            yield
        finally:
            self._synchronize()
            self.records.append(
                {
                    "type": "section",
                    "name": name,
                    "latency_end_to_end_ms": (time.perf_counter() - start) * 1000.0,
                }
            )

    def summary(
        self,
        *,
        routing_trace: RoutingTrace | None = None,
        flop_ledger: FlopLedger | None = None,
        vram: dict[str, Any] | None = None,
        energy: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return {
            "schema_version": "cwk.instrumentation.v1",
            "latency": {
                "end_to_end_ms": self._latency_stats(self.latency_end_to_end_ms),
                "gpu_kernel_ms": self._latency_stats(self.latency_gpu_kernel_ms),
                "inference": self._inference_latency_stats(),
            },
            "flops": (flop_ledger or FlopLedger()).to_dict(),
            "routing": (routing_trace or RoutingTrace()).to_dict(),
            "vram": vram or VRAMMeter(self.device).snapshot(),
            "energy": energy or {"available": False},
            "records": list(self.records),
        }

    def write_jsonl(self, summary: dict[str, Any]) -> None:
        if self.jsonl_path is None:
            return
        self.jsonl_path.parent.mkdir(parents=True, exist_ok=True)
        with self.jsonl_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(summary, sort_keys=True) + "\n")

    @staticmethod
    def overhead_report(
        *,
        off_seconds: float,
        on_seconds: float,
        max_overhead_fraction: float = 0.02,
    ) -> dict[str, float | bool]:
        if off_seconds <= 0.0:
            raise ValueError("off_seconds must be positive")
        overhead = (on_seconds - off_seconds) / off_seconds
        return {
            "off_seconds": off_seconds,
            "on_seconds": on_seconds,
            "overhead_fraction": overhead,
            "max_overhead_fraction": max_overhead_fraction,
            "pass": overhead <= max_overhead_fraction,
        }

    def _latency_stats(self, values: list[float]) -> dict[str, float]:
        if not values:
            return {"count": 0, "mean": 0.0, "p50": 0.0, "p95": 0.0, "p99": 0.0}
        return {
            "count": len(values),
            "mean": statistics.fmean(values),
            "p50": _percentile(values, 0.50),
            "p95": _percentile(values, 0.95),
            "p99": _percentile(values, 0.99),
        }

    def _inference_latency_stats(self) -> dict[str, Any]:
        return {
            "count": len(self.inference_breakdowns),
            "ttft_ms": self._latency_stats([item.ttft_ms for item in self.inference_breakdowns]),
            "tpot_ms": self._latency_stats([item.tpot_ms for item in self.inference_breakdowns]),
            "ttlt_ms": self._latency_stats([item.ttlt_ms for item in self.inference_breakdowns]),
        }

    def _synchronize(self) -> None:
        if self.cuda_available:
            torch.cuda.synchronize(self.device)
