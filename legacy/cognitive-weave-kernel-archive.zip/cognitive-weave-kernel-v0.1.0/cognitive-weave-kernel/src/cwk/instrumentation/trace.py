from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class InferenceLatencyBreakdown:
    ttft_ms: float
    tpot_ms: float
    ttlt_ms: float
    prompt_tokens: int
    output_tokens: int

    @classmethod
    def from_token_timestamps(
        cls,
        *,
        request_start_s: float,
        first_token_s: float,
        token_times_s: list[float],
        request_end_s: float,
        prompt_tokens: int,
        output_tokens: int,
    ) -> InferenceLatencyBreakdown:
        if prompt_tokens < 0 or output_tokens < 1:
            raise ValueError("prompt_tokens must be non-negative and output_tokens positive")
        if first_token_s < request_start_s or request_end_s < first_token_s:
            raise ValueError("timestamps must be monotonic")
        if token_times_s != sorted(token_times_s):
            raise ValueError("token_times_s must be sorted")
        if len(token_times_s) >= 2:
            intervals = [
                1000.0 * (b - a) for a, b in zip(token_times_s, token_times_s[1:], strict=False)
            ]
            tpot_ms = sum(intervals) / len(intervals)
        else:
            tpot_ms = 0.0
        return cls(
            ttft_ms=1000.0 * (first_token_s - request_start_s),
            tpot_ms=tpot_ms,
            ttlt_ms=1000.0 * (request_end_s - request_start_s),
            prompt_tokens=prompt_tokens,
            output_tokens=output_tokens,
        )

    def to_dict(self) -> dict[str, float | int]:
        return {
            "ttft_ms": self.ttft_ms,
            "tpot_ms": self.tpot_ms,
            "ttlt_ms": self.ttlt_ms,
            "prompt_tokens": self.prompt_tokens,
            "output_tokens": self.output_tokens,
        }


@dataclass(frozen=True)
class RoutingEvent:
    name: str
    active_tokens: int
    total_tokens: int
    active_experts: int
    total_experts: int
    depth: int = 1
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "active_tokens": self.active_tokens,
            "total_tokens": self.total_tokens,
            "active_experts": self.active_experts,
            "total_experts": self.total_experts,
            "depth": self.depth,
            "active_token_fraction": self.active_tokens / max(self.total_tokens, 1),
            "active_expert_fraction": self.active_experts / max(self.total_experts, 1),
            "metadata": dict(self.metadata),
        }


@dataclass
class RoutingTrace:
    """Analytical route record used for FLOP accounting and budget gates."""

    events: list[RoutingEvent] = field(default_factory=list)

    def record(
        self,
        name: str,
        *,
        active_tokens: int,
        total_tokens: int,
        active_experts: int,
        total_experts: int,
        depth: int = 1,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        if active_tokens < 0 or total_tokens < 1 or active_tokens > total_tokens:
            raise ValueError("active_tokens must be within [0, total_tokens]")
        if active_experts < 0 or total_experts < 1 or active_experts > total_experts:
            raise ValueError("active_experts must be within [0, total_experts]")
        if depth < 1:
            raise ValueError("depth must be positive")
        self.events.append(
            RoutingEvent(
                name=name,
                active_tokens=active_tokens,
                total_tokens=total_tokens,
                active_experts=active_experts,
                total_experts=total_experts,
                depth=depth,
                metadata=dict(metadata or {}),
            )
        )

    @property
    def active_token_fraction_mean(self) -> float:
        if not self.events:
            return 0.0
        active_fraction_sum = sum(
            event.active_tokens / event.total_tokens for event in self.events
        )
        return active_fraction_sum / len(self.events)

    @property
    def active_expert_fraction_mean(self) -> float:
        if not self.events:
            return 0.0
        return sum(event.active_experts / event.total_experts for event in self.events) / len(
            self.events
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_count": len(self.events),
            "active_token_fraction_mean": self.active_token_fraction_mean,
            "active_expert_fraction_mean": self.active_expert_fraction_mean,
            "events": [event.to_dict() for event in self.events],
        }


@dataclass(frozen=True)
class FlopEntry:
    name: str
    kind: str
    flops: int
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind,
            "flops": self.flops,
            "metadata": dict(self.metadata),
        }


@dataclass
class FlopLedger:
    """Analytical FLOP ledger; profiler measurements are calibration evidence only."""

    entries: list[FlopEntry] = field(default_factory=list)
    memory_bytes: int = 0
    communication_bytes: int = 0

    def add(self, name: str, kind: str, flops: int, **metadata: Any) -> int:
        if flops < 0:
            raise ValueError("flops cannot be negative")
        self.entries.append(FlopEntry(name=name, kind=kind, flops=int(flops), metadata=metadata))
        return int(flops)

    def add_memory_bytes(self, name: str, bytes_moved: int, **metadata: Any) -> int:
        if bytes_moved < 0:
            raise ValueError("bytes_moved cannot be negative")
        self.memory_bytes += int(bytes_moved)
        self.add(name, "memory_bytes_marker", 0, bytes_moved=int(bytes_moved), **metadata)
        return int(bytes_moved)

    def add_communication_bytes(self, name: str, bytes_moved: int, **metadata: Any) -> int:
        if bytes_moved < 0:
            raise ValueError("bytes_moved cannot be negative")
        self.communication_bytes += int(bytes_moved)
        self.add(name, "communication_bytes_marker", 0, bytes_moved=int(bytes_moved), **metadata)
        return int(bytes_moved)

    def add_dense_linear(self, name: str, *, tokens: int, d_in: int, d_out: int) -> int:
        flops = 2 * tokens * d_in * d_out
        return self.add(name, "dense_linear", flops, tokens=tokens, d_in=d_in, d_out=d_out)

    def add_attention(
        self,
        name: str,
        *,
        tokens: int,
        d_model: int,
        density: float,
    ) -> int:
        if not 0.0 < density <= 1.0:
            raise ValueError("attention density must be in (0, 1]")
        qkv_and_output = 8 * tokens * d_model * d_model
        attention_scores_and_values = int(4 * density * tokens * tokens * d_model)
        flops = qkv_and_output + attention_scores_and_values
        return self.add(
            name,
            "attention",
            flops,
            tokens=tokens,
            d_model=d_model,
            density=density,
        )

    def add_routed_ffn(
        self,
        name: str,
        *,
        active_tokens: int,
        d_model: int,
        hidden_dim: int,
        active_experts: int = 1,
    ) -> int:
        flops = 4 * active_tokens * d_model * hidden_dim * active_experts
        return self.add(
            name,
            "routed_ffn",
            flops,
            active_tokens=active_tokens,
            d_model=d_model,
            hidden_dim=hidden_dim,
            active_experts=active_experts,
        )

    @property
    def total_flops(self) -> int:
        return sum(entry.flops for entry in self.entries)

    @property
    def operational_intensity(self) -> float:
        total_bytes = self.memory_bytes + self.communication_bytes
        if total_bytes <= 0:
            return 0.0
        return self.total_flops / total_bytes

    def roofline_report(
        self,
        *,
        peak_flops_per_s: float,
        peak_memory_bandwidth_bytes_per_s: float,
    ) -> dict[str, float | str]:
        if peak_flops_per_s <= 0.0 or peak_memory_bandwidth_bytes_per_s <= 0.0:
            raise ValueError("peak hardware rates must be positive")
        oi = self.operational_intensity
        ridge_point = peak_flops_per_s / peak_memory_bandwidth_bytes_per_s
        attainable = min(peak_flops_per_s, oi * peak_memory_bandwidth_bytes_per_s)
        if oi == 0.0:
            bound = "unclassified"
        elif oi < ridge_point:
            bound = "memory_bound"
        else:
            bound = "compute_bound"
        return {
            "operational_intensity_flops_per_byte": oi,
            "ridge_point_flops_per_byte": ridge_point,
            "attainable_flops_per_s": attainable,
            "bound": bound,
        }

    def moe_cap_report(
        self,
        *,
        measured_tokens_per_s: float,
        theoretical_tokens_per_s: float,
        measured_memory_bytes_per_s: float,
        theoretical_memory_bytes_per_s: float,
    ) -> dict[str, float]:
        for name, value in {
            "measured_tokens_per_s": measured_tokens_per_s,
            "theoretical_tokens_per_s": theoretical_tokens_per_s,
            "measured_memory_bytes_per_s": measured_memory_bytes_per_s,
            "theoretical_memory_bytes_per_s": theoretical_memory_bytes_per_s,
        }.items():
            if value < 0.0:
                raise ValueError(f"{name} cannot be negative")
        return {
            "s_mfu": (
                measured_tokens_per_s / theoretical_tokens_per_s
                if theoretical_tokens_per_s > 0.0
                else 0.0
            ),
            "s_mbu": (
                measured_memory_bytes_per_s / theoretical_memory_bytes_per_s
                if theoretical_memory_bytes_per_s > 0.0
                else 0.0
            ),
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_flops": self.total_flops,
            "memory_bytes": self.memory_bytes,
            "communication_bytes": self.communication_bytes,
            "operational_intensity_flops_per_byte": self.operational_intensity,
            "entry_count": len(self.entries),
            "entries": [entry.to_dict() for entry in self.entries],
        }
