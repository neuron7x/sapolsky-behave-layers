from __future__ import annotations

import torch
from torch import nn

from .topology import local_global_mask, topology_stats


class LocalGlobalSelfAttention(nn.Module):
    """Reference sparse topology expressed as a mask over standard attention.

    This implementation validates semantics and observability; it does not claim kernel-level
    sparse speedup because the underlying PyTorch operation may still execute dense kernels.
    """

    def __init__(self, d_model: int, num_heads: int, local_window: int, global_tokens: int) -> None:
        super().__init__()
        self.attention = nn.MultiheadAttention(d_model, num_heads, batch_first=True)
        self.local_window = local_window
        self.global_tokens = global_tokens

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, dict[str, float | str]]:
        seq_len = x.shape[1]
        allowed = local_global_mask(
            seq_len,
            self.local_window,
            self.global_tokens,
            causal=True,
            device=x.device,
        )
        blocked = ~allowed
        output, _ = self.attention(x, x, x, attn_mask=blocked, need_weights=False)
        stats = topology_stats(allowed)
        telemetry: dict[str, float | str] = {
            "attention_density": stats.density,
            "attention_wiring_cost": stats.wiring_cost,
            "topology_hash": stats.topology_hash,
        }
        return x + output, telemetry
