from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class TopologyDelta:
    removed: tuple[tuple[int, int], ...]
    added: tuple[tuple[int, int], ...]


class StructuralPlasticityController:
    """Deterministic proposal engine; committing remains an external governed action."""

    def propose(
        self,
        mask: torch.Tensor,
        utility: torch.Tensor,
        *,
        prune_fraction: float,
        grow_count: int,
    ) -> TopologyDelta:
        if mask.shape != utility.shape or mask.ndim != 2 or mask.shape[0] != mask.shape[1]:
            raise ValueError("mask and utility must be matching square matrices")
        existing = torch.nonzero(mask, as_tuple=False)
        removable = [(int(i), int(j)) for i, j in existing.tolist() if i != j]
        remove_n = min(len(removable), int(len(removable) * prune_fraction))
        removable.sort(key=lambda edge: float(utility[edge[0], edge[1]].item()))
        removed = tuple(removable[:remove_n])

        candidates = torch.nonzero(~mask, as_tuple=False).tolist()
        candidates = [(int(i), int(j)) for i, j in candidates if i != j]
        candidates.sort(key=lambda edge: (-float(utility[edge[0], edge[1]].item()), edge))
        added = tuple(candidates[:grow_count])
        return TopologyDelta(removed=removed, added=added)

    @staticmethod
    def apply(mask: torch.Tensor, delta: TopologyDelta) -> torch.Tensor:
        updated = mask.clone()
        for i, j in delta.removed:
            updated[i, j] = False
        for i, j in delta.added:
            updated[i, j] = True
        if not torch.diagonal(updated).all():
            updated.fill_diagonal_(True)
        return updated
