from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class SemanticRouteMetrics:
    salience_lift: float
    high_salience_coverage: float

    def to_dict(self) -> dict[str, float]:
        return {
            "salience_lift": self.salience_lift,
            "high_salience_coverage": self.high_salience_coverage,
        }


def semantic_fields(tokens: torch.Tensor) -> torch.Tensor:
    """Deterministic semasiological field assignment for synthetic tokens."""

    return tokens.remainder(8)


def sense_counts(tokens: torch.Tensor) -> torch.Tensor:
    """Synthetic polysemy count: higher values mean more possible signified senses."""

    return (
        1
        + (tokens.remainder(5) == 0).to(torch.long)
        + (tokens.remainder(13) == 0).to(torch.long)
    )


def semiotic_types(tokens: torch.Tensor) -> torch.Tensor:
    """Peircean sign-role proxy: 0 icon, 1 index, 2 symbol."""

    return tokens.remainder(3)


def semiotic_salience_weights(tokens: torch.Tensor) -> torch.Tensor:
    """Weight tokens by meaning ambiguity, field transition and sign role.

    This is a synthetic instrumented task signal, not a natural-language semantics
    claim. It exists to test whether learned routing tracks meaning-bearing
    structure better than random/static controls.
    """

    fields = semantic_fields(tokens)
    previous_fields = torch.roll(fields, shifts=1, dims=1)
    field_transition = (fields != previous_fields).to(torch.float32)
    polysemy = (sense_counts(tokens).to(torch.float32) - 1.0).clamp_min(0.0)
    sign_role = semiotic_types(tokens)
    index_or_symbol = (sign_role != 0).to(torch.float32)
    symbol = (sign_role == 2).to(torch.float32)
    return 1.0 + 1.25 * field_transition + 0.75 * polysemy + 0.50 * index_or_symbol + 0.50 * symbol


def semantic_route_metrics(
    tokens: torch.Tensor,
    active_token_mask: torch.Tensor,
) -> SemanticRouteMetrics:
    weights = semiotic_salience_weights(tokens).to(active_token_mask.device)
    mask = active_token_mask.to(weights.dtype)
    active_count = mask.sum().clamp_min(1.0)
    active_salience = (weights * mask).sum() / active_count
    baseline_salience = weights.mean().clamp_min(1e-6)
    high_salience = weights >= torch.quantile(weights.detach().reshape(-1), 0.75)
    high_salience_total = high_salience.to(weights.dtype).sum().clamp_min(1.0)
    high_salience_covered = (high_salience.to(weights.dtype) * mask).sum() / high_salience_total
    return SemanticRouteMetrics(
        salience_lift=float((active_salience / baseline_salience).detach().cpu().item()),
        high_salience_coverage=float(high_salience_covered.detach().cpu().item()),
    )
