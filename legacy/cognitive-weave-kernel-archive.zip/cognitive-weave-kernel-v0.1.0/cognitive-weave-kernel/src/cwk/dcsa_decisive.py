from __future__ import annotations

import copy
import random
from dataclasses import dataclass
from typing import Any

import torch
import torch.nn.functional as F

from .core import CognitiveWeaveKernel
from .cwc_lite import (
    CwcLiteConfig,
    _budget_for_mode,
    _build_model,
    _semantic_alignment_loss,
    _task_batch,
)
from .objective import ObjectiveWeights, joint_objective
from .semiotics import (
    semantic_fields,
    semantic_route_metrics,
    semiotic_salience_weights,
    semiotic_types,
)


@dataclass(frozen=True)
class DcsaDecisiveConfig:
    seeds: tuple[int, ...] = (1, 2, 3, 4, 5)
    train_steps: int = 64
    eval_batches: int = 4
    active_token_cap_fraction: float = 0.75
    semantic_alignment_weight: float = 0.05
    bootstrap_samples: int = 1000
    ci: float = 0.95
    task_variant: str = "role_conditioned"
    isolate_role_path: bool = True


def run_dcsa_decisive_experiment(config: DcsaDecisiveConfig | None = None) -> dict[str, Any]:
    cfg = config or DcsaDecisiveConfig()
    rows: list[dict[str, float | int | str]] = []
    for seed in cfg.seeds:
        rows.extend(_run_seed(cfg, seed))
    aggregate = _aggregate(rows, cfg)
    return {
        "schema_version": "cwk.dcsa_decisive.v1",
        "hypothesis": (
            "Learned role/semantic routing improves task loss, semantic salience, "
            "T_same invariance and T_change sensitivity over random, static, frozen "
            "and removed-controller controls under the same active-token cap."
        ),
        "config": {
            "seeds": list(cfg.seeds),
            "train_steps": cfg.train_steps,
            "eval_batches": cfg.eval_batches,
            "active_token_cap_fraction": cfg.active_token_cap_fraction,
            "semantic_alignment_weight": cfg.semantic_alignment_weight,
            "bootstrap_samples": cfg.bootstrap_samples,
            "ci": cfg.ci,
            "task_variant": cfg.task_variant,
            "isolate_role_path": cfg.isolate_role_path,
        },
        "available": [
            "multi_seed_synthetic_runs",
            "T_same_same_signature_substitution",
            "T_change_signature_changing_substitution",
            "dense_random_static_frozen_removed_controls",
            "paired_bootstrap_ci",
        ],
        "missing": [
            "hardware_flops_vram_latency_energy",
            "external_dataset",
            "activation_trace_geometry",
            "independent_replication",
        ],
        "rows": rows,
        "aggregate": aggregate,
        "verdict": _verdict(aggregate),
        "claim_boundary": {
            "supported_if_pass": "LEVEL 3 component causality on synthetic workload",
            "not_supported": "Pareto evidence, full grounding, hardware efficiency, generalization",
        },
    }


def _run_seed(cfg: DcsaDecisiveConfig, seed: int) -> list[dict[str, float | int | str]]:
    _set_seed(seed)
    lite_cfg = CwcLiteConfig(
        train_steps=cfg.train_steps,
        eval_batches=cfg.eval_batches,
        seed=seed,
        active_token_cap_fraction=cfg.active_token_cap_fraction,
        semantic_alignment_weight=cfg.semantic_alignment_weight,
    )
    base = _build_model(lite_cfg)
    models = {
        "learned": _train_model(
            copy.deepcopy(base),
            lite_cfg,
            mode="learned",
            task_variant=cfg.task_variant,
            isolate_role_path=cfg.isolate_role_path,
        ),
        "random": _train_model(
            copy.deepcopy(base),
            lite_cfg,
            mode="random",
            task_variant=cfg.task_variant,
            isolate_role_path=cfg.isolate_role_path,
        ),
        "static": _train_model(
            copy.deepcopy(base),
            lite_cfg,
            mode="static",
            task_variant=cfg.task_variant,
            isolate_role_path=cfg.isolate_role_path,
        ),
        "frozen": _train_model(
            copy.deepcopy(base),
            lite_cfg,
            mode="learned",
            task_variant=cfg.task_variant,
            isolate_role_path=cfg.isolate_role_path,
            freeze_controller=True,
            semantic_alignment_weight=0.0,
        ),
        "removed": _train_model(
            copy.deepcopy(base),
            lite_cfg,
            mode="static",
            task_variant=cfg.task_variant,
            isolate_role_path=cfg.isolate_role_path,
            semantic_alignment_weight=0.0,
        ),
        "dense": _train_model(
            copy.deepcopy(base),
            lite_cfg,
            mode="dense",
            task_variant=cfg.task_variant,
            isolate_role_path=cfg.isolate_role_path,
            semantic_alignment_weight=0.0,
        ),
    }
    rows: list[dict[str, float | int | str]] = []
    for batch_idx in range(cfg.eval_batches):
        tokens, targets = _task_batch_for_variant(
            lite_cfg,
            step=20_000 + seed * 100 + batch_idx,
            variant=cfg.task_variant,
        )
        for mode, model in models.items():
            budget = _budget_for_mode(lite_cfg, "dense" if mode == "dense" else "learned")
            controller_mode = _controller_mode_for_eval(mode)
            with torch.no_grad():
                output = model(tokens, budget, controller_mode=controller_mode, read_memory=True)
                same = model(
                    _same_transform(tokens, lite_cfg.vocab_size),
                    budget,
                    controller_mode=controller_mode,
                    read_memory=True,
                )
                changed = model(
                    _change_transform(tokens, lite_cfg.vocab_size),
                    budget,
                    controller_mode=controller_mode,
                    read_memory=True,
                )
            rows.append(
                _row(seed, batch_idx, mode, output, same, changed, tokens, targets, lite_cfg)
            )
    return rows


def _controller_mode_for_eval(mode: str) -> str:
    if mode in {"learned", "frozen", "dense"}:
        return "learned"
    if mode == "removed":
        return "static"
    return mode


def _task_batch_for_variant(
    cfg: CwcLiteConfig,
    *,
    step: int,
    variant: str,
) -> tuple[torch.Tensor, torch.Tensor]:
    tokens, base_targets = _task_batch(cfg, step=step)
    if variant == "base":
        return tokens, base_targets
    if variant != "role_conditioned":
        raise ValueError(f"unsupported decisive task variant: {variant}")
    previous = torch.roll(tokens, shifts=1, dims=1)
    next_token = torch.roll(tokens, shifts=-1, dims=1)
    fields = semantic_fields(tokens)
    sign_types = semiotic_types(tokens)
    salience = semiotic_salience_weights(tokens)
    high_salience = salience >= torch.quantile(salience.reshape(-1), 0.65)
    field_shift = (tokens + fields + step) % cfg.vocab_size
    relational = (tokens + previous + next_token + step) % cfg.vocab_size
    corrective = (2 * tokens - previous + cfg.vocab_size + step) % cfg.vocab_size
    targets = torch.where((sign_types == 2) & high_salience, relational, field_shift)
    targets = torch.where((sign_types == 1) & high_salience, corrective, targets)
    return tokens, targets


def _train_model(
    model: CognitiveWeaveKernel,
    cfg: CwcLiteConfig,
    *,
    mode: str,
    task_variant: str,
    isolate_role_path: bool,
    freeze_controller: bool = False,
    semantic_alignment_weight: float | None = None,
) -> CognitiveWeaveKernel:
    budget = _budget_for_mode(cfg, mode)
    if isolate_role_path:
        _freeze_base_path(model)
    if freeze_controller:
        for param in model.controller.parameters():
            param.requires_grad = False
    optimizer = torch.optim.AdamW(
        [param for param in model.parameters() if param.requires_grad],
        lr=cfg.learning_rate,
    )
    alignment_weight = cfg.semantic_alignment_weight
    if semantic_alignment_weight is not None:
        alignment_weight = semantic_alignment_weight
    for step in range(cfg.train_steps):
        tokens, targets = _task_batch_for_variant(cfg, step=step, variant=task_variant)
        optimizer.zero_grad(set_to_none=True)
        controller_mode = "learned" if mode == "dense" else mode
        output = model(
            tokens,
            budget,
            controller_mode=controller_mode,
            read_memory=True,
            write_memory=step == 0,
        )
        task_loss = _weighted_loss_tensor(output.logits, targets, tokens, cfg.vocab_size)
        objective = joint_objective(
            task_loss,
            normalized_wiring_cost=float(output.telemetry["attention_density"]),
            active_fraction=float(output.telemetry["controller_active_token_fraction"]),
            route_entropy=output.route.entropy,
            weights=ObjectiveWeights(task=1.0, wiring=0.01, active=0.05, route_instability=0.01),
        )
        alignment = _semantic_alignment_loss(tokens, output.graph.active_token_gate)
        total = objective.total + alignment_weight * alignment
        total.backward()
        optimizer.step()
        model.router.update_load_bias(output.route.utilization)
    return model.eval()


def _freeze_base_path(model: CognitiveWeaveKernel) -> None:
    trainable_prefixes = ("controller.", "role_output.")
    for name, param in model.named_parameters():
        param.requires_grad = name.startswith(trainable_prefixes)


def _row(
    seed: int,
    batch_idx: int,
    mode: str,
    output: Any,
    same: Any,
    changed: Any,
    tokens: torch.Tensor,
    targets: torch.Tensor,
    cfg: CwcLiteConfig,
) -> dict[str, float | int | str]:
    route = semantic_route_metrics(tokens, output.graph.active_token_mask)
    base_sem = _semantic_projection(output.logits)
    same_sem = _semantic_projection(same.logits)
    changed_sem = _semantic_projection(changed.logits)
    invariance = F.cosine_similarity(base_sem.reshape(1, -1), same_sem.reshape(1, -1)).item()
    sensitivity = 1.0 - F.cosine_similarity(
        base_sem.reshape(1, -1),
        changed_sem.reshape(1, -1),
    ).item()
    return {
        "seed": seed,
        "batch": batch_idx,
        "mode": mode,
        "loss": _weighted_loss_float(output.logits, targets, tokens, cfg.vocab_size),
        "semantic_salience_lift": route.salience_lift,
        "high_salience_coverage": route.high_salience_coverage,
        "active_token_fraction": float(output.graph.active_token_mask.float().mean().item()),
        "invariance": float(invariance),
        "sensitivity": float(sensitivity),
    }


def _aggregate(
    rows: list[dict[str, float | int | str]],
    cfg: DcsaDecisiveConfig,
) -> dict[str, Any]:
    modes = sorted({str(row["mode"]) for row in rows})
    by_mode = {mode: _mode_summary(rows, mode) for mode in modes}
    deltas: dict[str, dict[str, Any]] = {}
    for control in ["random", "static", "frozen", "removed", "dense"]:
        deltas[f"learned_minus_{control}"] = _paired_delta(rows, "learned", control, cfg)
    return {
        "seed_count": len(cfg.seeds),
        "sample_size": len(rows),
        "mode_summary": by_mode,
        "paired_deltas": deltas,
        "component_causality_pass": _component_pass(deltas),
        "pareto_status": "NOT_TESTED_RESOURCE_TELEMETRY_MISSING",
    }


def _mode_summary(rows: list[dict[str, float | int | str]], mode: str) -> dict[str, float]:
    selected = [row for row in rows if row["mode"] == mode]
    return {
        "loss": _mean(float(row["loss"]) for row in selected),
        "semantic_salience_lift": _mean(float(row["semantic_salience_lift"]) for row in selected),
        "high_salience_coverage": _mean(float(row["high_salience_coverage"]) for row in selected),
        "active_token_fraction": _mean(float(row["active_token_fraction"]) for row in selected),
        "invariance": _mean(float(row["invariance"]) for row in selected),
        "sensitivity": _mean(float(row["sensitivity"]) for row in selected),
    }


def _paired_delta(
    rows: list[dict[str, float | int | str]],
    candidate: str,
    control: str,
    cfg: DcsaDecisiveConfig,
) -> dict[str, Any]:
    keys = sorted({(int(row["seed"]), int(row["batch"])) for row in rows})
    candidate_rows = _index(rows, candidate)
    control_rows = _index(rows, control)
    loss = [
        float(candidate_rows[key]["loss"]) - float(control_rows[key]["loss"]) for key in keys
    ]
    salience = [
        float(candidate_rows[key]["semantic_salience_lift"])
        - float(control_rows[key]["semantic_salience_lift"])
        for key in keys
    ]
    invariance = [
        float(candidate_rows[key]["invariance"]) - float(control_rows[key]["invariance"])
        for key in keys
    ]
    sensitivity = [
        float(candidate_rows[key]["sensitivity"]) - float(control_rows[key]["sensitivity"])
        for key in keys
    ]
    return {
        "loss": _delta_summary(loss, cfg, lower_is_better=True),
        "semantic_salience_lift": _delta_summary(salience, cfg, lower_is_better=False),
        "invariance": _delta_summary(invariance, cfg, lower_is_better=False),
        "sensitivity": _delta_summary(sensitivity, cfg, lower_is_better=False),
    }


def _delta_summary(
    values: list[float],
    cfg: DcsaDecisiveConfig,
    *,
    lower_is_better: bool,
) -> dict[str, float | bool | str]:
    ci_low, ci_high = _bootstrap_ci(values, cfg.bootstrap_samples, cfg.ci)
    mean = _mean(values)
    supported = ci_high < 0.0 if lower_is_better else ci_low > 0.0
    return {
        "mean": mean,
        "ci_low": ci_low,
        "ci_high": ci_high,
        "supported": supported,
        "status": "SUPPORTED" if supported else "NOT_SUPPORTED",
        "uncertainty": f"paired bootstrap {cfg.ci:.2f} CI",
    }


def _component_pass(deltas: dict[str, dict[str, Any]]) -> bool:
    required = ["random", "static", "frozen", "removed"]
    for control in required:
        item = deltas[f"learned_minus_{control}"]
        if not bool(item["semantic_salience_lift"]["supported"]):
            return False
        if not bool(item["loss"]["supported"]):
            return False
    return True


def _verdict(aggregate: dict[str, Any]) -> dict[str, str]:
    if aggregate["component_causality_pass"]:
        status = "LEVEL_3_COMPONENT_CAUSALITY_SUPPORTED_SYNTHETIC"
    else:
        status = "LEVEL_3_NOT_SUPPORTED"
    return {
        "status": status,
        "pareto": "NOT_TESTED_RESOURCE_TELEMETRY_MISSING",
        "reason": (
            "component causality requires learned to beat random/static/frozen/removed "
            "on loss and semantic salience with paired CI"
        ),
    }


def _index(
    rows: list[dict[str, float | int | str]],
    mode: str,
) -> dict[tuple[int, int], dict[str, float | int | str]]:
    return {
        (int(row["seed"]), int(row["batch"])): row for row in rows if row["mode"] == mode
    }


def _weighted_loss_tensor(
    logits: torch.Tensor,
    targets: torch.Tensor,
    tokens: torch.Tensor,
    vocab_size: int,
) -> torch.Tensor:
    per_token = F.cross_entropy(
        logits.reshape(-1, vocab_size),
        targets.reshape(-1),
        reduction="none",
    ).reshape_as(targets)
    weights = _decisive_event_weights(tokens)
    return (per_token * weights).sum() / weights.sum()


def _weighted_loss_float(
    logits: torch.Tensor,
    targets: torch.Tensor,
    tokens: torch.Tensor,
    vocab_size: int,
) -> float:
    return float(_weighted_loss_tensor(logits, targets, tokens, vocab_size).item())


def _decisive_event_weights(tokens: torch.Tensor) -> torch.Tensor:
    salience = semiotic_salience_weights(tokens)
    high_salience = salience >= torch.quantile(salience.detach().reshape(-1), 0.75)
    return torch.where(high_salience, salience, torch.full_like(salience, 0.05))


def _same_transform(tokens: torch.Tensor, vocab_size: int) -> torch.Tensor:
    transformed = tokens.clone()
    for idx in range(tokens.numel()):
        token = int(tokens.reshape(-1)[idx].item())
        transformed.reshape(-1)[idx] = _same_token(token, vocab_size)
    return transformed


def _change_transform(tokens: torch.Tensor, vocab_size: int) -> torch.Tensor:
    transformed = tokens.clone()
    for idx in range(tokens.numel()):
        token = int(tokens.reshape(-1)[idx].item())
        transformed.reshape(-1)[idx] = _changed_token(token, vocab_size)
    return transformed


def _same_token(token: int, vocab_size: int) -> int:
    field = token % 8
    sign_type = token % 3
    poly_a = _polysemy_signature(token)
    for candidate in range(vocab_size):
        if candidate == token:
            continue
        if (
            candidate % 8 == field
            and candidate % 3 == sign_type
            and _polysemy_signature(candidate) == poly_a
        ):
            return candidate
    return token


def _changed_token(token: int, vocab_size: int) -> int:
    for offset in range(1, vocab_size):
        candidate = (token + offset) % vocab_size
        if candidate % 8 != token % 8 and candidate % 3 != token % 3:
            return candidate
    return (token + 1) % vocab_size


def _polysemy_signature(token: int) -> tuple[bool, bool]:
    return token % 5 == 0, token % 13 == 0


def _semantic_projection(logits: torch.Tensor) -> torch.Tensor:
    probs = torch.softmax(logits, dim=-1)
    vocab = torch.arange(logits.shape[-1], device=logits.device)
    field_basis = F.one_hot(vocab.remainder(8), num_classes=8).to(probs.dtype)
    type_basis = F.one_hot(vocab.remainder(3), num_classes=3).to(probs.dtype)
    return torch.cat((probs @ field_basis, probs @ type_basis), dim=-1).mean(dim=(0, 1))


def _bootstrap_ci(values: list[float], samples: int, ci: float) -> tuple[float, float]:
    if not values:
        return 0.0, 0.0
    if len(values) == 1:
        return values[0], values[0]
    rng = random.Random(17)
    means = []
    for _ in range(samples):
        draw = [values[rng.randrange(len(values))] for _ in values]
        means.append(_mean(draw))
    alpha = (1.0 - ci) / 2.0
    return _quantile(means, alpha), _quantile(means, 1.0 - alpha)


def _quantile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    index = (len(ordered) - 1) * q
    lower = int(index)
    upper = min(lower + 1, len(ordered) - 1)
    weight = index - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def _mean(values: Any) -> float:
    materialized = list(values)
    return sum(materialized) / len(materialized) if materialized else 0.0


def _set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(1)
