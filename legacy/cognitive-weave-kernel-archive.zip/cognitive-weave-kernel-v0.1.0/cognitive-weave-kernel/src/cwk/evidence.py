from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import torch


def canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
    return hashlib.sha256(encoded).hexdigest()


def source_revision() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "uncommitted-local-tree"


def environment_record() -> dict[str, Any]:
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda,
        "pid": os.getpid(),
    }


def write_evidence_bundle(
    output_dir: Path,
    *,
    run_id: str,
    config: dict[str, Any],
    topology_hash: str,
    seeds: dict[str, int],
    metrics: dict[str, Any],
    data_identity: dict[str, Any],
    status: str = "complete",
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    environment = environment_record()
    (output_dir / "config.resolved.json").write_text(
        json.dumps(config, indent=2, sort_keys=True), encoding="utf-8"
    )
    (output_dir / "environment.json").write_text(
        json.dumps(environment, indent=2, sort_keys=True), encoding="utf-8"
    )
    (output_dir / "metrics.json").write_text(
        json.dumps(metrics, indent=2, sort_keys=True), encoding="utf-8"
    )
    manifest = {
        "run_id": run_id,
        "timestamp_utc": datetime.now(UTC).isoformat(),
        "source_revision": source_revision(),
        "config_hash": canonical_hash(config),
        "environment_hash": canonical_hash(environment),
        "data_hash": canonical_hash(data_identity),
        "topology_hash": topology_hash,
        "seeds": seeds,
        "metrics_file": "metrics.json",
        "status": status,
    }
    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    return manifest_path
