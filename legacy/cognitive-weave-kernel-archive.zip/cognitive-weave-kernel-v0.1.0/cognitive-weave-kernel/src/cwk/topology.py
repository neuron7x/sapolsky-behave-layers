from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class TopologyStats:
    nodes: int
    directed_edges: int
    density: float
    wiring_cost: float
    topology_hash: str


def local_global_mask(
    sequence_length: int,
    local_window: int,
    global_tokens: int,
    *,
    causal: bool = True,
    device: torch.device | None = None,
) -> torch.Tensor:
    if sequence_length < 1:
        raise ValueError("sequence_length must be positive")
    if local_window < 0:
        raise ValueError("local_window cannot be negative")
    if not 0 <= global_tokens <= sequence_length:
        raise ValueError("global_tokens outside sequence")

    allowed = torch.zeros((sequence_length, sequence_length), dtype=torch.bool, device=device)
    for query in range(sequence_length):
        left = max(0, query - local_window)
        right = query + 1 if causal else min(sequence_length, query + local_window + 1)
        allowed[query, left:right] = True
        if global_tokens:
            allowed[query, :global_tokens] = True
    if global_tokens:
        allowed[:global_tokens, :] = True
    if causal:
        allowed &= torch.tril(torch.ones_like(allowed, dtype=torch.bool))
    return allowed


def topology_stats(mask: torch.Tensor) -> TopologyStats:
    if mask.ndim != 2 or mask.shape[0] != mask.shape[1]:
        raise ValueError("mask must be square")
    n = int(mask.shape[0])
    edges = int(mask.sum().item())
    density = edges / float(n * n)
    coordinates = torch.arange(n, dtype=torch.float64, device=mask.device)
    distances = torch.abs(coordinates[:, None] - coordinates[None, :])
    wiring_cost = float((distances * mask.to(torch.float64)).sum().item())
    payload = json.dumps(mask.to(torch.uint8).cpu().tolist(), separators=(",", ":"))
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return TopologyStats(n, edges, density, wiring_cost, digest)


def normalized_wiring_cost(
    mask: torch.Tensor, dense_reference: torch.Tensor | None = None
) -> float:
    if dense_reference is not None:
        dense = dense_reference
    else:
        dense = torch.ones_like(mask, dtype=torch.bool)
    cost = topology_stats(mask).wiring_cost
    baseline = topology_stats(dense).wiring_cost
    return 0.0 if baseline == 0 else cost / baseline
