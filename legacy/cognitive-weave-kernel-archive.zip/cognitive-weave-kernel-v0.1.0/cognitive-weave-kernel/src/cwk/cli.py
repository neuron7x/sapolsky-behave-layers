from __future__ import annotations

import argparse
import json
from pathlib import Path

from .cwc_lite import CwcLiteConfig, run_cwc_lite_comparison
from .dcsa import DcsaAuditConfig, run_dcsa_audit
from .dcsa_decisive import DcsaDecisiveConfig, run_dcsa_decisive_experiment
from .fractal_control import FractalControlConfig, run_fractal_control_probe
from .neuro_cognitive_sim import NeuroCognitiveSimConfig, run_neuro_cognitive_sim
from .smoke import run_smoke
from .validation import validate_claim_firewall


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cwk")
    subparsers = parser.add_subparsers(dest="command", required=True)

    smoke = subparsers.add_parser("smoke", help="run deterministic local smoke experiment")
    smoke.add_argument("--config", type=Path, required=True)
    smoke.add_argument("--output", type=Path, default=Path("evidence/runs/local-smoke"))

    claim = subparsers.add_parser("validate-claim", help="apply Claim Firewall")
    claim.add_argument("--claim", type=Path, required=True)
    claim.add_argument("--evidence-root", type=Path, default=Path("evidence/runs"))
    claim.add_argument("--schema-root", type=Path, default=Path("schemas"))

    cwc_lite = subparsers.add_parser(
        "cwc-lite-smoke",
        help="train/evaluate CWC-lite against dense, random and inverted routing controls",
    )
    cwc_lite.add_argument("--steps", type=int, default=12)
    cwc_lite.add_argument("--seed", type=int, default=19)
    cwc_lite.add_argument("--active-token-cap-fraction", type=float, default=0.75)
    cwc_lite.add_argument("--semantic-alignment-weight", type=float, default=0.05)
    cwc_lite.add_argument("--output", type=Path)

    dcsa = subparsers.add_parser(
        "dcsa-audit",
        help="run DeepMind-style cognitive semiotic audit over CWC-lite traces",
    )
    dcsa.add_argument("--steps", type=int, default=64)
    dcsa.add_argument("--seed", type=int, default=19)
    dcsa.add_argument("--active-token-cap-fraction", type=float, default=0.75)
    dcsa.add_argument("--semantic-alignment-weight", type=float, default=0.05)
    dcsa.add_argument("--rsi-epsilon", type=float, default=0.05)
    dcsa.add_argument("--output", type=Path)
    dcsa.add_argument("--markdown-output", type=Path)

    decisive = subparsers.add_parser(
        "dcsa-decisive",
        help="run multi-seed DCSA T_same/T_change component-causality experiment",
    )
    decisive.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3, 4, 5])
    decisive.add_argument("--steps", type=int, default=64)
    decisive.add_argument("--eval-batches", type=int, default=4)
    decisive.add_argument("--bootstrap-samples", type=int, default=1000)
    decisive.add_argument("--output", type=Path)

    fractal = subparsers.add_parser(
        "fractal-control-probe",
        help="test recursive shared-rule routing against flat/random/static controls",
    )
    fractal.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3, 4, 5])
    fractal.add_argument("--active-token-cap-fraction", type=float, default=0.25)
    fractal.add_argument("--segment-size", type=int, default=4)
    fractal.add_argument("--eval-batches", type=int, default=8)
    fractal.add_argument("--output", type=Path)

    neuro = subparsers.add_parser(
        "neuro-cognitive-sim",
        help="run synthetic grounded role-transfer simulation",
    )
    neuro.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3, 4, 5])
    neuro.add_argument("--steps", type=int, default=180)
    neuro.add_argument("--eval-batches", type=int, default=32)
    neuro.add_argument("--bootstrap-samples", type=int, default=2000)
    neuro.add_argument("--output", type=Path)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.command == "smoke":
        metrics = run_smoke(args.config, args.output)
        print(json.dumps(metrics, indent=2, sort_keys=True))
        return
    if args.command == "validate-claim":
        errors = validate_claim_firewall(args.claim, args.evidence_root, args.schema_root)
        if errors:
            for error in errors:
                print(f"ERROR: {error}")
            raise SystemExit(1)
        print("CLAIM_FIREWALL_PASS")
        return
    if args.command == "cwc-lite-smoke":
        report = run_cwc_lite_comparison(
            CwcLiteConfig(
                train_steps=args.steps,
                seed=args.seed,
                active_token_cap_fraction=args.active_token_cap_fraction,
                semantic_alignment_weight=args.semantic_alignment_weight,
            )
        )
        payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
        if args.output is not None:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(payload, encoding="utf-8")
        print(payload, end="")
        return
    if args.command == "dcsa-audit":
        report = run_dcsa_audit(
            DcsaAuditConfig(
                train_steps=args.steps,
                seed=args.seed,
                active_token_cap_fraction=args.active_token_cap_fraction,
                semantic_alignment_weight=args.semantic_alignment_weight,
                rsi_epsilon=args.rsi_epsilon,
            )
        )
        markdown = str(report["markdown_report"])
        payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
        if args.output is not None:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(payload, encoding="utf-8")
        if args.markdown_output is not None:
            args.markdown_output.parent.mkdir(parents=True, exist_ok=True)
            args.markdown_output.write_text(markdown + "\n", encoding="utf-8")
        print(markdown)
        return
    if args.command == "fractal-control-probe":
        report = run_fractal_control_probe(
            FractalControlConfig(
                seeds=tuple(args.seeds),
                active_token_cap_fraction=args.active_token_cap_fraction,
                segment_size=args.segment_size,
                eval_batches=args.eval_batches,
            )
        )
        payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
        if args.output is not None:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(payload, encoding="utf-8")
        print(payload, end="")
        return
    if args.command == "dcsa-decisive":
        report = run_dcsa_decisive_experiment(
            DcsaDecisiveConfig(
                seeds=tuple(args.seeds),
                train_steps=args.steps,
                eval_batches=args.eval_batches,
                bootstrap_samples=args.bootstrap_samples,
            )
        )
        payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
        if args.output is not None:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(payload, encoding="utf-8")
        print(payload, end="")
        return
    if args.command == "neuro-cognitive-sim":
        report = run_neuro_cognitive_sim(
            NeuroCognitiveSimConfig(
                seeds=tuple(args.seeds),
                train_steps=args.steps,
                eval_batches=args.eval_batches,
                bootstrap_samples=args.bootstrap_samples,
            )
        )
        payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
        if args.output is not None:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(payload, encoding="utf-8")
        print(payload, end="")
        return
    raise SystemExit(2)


if __name__ == "__main__":
    main()
