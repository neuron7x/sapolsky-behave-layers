from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from .attention import LocalGlobalSelfAttention
from .controller import AdaptiveController
from .experts import ExpertEcology
from .memory import EpisodicMemory
from .router import BudgetedRouter
from .types import ActivationBudget, ActiveGraphState, RouteDecision, SlowStructuralState


@dataclass
class KernelOutput:
    logits: torch.Tensor
    route: RouteDecision
    graph: ActiveGraphState
    memory_state: torch.Tensor
    structural_state: SlowStructuralState
    telemetry: dict[str, float | int | bool | str]


class CognitiveWeaveKernel(nn.Module):
    def __init__(
        self,
        *,
        vocab_size: int,
        d_model: int,
        num_heads: int,
        num_experts: int,
        top_k: int,
        hidden_dim: int,
        local_window: int,
        global_tokens: int,
        memory_capacity: int,
        memory_top_k: int,
    ) -> None:
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, d_model)
        self.attention = LocalGlobalSelfAttention(
            d_model=d_model,
            num_heads=num_heads,
            local_window=local_window,
            global_tokens=global_tokens,
        )
        self.router = BudgetedRouter(d_model, num_experts, top_k)
        self.controller = AdaptiveController(d_model, max_depth=2)
        self.experts = ExpertEcology(d_model, hidden_dim, num_experts, role_dim=d_model)
        self.memory = EpisodicMemory(d_model, memory_capacity, memory_top_k)
        self.norm = nn.LayerNorm(d_model)
        self.output = nn.Linear(d_model, vocab_size)
        self.role_output = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, vocab_size),
        )
        self.num_experts = num_experts
        self.top_k = top_k

    def forward(
        self,
        token_ids: torch.Tensor,
        budget: ActivationBudget,
        *,
        read_memory: bool = True,
        write_memory: bool = False,
        controller_mode: str = "learned",
    ) -> KernelOutput:
        budget.validate()
        x = self.embedding(token_ids)
        x, attention_telemetry = self.attention(x)

        memory_reads = 0
        memory_values = torch.zeros_like(x)
        if read_memory:
            read = self.memory.read(x, budget.max_memory_reads)
            memory_values = read.values
            memory_reads = read.reads

        route = self.router(x, budget.max_active_experts)
        graph, controller_telemetry = self.controller(
            x,
            route,
            budget,
            mode=controller_mode,
        )
        memory_gate = graph.memory_read_gate.unsqueeze(-1).to(x.dtype)
        x = x + memory_values * memory_gate
        expert_update = self.experts(x, route, graph.role_code) - x
        active_gate = graph.active_token_gate.unsqueeze(-1).to(x.dtype)
        depth_gate = graph.depth_gate.unsqueeze(-1).to(x.dtype)
        x = x + expert_update * active_gate * depth_gate
        x = self.norm(x)
        logits = self.output(x)
        logits = logits + self.role_output(graph.role_code) * active_gate

        memory_writes = 0
        if write_memory:
            flattened = x.reshape(-1, x.shape[-1])
            memory_writes = self.memory.write(flattened, flattened, budget.max_memory_writes)

        active_fraction = self.top_k / self.num_experts
        telemetry: dict[str, float | int | bool | str] = {
            **attention_telemetry,
            "active_expert_fraction": active_fraction,
            "route_entropy_mean": float(route.entropy.mean().detach().cpu().item()),
            "route_overflow_count": route.overflow_count,
            "route_fallback_used": route.fallback_used,
            "memory_reads_per_query": memory_reads,
            "memory_writes": memory_writes,
            "memory_size": self.memory.size,
            "controller_active_token_fraction": controller_telemetry.active_token_fraction,
            "controller_depth_fraction": controller_telemetry.depth_fraction,
            "controller_memory_read_fraction": controller_telemetry.memory_read_fraction,
            "controller_budget_violation": controller_telemetry.budget_violation,
        }
        if float(telemetry["attention_density"]) > budget.max_attention_density:
            raise RuntimeError("attention density exceeded Activation Budget Contract")
        structural_state = SlowStructuralState(
            topology_version=0,
            plasticity_enabled=False,
            churn=0.0,
        )
        return KernelOutput(
            logits=logits,
            route=route,
            graph=graph,
            memory_state=self.memory.keys.detach().clone(),
            structural_state=structural_state,
            telemetry=telemetry,
        )
