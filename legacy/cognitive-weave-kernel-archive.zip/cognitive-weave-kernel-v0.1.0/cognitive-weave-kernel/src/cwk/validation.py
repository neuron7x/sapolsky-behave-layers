from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker


def load_json(path: Path) -> dict[str, Any]:
    data: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    return data


def validate_json(instance_path: Path, schema_path: Path) -> list[str]:
    instance = load_json(instance_path)
    schema = load_json(schema_path)
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    return [error.message for error in sorted(validator.iter_errors(instance), key=str)]


def validate_claim_firewall(claim_path: Path, evidence_root: Path, schema_root: Path) -> list[str]:
    errors = validate_json(claim_path, schema_root / "claim.schema.json")
    if errors:
        return errors
    claim = load_json(claim_path)
    evidence_ids = claim["evidence_bundle_ids"]
    for evidence_id in evidence_ids:
        manifest_path = evidence_root / evidence_id / "manifest.json"
        if not manifest_path.exists():
            errors.append(f"missing evidence manifest: {evidence_id}")
            continue
        errors.extend(
            f"{evidence_id}: {message}"
            for message in validate_json(manifest_path, schema_root / "evidence.schema.json")
        )
        if manifest_path.exists() and load_json(manifest_path).get("status") != "complete":
            errors.append(f"evidence bundle is not complete: {evidence_id}")
    if claim.get("level") in {"L3", "L4"} and claim.get("reproduction_state") != "independent":
        errors.append("L3/L4 claims require independent reproduction")
    return errors
