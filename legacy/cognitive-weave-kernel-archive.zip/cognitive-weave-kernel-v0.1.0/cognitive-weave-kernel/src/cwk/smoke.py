from __future__ import annotations

import random
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
import yaml

from .core import CognitiveWeaveKernel
from .evidence import write_evidence_bundle
from .types import ActivationBudget


def set_seed(seed: int) -> None:
    # Single-thread execution keeps the local verification path deterministic and fast.
    torch.set_num_threads(1)
    random.seed(seed)
    torch.manual_seed(seed)


def run_smoke(config_path: Path, output_dir: Path) -> dict[str, Any]:
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    model_cfg = config["model"]
    train_cfg = config["training"]
    budget_cfg = config["budget"]
    seed = int(train_cfg["seed"])
    set_seed(seed)

    model = CognitiveWeaveKernel(**model_cfg)
    budget = ActivationBudget(**budget_cfg)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(train_cfg["learning_rate"]))
    losses: list[float] = []
    last_output = None

    for step in range(int(train_cfg["steps"])):
        tokens = torch.randint(
            0,
            int(model_cfg["vocab_size"]),
            (int(train_cfg["batch_size"]), int(train_cfg["sequence_length"])),
        )
        targets = torch.roll(tokens, shifts=-1, dims=1)
        optimizer.zero_grad(set_to_none=True)
        last_output = model(tokens, budget, read_memory=True, write_memory=step == 0)
        loss = F.cross_entropy(
            last_output.logits.reshape(-1, model_cfg["vocab_size"]), targets.reshape(-1)
        )
        loss.backward()  # type: ignore[no-untyped-call]  # torch stub gap, not a code defect
        optimizer.step()
        model.router.update_load_bias(last_output.route.utilization)
        losses.append(float(loss.detach().item()))

    assert last_output is not None
    metrics: dict[str, Any] = {
        "initial_loss": losses[0],
        "final_loss": losses[-1],
        "finite": all(torch.isfinite(torch.tensor(losses)).tolist()),
        "steps": len(losses),
        **last_output.telemetry,
        "expert_utilization": last_output.route.utilization.detach().cpu().tolist(),
    }
    run_id = output_dir.name
    write_evidence_bundle(
        output_dir,
        run_id=run_id,
        config=config,
        topology_hash=str(last_output.telemetry["topology_hash"]),
        seeds={"training": seed, "data": seed + 1, "router": seed + 2},
        metrics=metrics,
        data_identity={"generator": "torch.randint", "seed": seed + 1, "purpose": "smoke"},
    )
    return metrics
