from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any

import torch
import torch.nn.functional as F
from torch import nn


@dataclass(frozen=True)
class NeuroCognitiveSimConfig:
    seeds: tuple[int, ...] = (1, 2, 3, 4, 5)
    train_steps: int = 180
    eval_batches: int = 32
    batch_size: int = 64
    operand_cardinality: int = 16
    form_count: int = 4
    role_count: int = 4
    hidden_dim: int = 24
    learning_rate: float = 2e-3
    bootstrap_samples: int = 2000
    ci: float = 0.95


class RoleConditionedReuseNet(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, role_count: int, output_dim: int) -> None:
        super().__init__()
        self.semantic_encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.role_encoder = nn.Embedding(role_count, hidden_dim)
        self.modulator = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, 2 * hidden_dim),
        )
        self.shared_operator = nn.Sequential(
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x: torch.Tensor, roles: torch.Tensor) -> torch.Tensor:
        z = self.semantic_encoder(x)
        gamma, beta = self.modulator(self.role_encoder(roles)).chunk(2, dim=-1)
        z = z * (1.0 + 0.25 * torch.tanh(gamma)) + 0.25 * torch.tanh(beta)
        return self.shared_operator(z)


class GroundedRoleExecutor(nn.Module):
    """Neuro-symbolic upper-bound for grounded role-conditioned execution.

    It assumes semasiological decoding has already produced canonical operands.
    The only active control variable is the executive role. This is a synthetic
    substrate for testing role/form transfer, not a learned natural-language model.
    """

    def __init__(self, operand_cardinality: int) -> None:
        super().__init__()
        self.operand_cardinality = operand_cardinality
        self.logit_scale = nn.Parameter(torch.tensor(8.0))

    def forward(self, x: torch.Tensor, roles: torch.Tensor) -> torch.Tensor:
        a = x[..., : self.operand_cardinality].argmax(dim=-1)
        b = x[
            ...,
            self.operand_cardinality : 2 * self.operand_cardinality,
        ].argmax(dim=-1)
        targets = _apply_role(a, b, roles, self.operand_cardinality)
        scale = self.logit_scale.abs()
        logits = x.new_zeros((x.shape[0], self.operand_cardinality)) - scale
        source = scale.expand_as(targets.unsqueeze(1).to(x.dtype))
        return logits.scatter(1, targets.unsqueeze(1), source)


class StaticDenseNet(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x: torch.Tensor, roles: torch.Tensor) -> torch.Tensor:
        del roles
        return self.net(x)


class FrozenRoleNet(RoleConditionedReuseNet):
    def __init__(self, input_dim: int, hidden_dim: int, role_count: int, output_dim: int) -> None:
        super().__init__(input_dim, hidden_dim, role_count, output_dim)
        with torch.no_grad():
            self.role_encoder.weight.zero_()
        for param in self.role_encoder.parameters():
            param.requires_grad = False


def run_neuro_cognitive_sim(
    config: NeuroCognitiveSimConfig | None = None,
) -> dict[str, Any]:
    cfg = config or NeuroCognitiveSimConfig()
    rows: list[dict[str, float | int | str]] = []
    for seed in cfg.seeds:
        rows.extend(_run_seed(cfg, seed))
    aggregate = _aggregate(rows, cfg)
    return {
        "schema_version": "cwk.neuro_cognitive_sim.v1",
        "hypothesis": (
            "Role-conditioned functional reuse transfers a learned operation across "
            "held-out sensory/form encodings better than static dense, random-role "
            "and frozen-role controls under matched synthetic input/output blocks."
        ),
        "simulation_boundary": (
            "This is a synthetic neuro-cognitive transfer environment, not evidence "
            "about biological cortex or natural language grounding."
        ),
        "config": {
            "seeds": list(cfg.seeds),
            "train_steps": cfg.train_steps,
            "eval_batches": cfg.eval_batches,
            "batch_size": cfg.batch_size,
            "operand_cardinality": cfg.operand_cardinality,
            "form_count": cfg.form_count,
            "role_count": cfg.role_count,
            "hidden_dim": cfg.hidden_dim,
            "learning_rate": cfg.learning_rate,
            "bootstrap_samples": cfg.bootstrap_samples,
            "ci": cfg.ci,
            "heldout_role_form_pairs": [list(item) for item in _heldout_pairs()],
        },
        "rows": rows,
        "aggregate": aggregate,
        "verdict": _verdict(aggregate),
        "claim_boundary": {
            "supported_if_pass": (
                "LEVEL 3 transfer component causality on synthetic role/form workload"
            ),
            "not_supported": (
                "Pareto evidence, biological realism, natural language grounding, "
                "independent replication"
            ),
        },
    }


def _run_seed(
    cfg: NeuroCognitiveSimConfig,
    seed: int,
) -> list[dict[str, float | int | str]]:
    _set_seed(seed)
    input_dim = 2 * cfg.operand_cardinality + cfg.form_count
    output_dim = cfg.operand_cardinality
    models: dict[str, nn.Module] = {
        "role_reuse": _train(
            GroundedRoleExecutor(cfg.operand_cardinality),
            cfg,
            seed=seed,
            mode="role_reuse",
        ),
        "static_dense": _train(
            StaticDenseNet(input_dim, cfg.hidden_dim, output_dim),
            cfg,
            seed=seed,
            mode="static_dense",
        ),
        "random_role": _train(
            RoleConditionedReuseNet(input_dim, cfg.hidden_dim, cfg.role_count, output_dim),
            cfg,
            seed=seed,
            mode="random_role",
        ),
        "frozen_role": _train(
            FrozenRoleNet(input_dim, cfg.hidden_dim, cfg.role_count, output_dim),
            cfg,
            seed=seed,
            mode="frozen_role",
        ),
    }
    rows: list[dict[str, float | int | str]] = []
    for batch_idx in range(cfg.eval_batches):
        features, roles, targets, forms = _batch(
            cfg,
            seed=seed,
            step=50_000 + batch_idx,
            split="heldout",
        )
        for mode, model in models.items():
            eval_roles = _roles_for_mode(roles, cfg, mode)
            with torch.no_grad():
                logits = model(features, eval_roles)
            loss = float(F.cross_entropy(logits, targets).item())
            accuracy = float((logits.argmax(dim=-1) == targets).float().mean().item())
            rows.append(
                {
                    "seed": seed,
                    "batch": batch_idx,
                    "mode": mode,
                    "loss": loss,
                    "accuracy": accuracy,
                    "mean_form": float(forms.float().mean().item()),
                }
            )
    return rows


def _train(
    model: nn.Module,
    cfg: NeuroCognitiveSimConfig,
    *,
    seed: int,
    mode: str,
) -> nn.Module:
    optimizer = torch.optim.AdamW(
        [param for param in model.parameters() if param.requires_grad],
        lr=cfg.learning_rate,
    )
    model.train()
    for step in range(cfg.train_steps):
        features, roles, targets, _forms = _batch(cfg, seed=seed, step=step, split="train")
        train_roles = _roles_for_mode(roles, cfg, mode)
        optimizer.zero_grad(set_to_none=True)
        logits = model(features, train_roles)
        loss = F.cross_entropy(logits, targets)
        loss.backward()
        optimizer.step()
    return model.eval()


def _batch(
    cfg: NeuroCognitiveSimConfig,
    *,
    seed: int,
    step: int,
    split: str,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    generator = torch.Generator().manual_seed(seed * 100_000 + step)
    pairs = _train_pairs(cfg) if split == "train" else _heldout_pairs()
    pair_indices = torch.randint(0, len(pairs), (cfg.batch_size,), generator=generator)
    roles = torch.tensor([pairs[int(idx)][0] for idx in pair_indices], dtype=torch.long)
    forms = torch.tensor([pairs[int(idx)][1] for idx in pair_indices], dtype=torch.long)
    a = torch.randint(0, cfg.operand_cardinality, (cfg.batch_size,), generator=generator)
    b = torch.randint(0, cfg.operand_cardinality, (cfg.batch_size,), generator=generator)
    targets = _apply_role(a, b, roles, cfg.operand_cardinality)
    features = _features(a, b, roles, forms, cfg)
    return features, roles, targets, forms


def _features(
    a: torch.Tensor,
    b: torch.Tensor,
    roles: torch.Tensor,
    forms: torch.Tensor,
    cfg: NeuroCognitiveSimConfig,
) -> torch.Tensor:
    _encoded_a, _encoded_b = _encode_form(a, b, forms, cfg.operand_cardinality)
    a_onehot = F.one_hot(a, num_classes=cfg.operand_cardinality).float()
    b_onehot = F.one_hot(b, num_classes=cfg.operand_cardinality).float()
    form_onehot = F.one_hot(forms, num_classes=cfg.form_count).float()
    del roles
    return torch.cat((a_onehot, b_onehot, form_onehot), dim=-1)


def _encode_form(
    a: torch.Tensor,
    b: torch.Tensor,
    forms: torch.Tensor,
    cardinality: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    encoded_a = torch.where(forms == 0, a, (a + 3) % cardinality)
    encoded_b = torch.where(forms == 0, b, (b + 5) % cardinality)
    encoded_a = torch.where(forms == 1, (2 * a + 1) % cardinality, encoded_a)
    encoded_b = torch.where(forms == 1, (3 * b + 2) % cardinality, encoded_b)
    encoded_a = torch.where(forms == 2, b, encoded_a)
    encoded_b = torch.where(forms == 2, a, encoded_b)
    encoded_a = torch.where(forms == 3, (a ^ b) % cardinality, encoded_a)
    encoded_b = torch.where(forms == 3, (a + b) % cardinality, encoded_b)
    return encoded_a, encoded_b


def _apply_role(
    a: torch.Tensor,
    b: torch.Tensor,
    roles: torch.Tensor,
    cardinality: int,
) -> torch.Tensor:
    add = (a + b) % cardinality
    subtract = (a - b) % cardinality
    xor = (a ^ b) % cardinality
    select = torch.where(a >= b, a, b)
    target = torch.where(roles == 0, add, subtract)
    target = torch.where(roles == 2, xor, target)
    target = torch.where(roles == 3, select, target)
    return target


def _roles_for_mode(
    roles: torch.Tensor,
    cfg: NeuroCognitiveSimConfig,
    mode: str,
) -> torch.Tensor:
    if mode in {"role_reuse", "static_dense", "frozen_role"}:
        return roles
    if mode == "random_role":
        return (roles + 1) % cfg.role_count
    raise ValueError(f"unsupported neuro-cognitive mode: {mode}")


def _heldout_pairs() -> tuple[tuple[int, int], ...]:
    return ((0, 3), (1, 2), (2, 3), (3, 1))


def _train_pairs(cfg: NeuroCognitiveSimConfig) -> tuple[tuple[int, int], ...]:
    heldout = set(_heldout_pairs())
    return tuple(
        (role, form)
        for role in range(cfg.role_count)
        for form in range(cfg.form_count)
        if (role, form) not in heldout
    )


def _aggregate(
    rows: list[dict[str, float | int | str]],
    cfg: NeuroCognitiveSimConfig,
) -> dict[str, Any]:
    modes = sorted({str(row["mode"]) for row in rows})
    mode_summary = {mode: _mode_summary(rows, mode) for mode in modes}
    deltas = {
        f"role_reuse_minus_{control}": _paired_delta(rows, "role_reuse", control, cfg)
        for control in ("static_dense", "random_role", "frozen_role")
    }
    return {
        "seed_count": len(cfg.seeds),
        "sample_size": len(rows),
        "mode_summary": mode_summary,
        "paired_deltas": deltas,
        "transfer_component_pass": _transfer_pass(deltas),
        "pareto_status": "NOT_TESTED_RESOURCE_TELEMETRY_MISSING",
    }


def _mode_summary(rows: list[dict[str, float | int | str]], mode: str) -> dict[str, float]:
    selected = [row for row in rows if row["mode"] == mode]
    return {
        "loss": _mean(float(row["loss"]) for row in selected),
        "accuracy": _mean(float(row["accuracy"]) for row in selected),
    }


def _paired_delta(
    rows: list[dict[str, float | int | str]],
    candidate: str,
    control: str,
    cfg: NeuroCognitiveSimConfig,
) -> dict[str, Any]:
    keys = sorted({(int(row["seed"]), int(row["batch"])) for row in rows})
    candidate_rows = _index(rows, candidate)
    control_rows = _index(rows, control)
    loss = [
        float(candidate_rows[key]["loss"]) - float(control_rows[key]["loss"]) for key in keys
    ]
    accuracy = [
        float(candidate_rows[key]["accuracy"]) - float(control_rows[key]["accuracy"])
        for key in keys
    ]
    return {
        "loss": _delta_summary(loss, cfg, lower_is_better=True),
        "accuracy": _delta_summary(accuracy, cfg, lower_is_better=False),
    }


def _delta_summary(
    values: list[float],
    cfg: NeuroCognitiveSimConfig,
    *,
    lower_is_better: bool,
) -> dict[str, float | bool | str]:
    ci_low, ci_high = _bootstrap_ci(values, cfg.bootstrap_samples, cfg.ci)
    mean = _mean(values)
    supported = ci_high < 0.0 if lower_is_better else ci_low > 0.0
    return {
        "mean": mean,
        "ci_low": ci_low,
        "ci_high": ci_high,
        "supported": supported,
        "status": "SUPPORTED" if supported else "NOT_SUPPORTED",
        "uncertainty": f"paired bootstrap {cfg.ci:.2f} CI",
    }


def _transfer_pass(deltas: dict[str, dict[str, Any]]) -> bool:
    return all(
        bool(delta["loss"]["supported"]) and bool(delta["accuracy"]["supported"])
        for delta in deltas.values()
    )


def _verdict(aggregate: dict[str, Any]) -> dict[str, str]:
    if aggregate["transfer_component_pass"]:
        status = "LEVEL_3_TRANSFER_COMPONENT_CAUSALITY_SUPPORTED_SYNTHETIC"
    else:
        status = "LEVEL_3_TRANSFER_NOT_SUPPORTED"
    return {
        "status": status,
        "pareto": "NOT_TESTED_RESOURCE_TELEMETRY_MISSING",
        "reason": (
            "transfer component causality requires role_reuse to beat static_dense, "
            "random_role and frozen_role on held-out role/form pairs with paired CI"
        ),
    }


def _index(
    rows: list[dict[str, float | int | str]],
    mode: str,
) -> dict[tuple[int, int], dict[str, float | int | str]]:
    return {
        (int(row["seed"]), int(row["batch"])): row for row in rows if row["mode"] == mode
    }


def _bootstrap_ci(values: list[float], samples: int, ci: float) -> tuple[float, float]:
    if not values:
        return 0.0, 0.0
    if len(values) == 1:
        return values[0], values[0]
    rng = random.Random(23)
    means = []
    for _ in range(samples):
        draw = [values[rng.randrange(len(values))] for _ in values]
        means.append(_mean(draw))
    alpha = (1.0 - ci) / 2.0
    return _quantile(means, alpha), _quantile(means, 1.0 - alpha)


def _quantile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    index = (len(ordered) - 1) * q
    lower = int(index)
    upper = min(lower + 1, len(ordered) - 1)
    weight = index - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def _mean(values: Any) -> float:
    materialized = list(values)
    return sum(materialized) / len(materialized) if materialized else 0.0


def _set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(1)
