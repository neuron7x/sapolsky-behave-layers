from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any

import torch

from .cwc_lite import CwcLiteConfig, _task_batch
from .semiotics import semantic_route_metrics, semiotic_salience_weights


@dataclass(frozen=True)
class FractalControlConfig:
    seeds: tuple[int, ...] = (1, 2, 3, 4, 5)
    batch_size: int = 4
    sequence_length: int = 16
    vocab_size: int = 64
    segment_size: int = 4
    active_token_cap_fraction: float = 0.25
    eval_batches: int = 8


def run_fractal_control_probe(config: FractalControlConfig | None = None) -> dict[str, Any]:
    cfg = config or FractalControlConfig()
    per_seed = [_run_seed(cfg, seed) for seed in cfg.seeds]
    aggregate = _aggregate(per_seed)
    return {
        "schema_version": "cwk.fractal_control_probe.v1",
        "hypothesis": (
            "A shared selection rule recursively applied at segment and token scales "
            "improves semantic-salience routing under the same active-token budget."
        ),
        "config": {
            "seeds": list(cfg.seeds),
            "batch_size": cfg.batch_size,
            "sequence_length": cfg.sequence_length,
            "vocab_size": cfg.vocab_size,
            "segment_size": cfg.segment_size,
            "active_token_cap_fraction": cfg.active_token_cap_fraction,
            "eval_batches": cfg.eval_batches,
        },
        "controls": ["random", "static", "flat_oracle_upper_bound"],
        "per_seed": per_seed,
        "aggregate": aggregate,
        "claim_status": _claim_status(aggregate),
        "claim_boundary": {
            "supported": (
                "fractal shared-rule routing is better than random/static "
                "on this synthetic probe"
            ),
            "not_supported": (
                "learned CWC, Pareto dominance, real semantic grounding, "
                "or hardware efficiency"
            ),
            "status": (
                "SUPPORTED"
                if aggregate["fractal_beats_random_count"] == len(cfg.seeds)
                else "ESTIMATED"
            ),
        },
    }


def _run_seed(cfg: FractalControlConfig, seed: int) -> dict[str, Any]:
    random.seed(seed)
    torch.manual_seed(seed)
    lite_cfg = CwcLiteConfig(
        vocab_size=cfg.vocab_size,
        batch_size=cfg.batch_size,
        sequence_length=cfg.sequence_length,
        seed=seed,
    )
    rows: list[dict[str, float | str]] = []
    for batch_idx in range(cfg.eval_batches):
        tokens, _ = _task_batch(lite_cfg, step=10_000 + seed * 101 + batch_idx)
        cap = max(1, int(tokens.numel() * cfg.active_token_cap_fraction))
        rows.extend(
            [
                _measure(
                    "fractal_shared_rule",
                    tokens,
                    _fractal_mask(tokens, cfg.segment_size, cap),
                ),
                _measure("flat_oracle_upper_bound", tokens, _top_salience_mask(tokens, cap)),
                _measure("random", tokens, _random_mask(tokens, cap)),
                _measure("static", tokens, _static_mask(tokens, cap)),
            ]
        )
    result = _aggregate_rows(seed, rows)
    result["deltas"] = {
        "fractal_minus_random_salience_lift": (
            result["fractal_shared_rule"]["semantic_salience_lift"]
            - result["random"]["semantic_salience_lift"]
        ),
        "fractal_minus_static_salience_lift": (
            result["fractal_shared_rule"]["semantic_salience_lift"]
            - result["static"]["semantic_salience_lift"]
        ),
        "fractal_minus_flat_oracle_salience_lift": (
            result["fractal_shared_rule"]["semantic_salience_lift"]
            - result["flat_oracle_upper_bound"]["semantic_salience_lift"]
        ),
    }
    return result


def _fractal_mask(tokens: torch.Tensor, segment_size: int, cap: int) -> torch.Tensor:
    salience = semiotic_salience_weights(tokens)
    flat_mask = torch.zeros_like(tokens, dtype=torch.bool)
    segments = []
    for row in range(tokens.shape[0]):
        for start in range(0, tokens.shape[1], segment_size):
            end = min(start + segment_size, tokens.shape[1])
            segment_salience = salience[row, start:end]
            segments.append((float(segment_salience.mean().item()), row, start, end))
    segment_count = max(1, min(len(segments), cap // max(1, segment_size // 2)))
    selected = sorted(segments, key=lambda item: item[0], reverse=True)[:segment_count]
    remaining = cap
    for _, row, start, end in selected:
        if remaining <= 0:
            break
        local_cap = min(max(1, segment_size // 2), remaining, end - start)
        local_scores = salience[row, start:end]
        local_indices = torch.topk(local_scores.reshape(-1), k=local_cap).indices
        for local_idx in local_indices:
            flat_mask[row, start + int(local_idx.item())] = True
        remaining -= local_cap
    if int(flat_mask.sum().item()) < cap:
        remainder = cap - int(flat_mask.sum().item())
        fill_scores = salience.masked_fill(flat_mask, float("-inf"))
        fill_indices = torch.topk(fill_scores.reshape(-1), k=remainder).indices
        flat_mask.reshape(-1)[fill_indices] = True
    return flat_mask


def _top_salience_mask(tokens: torch.Tensor, cap: int) -> torch.Tensor:
    salience = semiotic_salience_weights(tokens)
    mask = torch.zeros_like(tokens, dtype=torch.bool)
    indices = torch.topk(salience.reshape(-1), k=cap).indices
    mask.reshape(-1)[indices] = True
    return mask


def _random_mask(tokens: torch.Tensor, cap: int) -> torch.Tensor:
    mask = torch.zeros_like(tokens, dtype=torch.bool)
    indices = torch.randperm(tokens.numel())[:cap]
    mask.reshape(-1)[indices] = True
    return mask


def _static_mask(tokens: torch.Tensor, cap: int) -> torch.Tensor:
    mask = torch.zeros_like(tokens, dtype=torch.bool)
    mask.reshape(-1)[:cap] = True
    return mask


def _measure(mode: str, tokens: torch.Tensor, mask: torch.Tensor) -> dict[str, float | str]:
    metrics = semantic_route_metrics(tokens, mask)
    return {
        "mode": mode,
        "semantic_salience_lift": metrics.salience_lift,
        "high_salience_coverage": metrics.high_salience_coverage,
        "active_token_fraction": float(mask.float().mean().item()),
    }


def _aggregate_rows(seed: int, rows: list[dict[str, float | str]]) -> dict[str, Any]:
    modes = sorted({str(row["mode"]) for row in rows})
    result: dict[str, Any] = {"seed": seed}
    for mode in modes:
        selected = [row for row in rows if row["mode"] == mode]
        result[mode] = {
            "semantic_salience_lift": _mean(
                float(row["semantic_salience_lift"]) for row in selected
            ),
            "high_salience_coverage": _mean(
                float(row["high_salience_coverage"]) for row in selected
            ),
            "active_token_fraction": _mean(
                float(row["active_token_fraction"]) for row in selected
            ),
        }
    return result


def _aggregate(per_seed: list[dict[str, Any]]) -> dict[str, float | int]:
    random_deltas = [
        float(item["deltas"]["fractal_minus_random_salience_lift"]) for item in per_seed
    ]
    static_deltas = [
        float(item["deltas"]["fractal_minus_static_salience_lift"]) for item in per_seed
    ]
    oracle_deltas = [
        float(item["deltas"]["fractal_minus_flat_oracle_salience_lift"]) for item in per_seed
    ]
    return {
        "seed_count": len(per_seed),
        "mean_fractal_minus_random_salience_lift": _mean(random_deltas),
        "mean_fractal_minus_static_salience_lift": _mean(static_deltas),
        "mean_fractal_minus_flat_oracle_salience_lift": _mean(oracle_deltas),
        "fractal_beats_random_count": sum(delta > 0 for delta in random_deltas),
        "fractal_beats_static_count": sum(delta > 0 for delta in static_deltas),
        "fractal_beats_flat_oracle_count": sum(delta > 0 for delta in oracle_deltas),
    }


def _claim_status(aggregate: dict[str, float | int]) -> str:
    if (
        aggregate["fractal_beats_random_count"] == aggregate["seed_count"]
        and aggregate["fractal_beats_static_count"] == aggregate["seed_count"]
        and aggregate["mean_fractal_minus_flat_oracle_salience_lift"] <= 0
    ):
        return "SUPPORTED_SYNTHETIC_COMPONENT_RESULT"
    return "NOT_SUPPORTED"


def _mean(values: Any) -> float:
    materialized = list(values)
    return sum(materialized) / len(materialized) if materialized else 0.0
