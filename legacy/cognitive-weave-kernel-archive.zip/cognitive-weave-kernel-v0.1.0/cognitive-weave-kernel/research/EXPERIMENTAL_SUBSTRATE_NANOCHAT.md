# ⊛ CWC–Nanochat Experimental Substrate v0.1

**Identifier:** `CWC-EXPSUB-NANOCHAT-001`
**Status:** `PREREGISTERED` — WP-0 fixation executed 2026-07-16. Fork lives as a sibling directory
`../nanochat-cwc-baseline/` (outside this repository, per WP-0's "clean-history fork" requirement —
it is a separate git history, not vendored into CWC). `master`/`baseline` there are byte-identical
to `karpathy/nanochat@92d63d4e8bb4df75c3b71618f31ddde2378b2bcd` (verified: empty diff); our own
`BASELINE_MANIFEST.json` lives only on a dedicated `cwc-fixation` branch so the control organism is
never touched. WP-1 through WP-7 are `PENDING_EXECUTION`, not run.
**Author and Principal Architect:** Ярослав Василенко
**Base system:** `karpathy/nanochat` (MIT license), not `nanoGPT` — Karpathy has marked nanoGPT superseded; nanochat covers tokenizer → pretraining → SFT/RL → evaluation → inference end to end and is designed to be forked.

## 0. Canonical mission (restated in falsifiable form)

The goal is not to declare CWC a future world standard. The goal is to test an alternative to
brute-force scaling: a resource-bounded architecture that jointly controls routing, memory,
compute depth and structural plasticity, maximizing useful function per unit of FLOPs, VRAM,
energy, latency and bandwidth.

The practical success criterion is a **reproducible Pareto advantage** over matched dense
Transformer, static-MoE and dynamic-compute baselines. That claim requires compute-matched
comparison, preregistration, ablation analysis, negative controls, multiple seeds and independent
replication. Until that evidence exists, CWC is a strict, falsifiable architectural hypothesis —
not a claim of superiority, and not "will become the standard." The end goal is a verified
engineering principle for building plastic, energy-efficient, resource-bounded digital agents on
specified tasks — nothing broader is claimed.

## 1. Scientific goal

Determine experimentally whether joint control of active compute route, expert selection, compute
depth, short/long-term memory, hard resource budget and slow structural plasticity produces a
Pareto advantage over an equivalent static Transformer architecture. The result must be a causal
proof or disproof of CWC, not a demonstration of complexity.

## 2. Base principle

Nanochat remains an unmodified **control organism**. CWC is implemented in isolated layers so each
gain or regression can be causally attributed to a specific mechanism. Changing topology, routing,
memory and training objective simultaneously without intermediate ablation stages is forbidden.

## 3. Work packages

### WP-0 — Fix the control baseline

Pin upstream commit; preserve MIT copyright notice; fix Python/PyTorch/CUDA/dataset/tokenizer/seeds;
create an immutable `baseline` branch; reproduce a small reference run on available hardware.
**Output:** `baseline_manifest.json`, checkpoint, logs, hardware profile.

### WP-1 — Measurement loop

Add exact logging: validation loss/`val_bpb`, task quality, FLOPs and activated FLOPs, peak VRAM,
latency, tokens/second, activated parameter count, routing entropy, expert utilization, memory
reads/writes, structural churn. Nanochat already reports `val_bpb`, CORE, VRAM, MFU and throughput;
CWC extends this measurement loop rather than replacing it.

### WP-2 — Formalize CWC state

Separate `G_t` (active graph per forward pass), `M_t` (memory state), `S_τ` (slow structural
state), `B_t` (hard resource budget), `Π` (active-route controller), `Φ` (inter-episode
restructuring). Single-token/sequence routing is not structural plasticity.

### WP-3 — Sparse expert layer

Shared expert, routed experts, Top-K activation, capacity limits, deterministic routing trace,
expert-collapse control, dense-equivalent parameter-matched baseline.

### WP-4 — Executive compute controller

Decides whether to continue computing, which blocks to skip, which expert to activate, how many
FLOPs a given example is allowed, when to terminate inference. Budget is a hard precondition:
exceeding `B_t` blocks execution, it does not merely add a loss penalty.

### WP-5 — Hierarchical memory

Separate context working memory, episodic state, long-term adaptive memory, write policy,
forgetting policy, retrieval cost. Evaluate not just retrieval accuracy but negative transfer,
memory contamination and catastrophic interference.

### WP-6 — Slow structural plasticity

Between episodes: pruning low-utility edges, growing new routes, expert reassignment, structural
churn limits, rollback after regression. Every `S_τ` change carries provenance: cause, expected
benefit, measured utility delta, cost.

### WP-7 — Joint closed-loop controller

Combine routing, depth, memory and topology only after each mechanism is independently validated.
The controller optimizes utility under hard budgets and may not conceal overruns behind averaged
metrics.

## 4. Experimental matrix

Mandatory configurations, minimum three seeds each, identical data/tokenizer/training
tokens/evaluation protocol: (1) static dense nanochat; (2) dynamic depth only; (3) sparse experts
only; (4) memory only; (5) routing+depth; (6) routing+memory; (7) routing+depth+memory; (8) full
CWC without structural plasticity; (9) full CWC with structural plasticity; (10) random-router and
shuffled-memory negative controls.

## 5. Acceptance criterion

CWC is accepted only if, simultaneously: quality not below baseline; lower activated FLOPs, VRAM or
latency; no expert collapse; positive transfer; stability after restructuring; reproduction on an
independent seed; ablation confirms the causal contribution of each component; at least one Pareto
point undominated by baseline systems. One good-looking result, one seed, or one task is not proof.

## 6. Falsification conditions

The CWC hypothesis is rejected or narrowed if: the advantage disappears after compute alignment;
the controller costs more than it saves; routing is unstable; memory improves recall but degrades
general transfer; topology adaptation does not beat random restructuring; the result does not
reproduce.

## 7. Final artifacts

Clean-history fork; baseline and CWC checkpoints; preregistration; experiment registry; ablation
matrix; Pareto-front report; machine-readable evidence bundle; reproducible run scripts; a
technical writeup with a positive or negative verdict.

## 8. Hardware boundary

The available local GPU is an RTX 3050 (4 GB VRAM). This supports WP-0 fixation, smoke checks and
micro-experiments only. Nanochat's own reference runs (the "speedrun" configuration and above) are
scoped to multi-GPU datacenter hardware; a full WP-1–WP-7 reference run is not executable on this
machine. Any run claimed as "reproduced" from this environment must state its reduced scale
explicitly and must not be compared against nanochat's published reference numbers as if
compute-matched.

## Relationship to CLAIMS.md and ADR-0007

`Q_transfer`/`Q_adapt`/`Q_robust`/`Q_agency` (ADR-0007, `CWC-UDC-001..005`) are the metrics WP-1's
measurement loop must extend nanochat's existing telemetry to capture. `CWC-CLM-009` (prior-art gap
hypothesis) and `CWC-CLM-010` (open research problem) are exactly the hypotheses this substrate is
built to test — this document does not itself constitute evidence toward either.
