# Release Gates

## G0 — Structural integrity

All required documents, schemas and source files exist; schemas are valid; repository validation passes.

## G1 — Deterministic execution

Unit tests and smoke run pass on supported Python versions. Evidence bundle is complete.

## G2 — Mechanism validity

Each mechanism passes its causal benchmark against randomized and disabled controls.

## G3 — Resource validity

Algorithmic proxy reductions correspond to measured system improvements on declared hardware, or claims remain proxy-only.

## G4 — Integrated Pareto result

The integrated architecture is non-inferior on protected capability and improves at least one resource metric without dominating regressions.

## G5 — Robustness

Results survive preregistered seeds, splits, perturbations and out-of-distribution tests.

## G6 — Safety and state integrity

Memory isolation, budget enforcement, evidence tampering and action-permission tests pass.

## G7 — Independent reproduction

A separate executor reproduces frozen results and records deviations.

## G8 — Claim release

Claim Firewall passes. Claim language is bounded by evidence. General claims require multi-task, multi-domain and independent evidence.
