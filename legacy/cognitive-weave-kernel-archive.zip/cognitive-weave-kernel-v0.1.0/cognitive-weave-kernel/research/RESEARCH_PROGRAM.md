# Research Programme

## Primary question

Can a jointly optimized sparse topology, conditional router, expert ecology and bounded memory produce a reproducible Pareto improvement over resource-matched alternatives?

## Hypotheses

### H1 — Wiring-constrained modularity

A connection-cost term will produce lower communication cost and greater modularity than task loss alone without exceeding the preregistered capability tolerance.

### H2 — Conditional functional yield

A routed expert ecology will improve capability per activated parameter over a dense parameter-matched baseline and a compute-matched dense baseline.

### H3 — Local–global sufficiency

A learned or structured local–global communication graph will preserve task performance at lower attention density than full connectivity on tasks whose dependency graph is sparse.

### H4 — Memory utility

Episodic memory will improve delayed recall and transfer beyond equal-token context extension after retrieval latency, distraction and memory footprint are counted.

### H5 — Controlled plasticity

Prune–grow adaptation between task regimes will reduce adaptation cost or forgetting relative to fixed topology without producing instability.

### H6 — Integrated synergy

The integrated kernel will demonstrate a positive interaction beyond the sum of isolated component gains. Failure of H6 does not invalidate successful component hypotheses.

## Explicit non-hypotheses

CWK does not initially test consciousness, subjective experience, human equivalence, biological identity or unrestricted general intelligence.
