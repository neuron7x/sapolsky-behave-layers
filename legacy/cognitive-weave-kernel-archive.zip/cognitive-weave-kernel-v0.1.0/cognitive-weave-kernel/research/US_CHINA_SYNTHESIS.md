# United States–China Method Synthesis

This document records the engineering methods selected for evaluation. It does not rank countries and does not treat technical reports as independent validation.

## United States research line

### Sparse local–global attention

BigBird demonstrates that a combination of local, random and global attention can reduce sequence complexity while preserving important theoretical properties. CWK adopts the **local–bridge–global pattern class**, but replaces a fixed attention recipe with a versioned topology contract and explicit cost telemetry.

### Conditional computation

Sparsely-Gated MoE and Switch Transformer establish trainable sparse expert selection and expose practical failure modes: communication overhead, instability, expert imbalance and token capacity. CWK adopts conditional activation but requires shared-path fallback, route replay and a complete utilization record.

### Memory beyond the context window

Memorizing Transformers use external retrieval over prior representations. Titans proposes neural long-term memory updated at test time. CWK begins with provenance-bounded episodic retrieval, then tests trainable memory only after state isolation and matched-cost utility are established.

### Governance and reproducibility

NIST AI RMF, NIST SSDF, SLSA provenance and MLCommons reproducibility principles motivate native risk, provenance and benchmark controls. CWK converts them into executable repository contracts rather than relying solely on release documentation.

## China research line

### Fine-grained and shared experts

DeepSeekMoE separates shared experts from fine-grained routed experts to reduce redundancy and improve specialization. CWK adopts the shared-plus-routed decomposition as a baseline mechanism while independently measuring specialization and redundancy.

### Load balancing without task-gradient interference

Loss-Free Balancing applies dynamically updated expert biases before Top-K routing. CWK implements an auditable bias state and treats it as one candidate controller; it must be compared with auxiliary-loss balancing and unbalanced routing.

### Hybrid attention and long-context efficiency

DeepSeek MLA, MiniMax Lightning Attention, Kimi Linear and MoBA represent distinct approaches to reducing attention or KV-cache cost. CWK does not combine them blindly. It defines a common communication interface so each mechanism can be substituted and evaluated under the same budget.

### Adaptive reasoning budgets

Qwen3 exposes thinking-budget control. CWK generalizes the idea into a Metacognitive Budget Governor that allocates depth, routing and memory access, while separating budget decisions from output content.

## Synthesis boundary

The selected architecture is not a collage. Each imported method is reduced to a contract, assigned a causal hypothesis, given matched baselines, and rejected if it does not improve the declared Pareto frontier. CWK's authorial contribution lies in the system of contracts, lifecycle, evidence objects and integrated falsification programme.
