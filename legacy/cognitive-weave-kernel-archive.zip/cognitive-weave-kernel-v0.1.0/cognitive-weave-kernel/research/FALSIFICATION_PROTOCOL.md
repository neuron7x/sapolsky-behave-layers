# Falsification Protocol

## 1. Preregistration

Before training, freeze:

- hypothesis and causal contrast;
- datasets and exact identities;
- train/validation/test partition;
- model and baseline budgets;
- primary and secondary metrics;
- minimum effect or non-inferiority margin;
- seeds and number of independent runs;
- exclusion and failure rules;
- statistical procedure;
- claim scope.

## 2. Units and repetitions

The experimental unit is the independently sampled dataset/task instance or environment seed defined by the protocol. Training seeds are computational repetitions and SHALL NOT be misrepresented as independent biological or population observations.

## 3. Required controls

- matched dense model;
- matched activated-compute model;
- static sparse graph;
- randomized graph with equal density;
- learned router, frozen router and shuffled router;
- memory disabled, random retrieval and oracle retrieval upper bound;
- plasticity disabled and random rewiring;
- topology or expert ablation;
- data-label permutation where meaningful.

## 4. Measurement

Primary vector:

```text
(capability, active_flops, latency, peak_memory, communication,
 route_entropy, overflow, robustness, calibration, adaptation_cost)
```

No single average may replace the full vector. Tail latency and worst-group results are mandatory when deployment claims are considered.

## 5. Statistical discipline

- report all preregistered runs;
- use confidence intervals over valid independent units;
- correct multiplicity for families of confirmatory tests;
- distinguish exploratory from confirmatory analyses;
- publish effect sizes and uncertainty, not only p-values;
- treat benchmark saturation and contamination as threats;
- use paired comparisons when models share evaluation instances;
- never infer population generalization from a fixed benchmark alone.

## 6. Rejection rules

Reject the tested mechanism when any condition holds:

- primary capability falls below the non-inferiority margin;
- resource reduction is below the minimum meaningful threshold;
- improvement disappears under compute-matched comparison;
- route collapse violates utilization limits;
- memory gain is explained by additional context or data access;
- effect fails the preregistered robustness check;
- deterministic replay or evidence validation fails.

## 7. Claim levels

| Level | Meaning |
|---|---|
| L0 | implementation observation |
| L1 | benchmark result under one frozen protocol |
| L2 | replicated across seeds/splits/tasks |
| L3 | independently reproduced |
| L4 | bounded generalization claim |

The default repository state is L0.
