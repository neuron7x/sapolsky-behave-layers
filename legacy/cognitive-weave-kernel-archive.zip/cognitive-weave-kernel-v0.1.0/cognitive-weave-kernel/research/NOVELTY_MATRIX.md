# Prior-Art and Novelty Matrix

CWK does not claim novelty for sparse attention, MoE, memory augmentation, structural plasticity or wiring-cost regularization individually. The candidate novelty is the **contractual integration** of these mechanisms under one observable resource objective and one evidence-governed topology lifecycle.

| Capability | Established prior art | CWK differentiator to test |
|---|---|---|
| Sparse local/global communication | BigBird and related sparse attention | topology is a versioned system object with measured wiring and communication cost |
| Conditional expert activation | Sparsely-Gated MoE, Switch, DeepSeekMoE | route decisions obey an explicit multi-resource budget contract |
| Load balancing | auxiliary losses and loss-free bias updates | balance is one constraint; specialization, churn and fallback are co-measured |
| Long-term memory | Memorizing Transformer, Titans, ATLAS | memory tiers share provenance, retention and cost accounting contracts |
| Adaptive compute | thinking budgets and early-exit families | budget selection is separated from content generation and audited |
| Structural adaptation | pruning, growth and dynamic sparse training | topology deltas are proposed, validated, versioned and reversible |
| Brain network economy | small-world and economical network literature | neuroscience informs hypotheses but provides no equivalence claim |
| Reproducible AI governance | NIST, SLSA, MLCommons practices | evidence and claim validation are native runtime objects, not release paperwork |

## Novelty boundary

A novelty claim is prohibited until:

1. a documented search covers relevant literature and implementations;
2. the exact claimed combination is absent from searched prior art;
3. the contribution is described at contract and mechanism level;
4. empirical gain is separated from conceptual originality;
5. an external reviewer can reproduce the comparison.
