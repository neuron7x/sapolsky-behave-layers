# Claim Policy

## Required claim fields

Every claim must declare:

- exact statement;
- claim level;
- target population or task scope;
- causal contrast;
- evidence bundle identifiers;
- uncertainty;
- known limitations;
- conflicts and role overlap;
- reproduction state;
- expiration or review condition.

## Forbidden transformations

The following transformations are invalid:

```text
lower proxy FLOPs → lower measured energy
benchmark improvement → general intelligence
routing selectivity → semantic specialization
small-world metric → biological fidelity
memory retrieval → understanding
successful demo → robust agent
```

## Language rule

Use “demonstrated under protocol X” rather than “proves”. Use “candidate mechanism” until causal controls pass. Use “independently reproduced” only when executed by an independent party from frozen artifacts.
