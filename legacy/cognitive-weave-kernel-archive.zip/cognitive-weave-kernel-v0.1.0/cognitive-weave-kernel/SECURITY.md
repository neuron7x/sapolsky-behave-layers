# Security Policy

## Scope

This repository contains experimental AI code. It is not authorized for autonomous control of physical, financial, medical, military or critical infrastructure systems.

## Mandatory controls

- dependencies are pinned in release artifacts;
- untrusted model artifacts are never loaded with arbitrary-code deserialization;
- memory inputs are treated as untrusted data;
- tool/action interfaces require explicit permissions;
- secrets are forbidden in source, logs and evidence bundles;
- generated artifacts include provenance and hashes;
- evaluation executes without network access by default.

Report vulnerabilities privately to the repository owner before public disclosure.
