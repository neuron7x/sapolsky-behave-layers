# Model Card

## Identity

- model identifier:
- source revision:
- topology hash:
- training data manifest:
- release gate reached:

## Intended use

## Prohibited use

## Architecture

## Activated-resource profile

## Evaluation protocols

## Results with uncertainty

## Routing and expert diagnostics

## Memory behavior

## Safety, privacy and security

## Limitations and invalid inferences

## Reproduction instructions
