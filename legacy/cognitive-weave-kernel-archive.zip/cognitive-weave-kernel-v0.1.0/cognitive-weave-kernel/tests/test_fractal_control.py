from cwk.fractal_control import FractalControlConfig, run_fractal_control_probe


def test_fractal_control_probe_compares_budget_matched_controls() -> None:
    report = run_fractal_control_probe(
        FractalControlConfig(seeds=(1, 2), eval_batches=2, active_token_cap_fraction=0.25)
    )

    assert report["schema_version"] == "cwk.fractal_control_probe.v1"
    assert report["aggregate"]["seed_count"] == 2
    assert "random" in report["controls"]
    assert "static" in report["controls"]
    assert report["claim_boundary"]["not_supported"]
    for seed_report in report["per_seed"]:
        active = seed_report["fractal_shared_rule"]["active_token_fraction"]
        assert active == seed_report["random"]["active_token_fraction"]
        assert active == seed_report["static"]["active_token_fraction"]
