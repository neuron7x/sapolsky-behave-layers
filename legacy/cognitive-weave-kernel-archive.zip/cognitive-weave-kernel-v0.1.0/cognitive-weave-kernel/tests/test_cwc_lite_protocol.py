from pathlib import Path

import yaml

from cwk.cwc_lite_protocol import validate_cwc_lite_protocol

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_ROOT = ROOT / "schemas"
PROTOCOL = ROOT / "experiments" / "cwc_lite_pareto_v1.yaml"


def _mutated_protocol(tmp_path: Path, **updates: object) -> Path:
    payload = yaml.safe_load(PROTOCOL.read_text(encoding="utf-8"))
    for key, value in updates.items():
        target = payload
        parts = key.split("__")
        for part in parts[:-1]:
            target = target[part]
        target[parts[-1]] = value
    path = tmp_path / "protocol.yaml"
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    return path


def test_cwc_lite_protocol_passes_frozen_semantic_gate() -> None:
    assert validate_cwc_lite_protocol(PROTOCOL, SCHEMA_ROOT) == []


def test_cwc_lite_rejects_phase_two_plasticity(tmp_path: Path) -> None:
    path = _mutated_protocol(tmp_path, candidate__topology_plasticity_enabled=True)
    errors = validate_cwc_lite_protocol(path, SCHEMA_ROOT)
    assert any("plasticity is phase two" in error for error in errors)


def test_cwc_lite_rejects_missing_required_baseline(tmp_path: Path) -> None:
    # 3 items to satisfy the schema's minItems:3 structural rule, so this actually
    # exercises the semantic "missing dynamic_depth" check rather than tripping
    # the structural check first and masking it behind a generic schema error.
    path = _mutated_protocol(
        tmp_path, baselines=["dense_transformer", "static_moe", "recursive_parameter_sharing"]
    )
    errors = validate_cwc_lite_protocol(path, SCHEMA_ROOT)
    assert any("dynamic_depth" in error for error in errors)


def test_cwc_lite_rejects_soft_budget_substitution(tmp_path: Path) -> None:
    path = _mutated_protocol(tmp_path, budgets__hard_constraints=False)
    errors = validate_cwc_lite_protocol(path, SCHEMA_ROOT)
    assert any("soft penalties cannot prove CWC" in error for error in errors)


def test_cwc_lite_rejects_weak_claim_rule(tmp_path: Path) -> None:
    path = _mutated_protocol(tmp_path, claim_rule="Candidate wins if average accuracy improves.")
    errors = validate_cwc_lite_protocol(path, SCHEMA_ROOT)
    assert any("claim_rule" in error and "hypervolume" in error for error in errors)
