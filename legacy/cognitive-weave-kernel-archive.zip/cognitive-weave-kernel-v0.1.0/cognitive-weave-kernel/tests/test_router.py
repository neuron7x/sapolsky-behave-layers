import torch

from cwk.router import BudgetedRouter


def test_router_respects_top_k_and_normalizes_weights() -> None:
    torch.manual_seed(1)
    router = BudgetedRouter(d_model=8, num_experts=4, top_k=2)
    x = torch.randn(2, 5, 8)
    decision = router(x, max_active_experts=2)
    assert decision.indices.shape == (2, 5, 2)
    assert torch.allclose(decision.weights.sum(dim=-1), torch.ones(2, 5))
    assert torch.isclose(decision.utilization.sum(), torch.tensor(1.0))


def test_load_bias_update_is_centered() -> None:
    router = BudgetedRouter(d_model=4, num_experts=4, top_k=1)
    router.update_load_bias(torch.tensor([1.0, 0.0, 0.0, 0.0]), step_size=0.1)
    assert torch.isclose(router.load_bias.mean(), torch.tensor(0.0), atol=1e-7)
    assert router.load_bias[0] < router.load_bias[1]
