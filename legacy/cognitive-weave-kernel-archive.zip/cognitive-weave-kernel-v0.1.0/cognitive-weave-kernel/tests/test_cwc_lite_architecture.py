import torch

from cwk.controller import AdaptiveController
from cwk.core import CognitiveWeaveKernel
from cwk.cwc_lite import CwcLiteConfig, run_cwc_lite_comparison
from cwk.experts import ExpertEcology
from cwk.router import BudgetedRouter
from cwk.types import ActivationBudget


def test_adaptive_controller_outputs_active_graph_under_hard_token_budget() -> None:
    torch.manual_seed(3)
    x = torch.randn(2, 6, 8)
    route = BudgetedRouter(d_model=8, num_experts=4, top_k=2)(x, max_active_experts=2)
    controller = AdaptiveController(d_model=8, max_depth=2)
    budget = ActivationBudget(
        max_active_experts=2,
        max_attention_density=1.0,
        max_memory_reads=3,
        max_memory_writes=0,
        max_depth=1,
        max_active_tokens=4,
    )

    graph, telemetry = controller(x, route, budget)

    assert 0 < graph.active_token_mask.sum().item() <= 4
    assert 0 < graph.memory_read_mask.sum().item() <= 3
    assert graph.active_token_gate.requires_grad
    assert graph.role_code.shape == x.shape
    assert graph.policy == "learned"
    assert 0.0 < telemetry.active_token_fraction < 1.0


def test_kernel_returns_explicit_g_m_s_states() -> None:
    torch.manual_seed(5)
    model = CognitiveWeaveKernel(
        vocab_size=32,
        d_model=16,
        num_heads=4,
        num_experts=4,
        top_k=2,
        hidden_dim=32,
        local_window=2,
        global_tokens=1,
        memory_capacity=16,
        memory_top_k=2,
    )
    budget = ActivationBudget(2, 0.60, 2, 8, max_depth=1, max_active_tokens=6)
    output = model(torch.randint(0, 32, (2, 8)), budget, write_memory=True)

    active_tokens = output.graph.active_token_mask.sum().item()
    assert 0 < active_tokens <= 6
    assert output.memory_state.ndim == 2
    assert output.structural_state.topology_version == 0
    assert output.telemetry["controller_active_token_fraction"] == active_tokens / 16


def test_role_conditioned_expert_ecology_changes_functional_output() -> None:
    torch.manual_seed(11)
    x = torch.randn(2, 5, 8)
    route = BudgetedRouter(d_model=8, num_experts=3, top_k=2)(x, max_active_experts=2)
    experts = ExpertEcology(d_model=8, hidden_dim=16, num_experts=3)

    low_role = torch.zeros(2, 5, 8)
    high_role = torch.linspace(-1.0, 1.0, steps=8).expand(2, 5, 8)

    low = experts(x, route, low_role)
    high = experts(x, route, high_role)

    assert not torch.allclose(low, high)


def test_cwc_lite_comparison_has_baselines_and_controls() -> None:
    report = run_cwc_lite_comparison(
        CwcLiteConfig(train_steps=2, eval_batches=1, batch_size=2, sequence_length=8)
    )

    modes = {item["mode"] for item in report["results"]}
    assert modes == {"dense", "learned", "random", "static", "inverted"}
    learned = next(item for item in report["results"] if item["mode"] == "learned")
    dense = next(item for item in report["results"] if item["mode"] == "dense")
    assert learned["active_token_fraction"] < dense["active_token_fraction"]
    assert "semantic_salience_lift" in learned
    assert "learned_minus_random_semantic_salience_lift" in report["deltas"]
    assert "learned_minus_dense_eval_loss" in report["deltas"]
    assert report["interpretation"] == "training_smoke_not_pareto_claim"
