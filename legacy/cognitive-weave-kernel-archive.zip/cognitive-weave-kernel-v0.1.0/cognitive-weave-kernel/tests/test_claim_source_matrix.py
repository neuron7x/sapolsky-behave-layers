from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_claim_source_matrix_gate() -> None:
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run(
        [sys.executable, str(root / "scripts" / "check_claim_source_matrix.py")],
        cwd=root,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "bibliography-gate: OK" in result.stdout
