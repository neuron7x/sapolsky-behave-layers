import json
from pathlib import Path

from cwk.value_function import evaluate_capability_threshold_gate

SCHEMA_ROOT = Path(__file__).resolve().parents[1] / "schemas"
EXAMPLES = Path(__file__).resolve().parents[1] / "evidence" / "examples"


def test_compliant_report_passes() -> None:
    report_path = EXAMPLES / "value_function_report.valid.json"
    errors = evaluate_capability_threshold_gate(report_path, SCHEMA_ROOT)
    assert errors == []


def test_self_reported_pass_is_rejected_under_violations() -> None:
    report_path = EXAMPLES / "value_function_report.invalid.json"
    errors = evaluate_capability_threshold_gate(report_path, SCHEMA_ROOT)
    assert any("safety_envelope_violations" in error for error in errors)
    assert any("verifier_trace_id" in error for error in errors)
    assert any("cannot mark itself PASS" in error for error in errors)


def test_threshold_crossing_must_match_declared_flag(tmp_path: Path) -> None:
    report = json.loads((EXAMPLES / "value_function_report.valid.json").read_text())
    report["capability_threshold_crossed"] = False  # lie: proposed > baseline but flag says no
    report_path = tmp_path / "report.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    errors = evaluate_capability_threshold_gate(report_path, SCHEMA_ROOT)
    assert any("disagrees with thresholds" in error for error in errors)


def test_non_compute_matched_transfer_is_rejected(tmp_path: Path) -> None:
    report = json.loads((EXAMPLES / "value_function_report.valid.json").read_text())
    report["q_transfer"]["budget_ood_hash"] = "different-budget"
    report_path = tmp_path / "report.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    errors = evaluate_capability_threshold_gate(report_path, SCHEMA_ROOT)
    assert any("not compute-matched" in error for error in errors)


def test_excess_structural_churn_is_rejected(tmp_path: Path) -> None:
    report = json.loads((EXAMPLES / "value_function_report.valid.json").read_text())
    report["q_adapt"]["structural_churn"] = 0.5
    report_path = tmp_path / "report.json"
    report_path.write_text(json.dumps(report), encoding="utf-8")
    errors = evaluate_capability_threshold_gate(report_path, SCHEMA_ROOT)
    assert any("exceeds" in error and "churn_bound" in error for error in errors)
