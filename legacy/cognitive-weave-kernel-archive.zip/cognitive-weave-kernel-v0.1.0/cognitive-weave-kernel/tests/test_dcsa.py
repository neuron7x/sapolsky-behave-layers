import math

from cwk.dcsa import DcsaAuditConfig, run_dcsa_audit


def test_dcsa_audit_emits_four_stage_report() -> None:
    report = run_dcsa_audit(DcsaAuditConfig(train_steps=2, seed=7))

    assert report["schema_version"] == "cwk.dcsa_audit.v2"
    assert report["executive_verdict"]["maximum_supported_claim_level"].startswith("LEVEL 1")
    assert report["evidence_gate"]["claimable_run"] is False
    assert report["claim_evidence_matrix"]
    assert report["semiotic_landscape"]["syntactic_entropy_bits"] > 0.0
    assert math.isfinite(report["geometric_representation"]["effective_rank_proxy"])
    assert report["geometric_representation"]["riemann_curvature"] == "INVALID_REQUEST"
    assert report["geometric_representation"]["fisher_information"] == "NOT_TESTED"
    assert 0.0 <= report["semasiological_grounding"]["rsi"] <= 1.0
    assert "learned_minus_random_loss" in report["compute_equivalent_controls"]
    assert report["adversarial_disruption"]["max_kl_divergence"] >= 0.0
    assert "# COGNITIVE-SEMANTIC ARCHITECTURE AUDIT" in report["markdown_report"]
    assert "## 10. NEXT DECISIVE EXPERIMENT" in report["markdown_report"]
