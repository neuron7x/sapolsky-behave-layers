import json
from pathlib import Path

from cwk.validation import validate_claim_firewall


def test_claim_firewall_rejects_missing_evidence(tmp_path: Path) -> None:
    claim = {
        "claim_id": "claim-1",
        "statement": "The mechanism improved a frozen benchmark under a declared budget.",
        "level": "L1",
        "scope": "synthetic task only",
        "evidence_bundle_ids": ["absent-run"],
        "uncertainty": "not estimated",
        "limitations": ["smoke-only"],
        "reproduction_state": "none",
    }
    claim_path = tmp_path / "claim.json"
    claim_path.write_text(json.dumps(claim), encoding="utf-8")
    schema_root = Path(__file__).resolve().parents[1] / "schemas"
    errors = validate_claim_firewall(claim_path, tmp_path, schema_root)
    assert any("missing evidence" in error for error in errors)
