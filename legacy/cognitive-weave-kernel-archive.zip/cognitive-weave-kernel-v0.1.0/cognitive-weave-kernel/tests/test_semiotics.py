import torch

from cwk.semiotics import semantic_route_metrics, semiotic_salience_weights


def test_semiotic_salience_weights_are_deterministic_and_structured() -> None:
    tokens = torch.tensor([[0, 1, 2, 5, 13, 16]])

    weights = semiotic_salience_weights(tokens)

    assert weights.shape == tokens.shape
    assert torch.all(weights >= 1.0)
    assert weights[0, 3] > weights[0, 1]
    assert torch.equal(weights, semiotic_salience_weights(tokens))


def test_semantic_route_metrics_reward_high_salience_activation() -> None:
    tokens = torch.tensor([[0, 1, 2, 5, 13, 16]])
    weights = semiotic_salience_weights(tokens)
    high_salience_mask = weights >= torch.quantile(weights.reshape(-1), 0.75)
    low_salience_mask = ~high_salience_mask

    high = semantic_route_metrics(tokens, high_salience_mask)
    low = semantic_route_metrics(tokens, low_salience_mask)

    assert high.salience_lift > low.salience_lift
    assert high.high_salience_coverage > low.high_salience_coverage
