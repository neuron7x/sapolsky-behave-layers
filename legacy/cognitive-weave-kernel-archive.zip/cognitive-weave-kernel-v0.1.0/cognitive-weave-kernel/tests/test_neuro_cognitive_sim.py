from cwk.neuro_cognitive_sim import NeuroCognitiveSimConfig, run_neuro_cognitive_sim


def test_neuro_cognitive_sim_reports_transfer_controls_and_boundaries() -> None:
    report = run_neuro_cognitive_sim(
        NeuroCognitiveSimConfig(seeds=(1, 2), train_steps=4, eval_batches=2, bootstrap_samples=50)
    )

    assert report["schema_version"] == "cwk.neuro_cognitive_sim.v1"
    assert report["simulation_boundary"]
    modes = {row["mode"] for row in report["rows"]}
    assert modes == {"role_reuse", "static_dense", "random_role", "frozen_role"}
    assert report["aggregate"]["pareto_status"] == "NOT_TESTED_RESOURCE_TELEMETRY_MISSING"
    static_delta = report["aggregate"]["paired_deltas"]["role_reuse_minus_static_dense"]
    assert "ci_low" in static_delta["loss"]
    assert "ci_high" in static_delta["accuracy"]
    assert report["claim_boundary"]["not_supported"]
