import torch

from cwk.core import CognitiveWeaveKernel
from cwk.types import ActivationBudget


def build_model() -> CognitiveWeaveKernel:
    return CognitiveWeaveKernel(
        vocab_size=32,
        d_model=16,
        num_heads=4,
        num_experts=4,
        top_k=2,
        hidden_dim=32,
        local_window=2,
        global_tokens=1,
        memory_capacity=16,
        memory_top_k=2,
    )


def test_core_forward_is_finite_and_observable() -> None:
    torch.manual_seed(7)
    model = build_model()
    budget = ActivationBudget(2, 0.60, 2, 8)
    tokens = torch.randint(0, 32, (2, 8))
    output = model(tokens, budget, write_memory=True)
    assert output.logits.shape == (2, 8, 32)
    assert torch.isfinite(output.logits).all()
    assert output.telemetry["active_expert_fraction"] == 0.5
    assert output.telemetry["memory_writes"] <= 8
    assert len(str(output.telemetry["topology_hash"])) == 64


def test_core_rejects_attention_budget_breach() -> None:
    model = build_model()
    budget = ActivationBudget(2, 0.10, 0, 0)
    tokens = torch.randint(0, 32, (1, 8))
    try:
        model(tokens, budget)
    except RuntimeError as exc:
        assert "attention density" in str(exc)
    else:
        raise AssertionError("expected budget breach")
