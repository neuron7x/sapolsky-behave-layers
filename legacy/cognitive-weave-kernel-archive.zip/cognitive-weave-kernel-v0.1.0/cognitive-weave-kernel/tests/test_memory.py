import torch

from cwk.memory import EpisodicMemory


def test_memory_write_read_and_capacity() -> None:
    memory = EpisodicMemory(d_model=4, capacity=3, top_k=2)
    values = torch.eye(4)
    written = memory.write(values, values, max_writes=4)
    assert written == 4
    assert memory.size == 3
    read = memory.read(values[-1:].view(1, 1, 4), max_reads=2)
    assert read.reads == 2
    assert read.values.shape == (1, 1, 4)


def test_memory_disabled_read_is_zero() -> None:
    memory = EpisodicMemory(d_model=4, capacity=3, top_k=2)
    query = torch.randn(2, 3, 4)
    read = memory.read(query, max_reads=0)
    assert read.reads == 0
    assert torch.equal(read.values, torch.zeros_like(query))
