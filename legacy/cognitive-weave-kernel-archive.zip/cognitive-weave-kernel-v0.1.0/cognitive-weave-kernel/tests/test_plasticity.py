import torch

from cwk.plasticity import StructuralPlasticityController


def test_plasticity_proposal_is_deterministic_and_reversible_in_shape() -> None:
    mask = torch.eye(5, dtype=torch.bool)
    mask[0, 1] = True
    mask[1, 2] = True
    utility = torch.arange(25, dtype=torch.float32).reshape(5, 5)
    controller = StructuralPlasticityController()
    delta = controller.propose(mask, utility, prune_fraction=0.5, grow_count=2)
    updated = controller.apply(mask, delta)
    assert updated.shape == mask.shape
    assert torch.diagonal(updated).all()
    assert len(delta.added) == 2
