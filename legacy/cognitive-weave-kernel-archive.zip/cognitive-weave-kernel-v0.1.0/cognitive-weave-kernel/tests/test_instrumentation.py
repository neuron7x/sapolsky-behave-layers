from pathlib import Path

import torch

from cwk.instrumentation import (
    EnergySampler,
    FlopLedger,
    InferenceLatencyBreakdown,
    RoutingTrace,
    RunMeter,
    VRAMMeter,
)


def test_routing_trace_records_active_fractions() -> None:
    trace = RoutingTrace()
    trace.record(
        "layer-0",
        active_tokens=4,
        total_tokens=8,
        active_experts=2,
        total_experts=4,
        metadata={"policy": "top_k"},
    )

    payload = trace.to_dict()
    assert payload["event_count"] == 1
    assert payload["active_token_fraction_mean"] == 0.5
    assert payload["active_expert_fraction_mean"] == 0.5
    assert payload["events"][0]["metadata"]["policy"] == "top_k"


def test_flop_ledger_is_analytical_and_reproducible() -> None:
    ledger = FlopLedger()
    dense = ledger.add_dense_linear("proj", tokens=3, d_in=4, d_out=5)
    attn = ledger.add_attention("attn", tokens=6, d_model=8, density=0.25)
    ffn = ledger.add_routed_ffn("expert", active_tokens=2, d_model=4, hidden_dim=16)
    memory = ledger.add_memory_bytes("kv-cache", 512)
    communication = ledger.add_communication_bytes("all-to-all", 256)

    assert dense == 2 * 3 * 4 * 5
    assert attn == 8 * 6 * 8 * 8 + int(4 * 0.25 * 6 * 6 * 8)
    assert ffn == 4 * 2 * 4 * 16
    assert memory == 512
    assert communication == 256
    assert ledger.to_dict()["total_flops"] == dense + attn + ffn
    assert ledger.to_dict()["operational_intensity_flops_per_byte"] > 0.0


def test_roofline_and_moe_cap_reports_are_derived_from_ledger() -> None:
    ledger = FlopLedger()
    ledger.add_dense_linear("matmul", tokens=16, d_in=32, d_out=32)
    ledger.add_memory_bytes("weights", 1_000_000)

    roofline = ledger.roofline_report(
        peak_flops_per_s=1_000_000_000.0,
        peak_memory_bandwidth_bytes_per_s=100_000_000.0,
    )
    cap = ledger.moe_cap_report(
        measured_tokens_per_s=50.0,
        theoretical_tokens_per_s=100.0,
        measured_memory_bytes_per_s=20.0,
        theoretical_memory_bytes_per_s=80.0,
    )

    assert roofline["bound"] == "memory_bound"
    assert roofline["operational_intensity_flops_per_byte"] == ledger.operational_intensity
    assert cap == {"s_mfu": 0.5, "s_mbu": 0.25}


def test_run_meter_reports_latency_flops_routing_and_jsonl(tmp_path: Path) -> None:
    trace = RoutingTrace()
    trace.record("route", active_tokens=2, total_tokens=4, active_experts=1, total_experts=4)
    ledger = FlopLedger()
    ledger.add_dense_linear("linear", tokens=4, d_in=8, d_out=8)
    meter = RunMeter(warmup_steps=1, jsonl_path=tmp_path / "metrics.jsonl")
    weight = torch.ones((8, 8))
    x = torch.ones((4, 8))

    def fn() -> torch.Tensor:
        return x @ weight

    summary = meter.benchmark(fn, steps=3, routing_trace=trace, flop_ledger=ledger)

    assert summary["latency"]["end_to_end_ms"]["count"] == 3
    assert summary["latency"]["end_to_end_ms"]["p95"] >= summary["latency"]["end_to_end_ms"]["p50"]
    assert summary["latency"]["gpu_kernel_ms"]["count"] == 3
    assert summary["flops"]["total_flops"] == 2 * 4 * 8 * 8
    assert summary["routing"]["event_count"] == 1
    assert (tmp_path / "metrics.jsonl").read_text(encoding="utf-8").count("\n") == 1


def test_inference_latency_breakdown_tracks_ttft_tpot_ttlt() -> None:
    breakdown = InferenceLatencyBreakdown.from_token_timestamps(
        request_start_s=10.0,
        first_token_s=10.2,
        token_times_s=[10.2, 10.5, 10.9],
        request_end_s=11.0,
        prompt_tokens=16,
        output_tokens=3,
    )
    meter = RunMeter()
    meter.record_inference_breakdown(breakdown)
    summary = meter.summary()

    assert breakdown.ttft_ms == 199.9999999999993
    assert breakdown.tpot_ms == 350.00000000000053
    assert breakdown.ttlt_ms == 1000.0
    assert summary["latency"]["inference"]["count"] == 1
    assert summary["latency"]["inference"]["ttft_ms"]["p50"] == breakdown.ttft_ms


def test_vram_meter_and_energy_sampler_fail_closed_on_cpu_or_missing_nvml() -> None:
    vram = VRAMMeter().snapshot()
    assert {"available", "allocated_bytes", "peak_allocated_bytes"}.issubset(vram)

    sampler = EnergySampler(interval_s=0.001)
    assert sampler._integrated_joules() == 0.0
    assert EnergySampler().interval_s == 0.1


def test_overhead_report_is_an_ab_gate() -> None:
    passing = RunMeter.overhead_report(off_seconds=1.0, on_seconds=1.01)
    failing = RunMeter.overhead_report(off_seconds=1.0, on_seconds=1.03)

    assert passing["pass"] is True
    assert failing["pass"] is False
