from cwk.dcsa_decisive import DcsaDecisiveConfig, run_dcsa_decisive_experiment


def test_dcsa_decisive_experiment_has_required_controls_and_ci() -> None:
    report = run_dcsa_decisive_experiment(
        DcsaDecisiveConfig(seeds=(1, 2), train_steps=2, eval_batches=1, bootstrap_samples=50)
    )

    assert report["schema_version"] == "cwk.dcsa_decisive.v1"
    assert "T_change_signature_changing_substitution" in report["available"]
    modes = {row["mode"] for row in report["rows"]}
    assert {"learned", "random", "static", "frozen", "removed", "dense"} <= modes
    delta = report["aggregate"]["paired_deltas"]["learned_minus_random"]
    assert "ci_low" in delta["loss"]
    assert "semantic_salience_lift" in delta
    assert report["verdict"]["pareto"] == "NOT_TESTED_RESOURCE_TELEMETRY_MISSING"
