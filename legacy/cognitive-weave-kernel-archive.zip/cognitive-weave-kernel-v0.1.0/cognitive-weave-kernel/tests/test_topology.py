import torch

from cwk.topology import local_global_mask, normalized_wiring_cost, topology_stats


def test_local_global_mask_is_causal_and_sparse() -> None:
    mask = local_global_mask(16, local_window=2, global_tokens=1, causal=True)
    assert torch.equal(mask, torch.tril(mask))
    stats = topology_stats(mask)
    assert 0.0 < stats.density < 1.0
    assert normalized_wiring_cost(mask) < 1.0
    assert len(stats.topology_hash) == 64


def test_global_token_cannot_see_future_under_causal_contract() -> None:
    mask = local_global_mask(8, local_window=1, global_tokens=1, causal=True)
    assert mask[0, 0]
    assert not mask[0, 1:].any()
