# Authorship and Intellectual Authority

**Ярослав Василенко** — Founder, Principal Architect, independent researcher; originator of the CWK synthesis, canonical intellectual objects, research statute and integration thesis.

External methods are acknowledged in `research/SOURCE_REGISTER.yaml`. Their inclusion as prior art does not transfer authorship of CWK's decomposition, contracts, evidence architecture or integrated research programme.
