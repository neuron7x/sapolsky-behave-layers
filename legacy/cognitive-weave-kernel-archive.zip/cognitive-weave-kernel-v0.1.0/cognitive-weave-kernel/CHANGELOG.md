# Changelog

## 0.4.0 — 2026-07-16

- added `src/cwk/instrumentation/` (WP-1 reification of `CWC-CLM-008`): `FlopLedger` (analytical
  FLOPs/bytes accounting — dense linear, attention, routed FFN, memory/communication byte markers,
  roofline and MoE `s_mfu`/`s_mbu` capacity reports), `RoutingTrace` (active-token/active-expert
  fraction accounting), `VRAMMeter` (`torch.cuda` peak allocation snapshot), `EnergySampler`
  (background power-draw sampling, `nvidia-smi`-subprocess based, integrated to joules),
  `RunMeter` (paired CUDA-event + wall-clock step timing, p50/p95/p99 latency, JSONL evidence
  writer, `overhead_report()` — measurement is required to stay under a declared
  `max_overhead_fraction` of the unmeasured baseline, so instrumentation cannot itself be the
  thing that invalidates the latency it reports);
- added `experiments/cwc_lite_pareto_v1.yaml` + `schemas/cwc_lite_protocol.schema.json` +
  `src/cwk/cwc_lite_protocol.py` (`validate_cwc_lite_protocol`) + `scripts/check_cwc_lite_protocol.py`
  + `make cwc-lite-verify`: a frozen, fail-closed preregistration gate scoping the first
  confirmatory bakeoff to routing + token-level depth + KV-memory policy + hard budget, with
  `topology_plasticity_enabled: false` enforced structurally — plasticity stays phase two. Recorded
  in `CLAIMS.md` as `CWC-UDC-006`, with rationale grounded in reading `karpathy/nanochat`'s `moe3`
  branch directly (DeepSeekV3-style MoE: per-step loss improved, MFU regressed 46%→35%, net
  wall-clock loss at GPT-2 scale — `dev/LOG.md`, 2026-02-19), not in an external survey's ~80
  unresolved citation markers, which are explicitly NOT promoted to bibliography-tier evidence;
- fixed one real bug surfaced by full verification: `test_cwc_lite_rejects_missing_required_baseline`
  tripped the schema's `minItems: 3` structural check before reaching the semantic
  "missing baseline" check it intended to exercise, silently passing for the wrong reason;
- fixed 3 mypy-strict findings (`torch.cuda.Event` untyped-call, same class of torch stub gap as
  the 0.3.0 `Tensor.backward()` fix) and 1 ruff line-length finding in the new instrumentation
  module; 28/28 tests, ruff, mypy, and all five verify gates (bibliography, value-function,
  cwc-lite, repository validator, smoke) green;
- separately, `nanochat-cwc-baseline` (sibling fork, not part of this repo) gained a
  `wp1-instrumentation` branch: `nanochat/cwc_instrumentation.py` (`EnergySampler` via `pynvml`,
  `ActivatedComputeCounter`, `RoutingTelemetry` placeholder) wired additively into
  `scripts/base_train.py`'s existing logging block, extending nanochat's own
  `val_bpb`/CORE/VRAM/MFU telemetry rather than replacing it; `master`/`baseline` there remain
  byte-identical to upstream `karpathy/nanochat@92d63d4e`.

## 0.3.0 — 2026-07-16

- reified ADR-0007 as executable code, not just prose: `schemas/value_function.schema.json`
  defines a machine-checkable value-function report contract; `src/cwk/value_function.py`
  (`evaluate_capability_threshold_gate`) enforces the semantic gate — threshold-crossing
  consistency, compute-matched `Q_transfer`, churn-bounded `Q_adapt`, safety-envelope-clean and
  inspectable-trace-backed `Q_robust`/`Q_agency`;
- added `scripts/check_value_function_report.py`, wired as `make value-function-verify` and into
  CI; a report cannot mark its own `gate_decision` as `PASS` while its measured fields fail the
  Capability-Threshold Gate — the validator rejects self-graded reports;
- added `tests/test_value_function_gate.py` (5 cases: compliant pass, plus four independent
  rejection paths) and two example reports under `evidence/examples/`;
- cross-linked `CLAIMS.md` (`CWC-UDC-001..005`) and ADR-0007 to the new implementation, with an
  explicit boundary note: the gate validates internal consistency of a *reported* measurement, it
  cannot verify the underlying experiment was run honestly — that remains an Evidence Spine
  provenance requirement, not something a JSON Schema enforces.

## 0.2.0 — 2026-07-16

- added ADR-0007 operationalizing the previously-undefined `Q_transfer`/`Q_adapt`/`Q_robust`/
  `Q_agency` slots in CWC-SPEC-001 §12.1, motivated by Sutskever's public generalization thesis and
  Amodei's Responsible Scaling Policy / interpretability principles — both cited as motivation, not
  as bibliography-tier primary sources (`docs/adr/0007-value-function-generalization-safety.md`);
- added CHARTER Article 5 invariant 11, **Capability-Threshold Gate**: new plasticity operators or
  routing configurations above a preregistered threshold are gated by `Q_robust`/`Q_agency`
  measurement as a precondition, structurally identical to Budget-first (§3.1);
- added `CLAIMS.md` rows `CWC-UDC-001..005` marked `UNSOURCED_DESIGN_CHOICE` per its own
  maintenance rule;
- added `research/EXPERIMENTAL_SUBSTRATE_NANOCHAT.md` (`CWC-EXPSUB-NANOCHAT-001`): a preregistered
  falsification substrate using `karpathy/nanochat` (MIT) as an unmodified control organism, with
  WP-0 through WP-7 work packages, a 10-configuration experimental matrix, acceptance criteria and
  falsification conditions;
- executed WP-0 baseline fixation for real: cloned `nanochat` as a sibling fork at
  `../nanochat-cwc-baseline/`, pinned upstream commit `92d63d4e8bb4df75c3b71618f31ddde2378b2bcd`,
  verified MIT license/copyright notice intact, recorded `BASELINE_MANIFEST.json` with hardware
  (RTX 3050, 4096 MiB VRAM) and software profile; `master`/`baseline` branches verified
  byte-identical to upstream (empty diff) — our manifest lives only on a separate `cwc-fixation`
  branch so the control organism is never touched;
- did **not** attempt WP-1 through WP-7 execution: local VRAM is ~1/20th of nanochat's reference
  target (80GB) and local torch (2.12.1+cu130) does not match the pinned dependency (`==2.9.1`);
  this is recorded as an explicit feasibility verdict in `BASELINE_MANIFEST.json`, not implied to be
  done.

## 0.1.1 — 2026-07-16

- merged `CWC-BIB-USCN-001` evidence bibliography (35 primary sources, 10 governed claims):
  `docs/BIBLIOGRAPHY_US_CN.md`, `docs/claim_source_matrix.json`, `docs/SOURCE_AUDIT.csv`,
  `scripts/check_claim_source_matrix.py`, `tests/test_claim_source_matrix.py`,
  `.github/workflows/bibliography-claim-gate.yml`; SHA256SUMS.txt of the source package verified
  intact before merge; `CWC-*` identifiers and author field preserved unchanged;
- added `CLAIMS.md` binding every architecture claim to a `CWC-CLM-*` evidence row;
- added `bibliography-verify` to the Makefile and CI verification closure;
- fixed 13 `ruff` findings and 13 `mypy --strict` findings surfaced by first full local
  lint/typecheck run (import ordering, line length, missing `types-jsonschema`/`types-PyYAML`
  stubs, untyped `nn.Module` buffer attributes, `Any`-returning calls through
  `nn.Module.__call__`, one torch stub gap on `Tensor.backward`); no numeric behavior changed —
  smoke evidence is byte-identical to 0.1.0.

## 0.1.0 — 2026-07-15

- established canonical-candidate statute;
- defined ten authorial intellectual objects;
- implemented local reference kernel;
- added falsification protocol, schemas, evidence gate and CI;
- added smoke benchmark and deterministic tests.
