# COGNITIVE-SEMANTIC ARCHITECTURE AUDIT

## 0. EXECUTIVE VERDICT
- Audit status: EXECUTABLE_BUT_NOT_CLAIMABLE
- Maximum supported claim level: LEVEL 1 - EXECUTABLE CONTRACT
- Strongest verified result: learned routing has bounded synthetic semantic-routing evidence
- Critical blocker: learned router does not beat random on task loss in this seed
- Next falsifying experiment: 5-seed paired T_same/T_change run against random, static, frozen and removed controls

## 1. SYSTEM AND EVIDENCE METADATA
- Target architecture: CWC-lite learned resource-constrained semantic router
- Commit/checkpoint: NOT_AVAILABLE
- Dataset: synthetic CWC-lite token task
- Hardware: NOT_RECORDED
- Seeds: [23]
- Available evidence: source_code, synthetic_dataset_generator, model_config, single_seed_execution_trace, random_router_control, static_router_control
- Missing evidence: git_commit_or_checkpoint_hash, dependency_lock_attestation, hardware_telemetry, activation_traces, gradient_traces, physical_energy_measurement, multi_seed_confidence_intervals, external_dataset
- Reproducibility status: ESTIMATED

## 2. CLAIM-EVIDENCE MATRIX
| Claim | Required evidence | Available evidence | Status | Reason |
|---|---|---|---|---|
| Reference implementation executes | source code, command, tests | source code plus pytest coverage | VERIFIED | audit and tests executed locally |
| Learned router improves semantic routing over random/static | paired controls under equal active-token cap | single-seed random/static controls | SUPPORTED | semantic lift deltas are positive, but uncertainty is not estimated |
| Learned router improves task quality over random/static | paired controls and confidence intervals | single-seed weighted cross-entropy | INVALID | single-seed result must beat both controls to support the claim |
| Semantic grounding | invariance, sensitivity and action relevance | T_same invariance proxy and synthetic action relevance only | NOT_TESTED | T_change sensitivity and external outcome are missing |
| Representation manifold curvature | metric tensor, manifold validation, local samples, uncertainty | logits only | INVALID | Riemann curvature is not identifiable from this evidence |
| Empirical Fisher information | per-sample gradients | no gradients captured | NOT_TESTED | Fisher approximation cannot be computed from logits alone |
| Compute-equivalent Pareto superiority | FLOPs, VRAM, latency, energy, 5 seeds, confidence intervals | active-token parity only | NOT_TESTED | resource telemetry and statistical protocol are missing |

## 3. COMPUTATIONAL GRAPH AND ROUTING
- Active graph: embedding -> local/global attention -> budgeted router -> adaptive controller -> memory gate -> expert ecology -> output head
- Routing entropy: value=3.000000; unit=bits; sample_size=48; seed_count=1; uncertainty=NOT_ESTIMATED; measurement_method=observed semantic-field entropy; status=VERIFIED
- Utilization: expert utilization trace available only as per-run router telemetry; cross-seed routing stability not measured
- Collapse indicators: absorbing states=0; degenerate pathways=0
- Controller FLOPs: NOT_TESTED; analytical controller ledger not attached to this audit
- Controller latency: NOT_TESTED; instrumentation trace not attached to this audit
- Status: ESTIMATED for graph structure; VERIFIED for observed routing masks

## 4. REPRESENTATION GEOMETRY
- Methods actually applicable: effective-rank proxy over logits only
- Effective rank: value=19.241051; unit=rank; sample_size=48; seed_count=1; uncertainty=NOT_ESTIMATED; measurement_method=logit covariance eigenspectrum; status=ESTIMATED
- CKA/RSA: NOT_TESTED; layer activations were not persisted
- Local dimension: NOT_TESTED; insufficient activation neighborhood traces
- Fisher approximation: NOT_TESTED; gradients were not captured
- Unsupported geometric claims: Riemann curvature tensor = INVALID_REQUEST; no metric tensor/manifold validation/synthetic estimator control
- Status: ESTIMATED for effective-rank proxy; INVALID for full curvature/FIM claims

## 5. SEMANTIC INVARIANCE AND GROUNDING
- T_same: synthetic same-signature token substitution
- T_change: NOT_TESTED; no separate causal meaning-changing transform set
- Invariance: value=0.999834; unit=cosine; sample_size=48; seed_count=1; uncertainty=NOT_ESTIMATED; measurement_method=semantic projection RSI; status=VERIFIED
- Sensitivity: NOT_TESTED
- Action relevance: value=-0.002624; unit=loss delta; sample_size=48; seed_count=1; uncertainty=NOT_ESTIMATED; measurement_method=paired weighted CE on static control; status=VERIFIED
- Grounding score: NOT_TESTED; missing sensitivity and external action outcome
- Commutativity test: ESTIMATED; paired synthetic T_same only, no uncertainty
- Status: SUPPORTED for invariance proxy; NOT_TESTED for full grounding

## 6. ADVERSARIAL AND CAUSAL FAILURES
- Perturbation set: single-token same-signature replacement
- Oracle: programmatic synthetic semantic signature
- Worst-case degradation: value=0.101774; unit=KL; sample_size=48; seed_count=1; uncertainty=NOT_ESTIMATED; measurement_method=brute-force L0=1 scan; status=VERIFIED
- Random-control degradation: NOT_TESTED
- Failure coordinate: [0, 10]
- Alternative explanation: lexical index sensitivity, not necessarily semantic collapse
- Status: VERIFIED for bounded synthetic disruption; NOT_TESTED for causal failure

## 7. COMPUTE-EQUIVALENT BASELINES
| Model | Quality | FLOPs | VRAM | p95 latency | Energy | Transfer | Adaptation |
|---|---:|---:|---:|---:|---:|---:|---:|
| learned | 4.275730 | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | synthetic | trained router |
| random | 4.267716 | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | synthetic | random router |
| static | 4.278354 | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | synthetic | fixed-prefix router |

- Compute parity: INVALID for full claim; active-token parity only was verified
- Statistical method: single-seed paired evaluation; no confidence interval
- Confidence intervals: NOT_TESTED
- Pareto verdict: PARETO_NOT_SUPPORTED

## 8. FALSIFICATION OUTCOME
- Hypotheses rejected: dense/Pareto/general-grounding claims for this evidence bundle
- Hypotheses surviving: learned routing can improve synthetic semantic salience routing
- Untested hypotheses: T_change sensitivity, memory contribution, depth adaptation, S_t plasticity, energy/latency efficiency, external workload transfer
- Confounds: synthetic oracle, single seed, no activation trace, no hardware telemetry
- Required negative controls: removed controller, frozen learned controller, semantic-label shuffle, T_change set, memory on/off, depth fixed/adaptive

## 9. FINAL CLAIM BOUNDARY
### Supported
- The reference audit executes and reports bounded synthetic routing evidence.
- Learned routing improved semantic salience lift over random/static controls in this run.

### Not supported
- Full semantic grounding.
- Pareto dominance.
- Energy efficiency.
- Riemannian manifold or Fisher-metric claims.

### Prohibited wording
- grounded intelligence
- functorial semantic proof
- compute-equivalent Pareto win
- causal semantic architecture

## 10. NEXT DECISIVE EXPERIMENT
- Intervention: run 5-seed CWC-lite with T_same and T_change transform sets.
- Controls: dense, random, static, frozen-router, removed-controller.
- Budget: equal active-token cap plus measured FLOPs/VRAM/latency.
- Primary metrics: weighted CE, semantic lift, invariance, sensitivity, p95 latency.
- Failure criterion: learned does not beat random/frozen on semantic lift and loss.
- Success criterion: learned beats all controls with paired 95% CI and resource parity.
