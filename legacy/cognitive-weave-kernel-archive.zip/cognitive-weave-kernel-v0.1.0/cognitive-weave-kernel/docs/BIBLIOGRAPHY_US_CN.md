# ⊛ Cognitive Wiring Core — доказова бібліографія першоджерел США та Китаю

**Ідентифікатор:** `CWC-BIB-USCN-001`  
**Версія:** `1.0.0`  
**Дата зрізу:** `2026-07-15`  
**Автор архітектури:** Ярослав Василенко  
**Об’єкт:** Cognitive Wiring Core  
**Тип документа:** аргументована бібліографія + межі доказу + prior-art map

## 1. Призначення

Цей документ не є декоративним списком літератури. Він визначає, які саме елементи CWC мають підтверджене першоджерельне підґрунтя, що кожне джерело фактично демонструє, чого воно не доводить і який локальний експеримент потрібний для перенесення результату в CWC.

Бібліографія прив’язана до канонічної специфікації `CWC-SPEC-001`: budget-first виконання, дві часові шкали, sparse-by-default, ієрархічна пам’ять, adaptive depth, структурні оператори, Pareto-критерій і evidence-gated release.

## 2. Правила включення

До основного корпусу включено лише:

1. оригінальні статті, технічні звіти, стандарти або benchmark-специфікації;
2. роботи, створені в американському або китайському дослідницькому середовищі;
3. джерела, що містять формальний механізм, експеримент або вимірювальний протокол;
4. джерела, для яких можна сформулювати точну межу доказу.

Виключено огляди, блоги, медіа, рекламні сторінки, перекази, цитатні агрегатори та роботи без прямого зв’язку з CWC. Позначка `USA_MULTINATIONAL` означає глобальну лабораторію в корпоративній екосистемі компанії зі штаб-квартирою у США; це не твердження про громадянство авторів.

## 3. Шкала доказовості

- `A1_PEER_REVIEWED_PRIMARY` — рецензована оригінальна робота.
- `A2_PRIMARY_BENCHMARK` — оригінальний відкритий benchmark/measurement protocol.
- `B1_PRIMARY_REPORT_CODE` — первинний технічний звіт із кодом.
- `B1_PRIMARY_REPORT_WEIGHTS` — первинний технічний звіт із відкритими вагами/артефактами.
- `B2_PRIMARY_REPORT` — первинний preprint/technical report; результати залишаються авторськими повідомленнями.
- `S1_PRIMARY_STANDARD` — офіційна стандартна або нормативна рамка.

Жодний tier не переносить результат у CWC автоматично. Для promotion потрібні локальні baselines, ablations, resource traces і reproduction.

## 4. Аргументативний ланцюг

1. **Топологія:** локальна щільність і небагато дальніх зв’язків можуть забезпечувати короткі глобальні маршрути без повного all-to-all графа.
2. **Умовне обчислення:** MoE і sparse attention показують, що ємність і активний compute можна розділити.
3. **Бюджет мислення:** глибину, кількість активних токенів і довжину reasoning можна робити залежними від задачі.
4. **Пам’ять:** робоча, зовнішня й neural long-term memory можуть мати окремі стани та політики.
5. **Пластичність:** зв’язки можна grow/prune/regrow, але безпечне когнітивне самоперебудування ще не доведене.
6. **Заземлення:** мультимодальні представлення можна пов’язувати зі станом середовища та діями.
7. **Доказ:** FLOPs недостатньо; потрібні latency, VRAM, bytes, joules, quality constraints і uncertainty.
8. **Незакритий синтез:** у корпусі не знайдено єдиної системи, що спільно контролює routing, memory, depth і persistent topology під жорстким багаторесурсним бюджетом.

---

## США / американська дослідницька екосистема
### US-TOP-001 — Watts, D

**Повне посилання:** Watts, D. J., & Strogatz, S. H. Collective dynamics of “small-world” networks. Nature 393, 440–442 (1998).  
**Першоджерело:** https://doi.org/10.1038/30918  
**Інституція:** Cornell University  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** A network can combine high local clustering with short global path lengths through a small number of long-range shortcuts; the paper demonstrated this topology in several empirical networks and analyzed dynamical consequences.  
**Значення для CWC:** Defines the graph-theoretic target family behind local clusters plus sparse hubs/shortcuts.  
**Заборонене розширення твердження:** Does not show that small-world topology is optimal for language models, that it will emerge from CWC training, or that biological and artificial networks are mechanistically equivalent.  
**Пов’язані claims:** CWC-CLM-001

### US-TOP-002 — Chklovskii, D

**Повне посилання:** Chklovskii, D. B., Schikorski, T., & Stevens, C. F. Wiring optimization in cortical circuits. Neuron 34(3), 341–347 (2002).  
**Першоджерело:** https://doi.org/10.1016/S0896-6273(02)00679-7  
**Інституція:** Cold Spring Harbor Laboratory / Salk Institute  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** The paper formulates cortical organization as an optimization problem in which wiring volume and conduction delay constrain circuit layout.  
**Значення для CWC:** Supports treating communication distance, transfer volume and latency as explicit costs rather than decorative topology metrics.  
**Заборонене розширення твердження:** A biological wiring principle is a design constraint and analogy, not evidence that CWC implements a brain or that Euclidean embedding alone measures hardware cost.  
**Пов’язані claims:** CWC-CLM-001, CWC-CLM-008

### US-MOE-001 — Lepikhin, D

**Повне посилання:** Lepikhin, D. et al. GShard: Scaling Giant Models with Conditional Computation and Automatic Sharding. arXiv:2006.16668 (2020).  
**Першоджерело:** https://arxiv.org/abs/2006.16668  
**Інституція:** Google  
**Клас доказу:** `B1_PRIMARY_REPORT_CODE`  
**Підтверджений факт:** GShard combines sparsely gated experts with automatic SPMD sharding, demonstrating that model capacity can grow much faster than per-token active computation.  
**Значення для CWC:** Provides prior art for conditional expert activation and distributed execution of routed modules.  
**Заборонене розширення твердження:** The topology is architect-designed and the routing does not jointly control memory, depth or persistent structural rewiring.  
**Пов’язані claims:** CWC-CLM-002, CWC-CLM-009

### US-MOE-002 — Fedus, W

**Повне посилання:** Fedus, W., Zoph, B., & Shazeer, N. Switch Transformers: Scaling to Trillion Parameter Models with Simple and Efficient Sparsity. JMLR 23(120), 1–39 (2022).  
**Першоджерело:** https://jmlr.org/papers/v23/21-0998.html  
**Інституція:** Google Research  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** Top-1 expert routing enabled sparse Transformer scaling and the authors reported up to 7× pretraining speed increases under the same computational resources, while documenting load-balancing and stability problems.  
**Значення для CWC:** Establishes sparse conditional computation as viable and exposes router collapse, capacity and communication as first-class failure modes.  
**Заборонене розширення твердження:** Reported speedups are workload/hardware dependent; Switch does not modify long-term topology and does not prove CWC-level efficiency.  
**Пов’язані claims:** CWC-CLM-002, CWC-CLM-008

### US-MOE-003 — Rajbhandari, S

**Повне посилання:** Rajbhandari, S. et al. DeepSpeed-MoE: Advancing Mixture-of-Experts Inference and Training to Power Next-Generation AI Scale. ICML/PMLR 162 (2022).  
**Першоджерело:** https://proceedings.mlr.press/v162/rajbhandari22a.html  
**Інституція:** Microsoft  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** DeepSpeed-MoE demonstrates that sparse model quality gains can be erased operationally by memory and communication costs unless inference placement, parallelism and compression are co-designed.  
**Значення для CWC:** Justifies CWC bandwidth, placement, peak-memory and latency budgets in addition to FLOPs.  
**Заборонене розширення твердження:** System-level serving improvements are not evidence for cognitive adaptation or self-restructuring.  
**Пов’язані claims:** CWC-CLM-002, CWC-CLM-008

### US-ATTN-001 — Zaheer, M

**Повне посилання:** Zaheer, M. et al. Big Bird: Transformers for Longer Sequences. NeurIPS 33 (2020).  
**Першоджерело:** https://arxiv.org/abs/2007.14062  
**Інституція:** Google Research  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** A fixed sparse pattern combining local, random and global attention reduces sequence-length dependence from quadratic to linear and processed sequences up to eight times longer on similar hardware in the reported experiments.  
**Значення для CWC:** Concrete prior art for local neighborhoods plus sparse global hubs in an attention graph.  
**Заборонене розширення твердження:** BigBird uses a fixed pattern; it neither learns persistent topology nor proves that small-world statistics cause intelligence.  
**Пов’язані claims:** CWC-CLM-001, CWC-CLM-003

### US-ATTN-002 — Roy, A

**Повне посилання:** Roy, A., Saffar, M., Vaswani, A., & Grangier, D. Efficient Content-Based Sparse Attention with Routing Transformers. TACL 9, 53–68 (2021).  
**Першоджерело:** https://arxiv.org/abs/2003.05997  
**Інституція:** Google Research  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** Online k-means routes queries to content-related clusters, yielding dynamic sparse attention with O(n^1.5 d) complexity and reported quality gains over comparable sparse baselines.  
**Значення для CWC:** Supports learned input-dependent edge selection in the fast active graph G_t.  
**Заборонене розширення твердження:** Cluster routing changes active attention, not the persistent structural state S_t.  
**Пов’язані claims:** CWC-CLM-001, CWC-CLM-003, CWC-CLM-009

### US-DEPTH-001 — Raposo, D

**Повне посилання:** Raposo, D. et al. Mixture-of-Depths: Dynamically allocating compute in transformer-based language models. arXiv:2404.02258 (2024).  
**Першоджерело:** https://arxiv.org/abs/2404.02258  
**Інституція:** Google DeepMind  
**Клас доказу:** `B2_PRIMARY_REPORT`  
**Підтверджений факт:** A predefined top-k token capacity per layer makes total FLOPs predictable while token identities remain context-dependent; the authors report equivalent-quality configurations and up to 50% faster post-training sampling.  
**Значення для CWC:** Direct prior art for dynamic depth/allocation under a hard aggregate compute capacity.  
**Заборонене розширення твердження:** The budget is principally token-layer capacity, not CWC’s joint FLOPs/VRAM/energy/latency/bandwidth contract, and topology remains fixed.  
**Пов’язані claims:** CWC-CLM-004, CWC-CLM-008

### US-DEPTH-002 — Muennighoff, N

**Повне посилання:** Muennighoff, N. et al. s1: Simple test-time scaling. arXiv:2501.19393 (2025).  
**Першоджерело:** https://arxiv.org/abs/2501.19393  
**Інституція:** Stanford University / University of Washington  
**Клас доказу:** `B1_PRIMARY_REPORT_CODE`  
**Підтверджений факт:** Budget forcing controls inference-time reasoning length by terminating or extending generation, demonstrating that test-time compute can be an explicit controllable variable.  
**Значення для CWC:** Supports the executive requirement to allocate a bounded reasoning budget rather than always using fixed effort.  
**Заборонене розширення твердження:** Longer chains are not equivalent to better internal cognition; the method does not route experts, manage memory or alter topology.  
**Пов’язані claims:** CWC-CLM-004

### US-MEM-001 — Hwang, D

**Повне посилання:** Hwang, D. et al. TransformerFAM: Feedback attention is working memory. arXiv:2404.09173 (2024).  
**Першоджерело:** https://arxiv.org/abs/2404.09173  
**Інституція:** Google LLC, Mountain View, California  
**Клас доказу:** `B2_PRIMARY_REPORT`  
**Підтверджений факт:** Feedback Attention Memory feeds latent representations forward as a persistent working-memory state without adding model weights and reports long-context improvements at multiple model scales.  
**Значення для CWC:** Prior art for recurrent working memory M^W coupled to attention.  
**Заборонене розширення твердження:** The authors’ “unlimited” sequence framing is architectural, not a proof of lossless indefinite memory; it does not implement provenance or episodic consolidation.  
**Пов’язані claims:** CWC-CLM-005

### US-MEM-002 — Behrouz, A

**Повне посилання:** Behrouz, A., Zhong, P., & Mirrokni, V. Titans: Learning to Memorize at Test Time. arXiv:2501.00663 (2025).  
**Першоджерело:** https://arxiv.org/abs/2501.00663  
**Інституція:** Google Research  
**Клас доказу:** `B2_PRIMARY_REPORT`  
**Підтверджений факт:** Titans introduces a neural long-term memory updated at test time and combines it with attention; the authors report gains across language, reasoning, genomics and time-series tasks and tests beyond two million context tokens.  
**Значення для CWC:** Prior art for adaptive neural memory M^L whose state can change during inference.  
**Заборонене розширення твердження:** The source is an author report; it does not establish provenance-safe memory, bounded contamination, or independent replication of all headline results.  
**Пов’язані claims:** CWC-CLM-005, CWC-CLM-010

### US-MEM-003 — Packer, C

**Повне посилання:** Packer, C. et al. MemGPT: Towards LLMs as Operating Systems. arXiv:2310.08560 (2023).  
**Першоджерело:** https://arxiv.org/abs/2310.08560  
**Інституція:** University of California, Berkeley  
**Клас доказу:** `B1_PRIMARY_REPORT_CODE`  
**Підтверджений факт:** MemGPT manages fast in-context memory and slower external storage through explicit paging and interrupt-like control, enabling document and multi-session tasks beyond the base context window.  
**Значення для CWC:** Supports a typed hierarchical memory controller and explicit read/evict/write operations.  
**Заборонене розширення твердження:** This is an external orchestration layer around an LLM, not learned neural structural plasticity.  
**Пов’язані claims:** CWC-CLM-005, CWC-CLM-009

### US-PLAST-001 — Evci, U

**Повне посилання:** Evci, U. et al. Rigging the Lottery: Making All Tickets Winners. ICML/PMLR 119, 2943–2952 (2020).  
**Першоджерело:** https://arxiv.org/abs/1911.11134  
**Інституція:** Google Research / DeepMind  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** RigL trains a fixed-size sparse network while periodically replacing low-magnitude connections using gradient information, so topology changes during training without dense training cost.  
**Значення для CWC:** Strong prior art for grow/prune rewiring under a fixed parameter and compute envelope.  
**Заборонене розширення твердження:** RigL changes weight connectivity during training; it is not episodic semantic specialization, expert split/merge or safe online self-modification.  
**Пов’язані claims:** CWC-CLM-006, CWC-CLM-010

### US-PLAST-002 — Dai, X

**Повне посилання:** Dai, X., Yin, H., & Jha, N. K. NeST: A Neural Network Synthesis Tool Based on a Grow-and-Prune Paradigm. IEEE Transactions on Computers 68(10), 1487–1497 (2019).  
**Першоджерело:** https://arxiv.org/abs/1711.02017  
**Інституція:** Princeton University  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** NeST starts from a sparse seed, grows neurons/connections using gradients and prunes by magnitude, reporting large parameter and FLOP reductions on several image models.  
**Значення для CWC:** Prior art for explicit grow and prune operators over a persistent structural state.  
**Заборонене розширення твердження:** Compression benchmarks do not establish transfer, continual adaptation, cognitive modularity or safe rollback.  
**Пов’язані claims:** CWC-CLM-006

### US-PLAST-003 — Hassantabar, S

**Повне посилання:** Hassantabar, S., Wang, Z., & Jha, N. K. SCANN: Synthesis of Compact and Accurate Neural Networks. arXiv:1904.09090 (2019).  
**Першоджерело:** https://arxiv.org/abs/1904.09090  
**Інституція:** Princeton University  
**Клас доказу:** `B2_PRIMARY_REPORT`  
**Підтверджений факт:** SCANN iterates connection growth, neuron growth and connection pruning to synthesize feed-forward networks with arbitrary structure.  
**Значення для CWC:** Prior art for CWC structural operators grow, split-like capacity expansion and prune.  
**Заборонене розширення твердження:** SCANN does not route per-input active graphs or operate under a multi-resource executive contract.  
**Пов’язані claims:** CWC-CLM-006, CWC-CLM-009

### US-GROUND-001 — Driess, D

**Повне посилання:** Driess, D. et al. PaLM-E: An Embodied Multimodal Language Model. ICML/PMLR 202, 8469–8488 (2023).  
**Першоджерело:** https://arxiv.org/abs/2303.03378  
**Інституція:** Google Robotics / US partner institutions  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** PaLM-E interleaves language, vision and continuous state estimates in one model and reports positive transfer across embodied and visual-language tasks.  
**Значення для CWC:** Evidence that multimodal sensor states can be integrated with a language backbone and shared representations.  
**Заборонене розширення твердження:** Multimodality alone is not grounding; grounding requires verified coupling to environment state and action consequences.  
**Пов’язані claims:** CWC-CLM-007

### US-GROUND-002 — Brohan, A

**Повне посилання:** Brohan, A. et al. RT-2: Vision-Language-Action Models Transfer Web Knowledge to Robotic Control. CoRL/PMLR 229 (2023).  
**Першоджерело:** https://arxiv.org/abs/2307.15818  
**Інституція:** Google DeepMind / US partner institutions  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** RT-2 co-trains web vision-language data and robotic trajectories by representing actions as tokens; the authors report 6,000 evaluation trials and improved generalization to novel objects and instructions.  
**Значення для CWC:** Prior art for typed action outputs and feedback-coupled multimodal representations.  
**Заборонене розширення твердження:** Action tokenization does not provide CWC’s verifier, risk contract, rollback or autonomous topology adaptation.  
**Пов’язані claims:** CWC-CLM-007, CWC-CLM-009

### US-MEASURE-001 — Reddi, V

**Повне посилання:** Reddi, V. J. et al. MLPerf Inference Benchmark. arXiv:1911.02549 (2019).  
**Першоджерело:** https://arxiv.org/abs/1911.02549  
**Інституція:** MLCommons / multi-organization consortium  
**Клас доказу:** `A2_PRIMARY_BENCHMARK`  
**Підтверджений факт:** MLPerf defines architecture-neutral inference scenarios, quality constraints and reproducible measurement rules across heterogeneous systems.  
**Значення для CWC:** Basis for separating algorithmic claims from system-specific latency, throughput and hardware claims.  
**Заборонене розширення твердження:** MLPerf comparability depends on adhering to a specified workload and rules; it does not validate CWC cognition or scientific novelty.  
**Пов’язані claims:** CWC-CLM-008

### US-MEASURE-002 — Tschand, A

**Повне посилання:** Tschand, A. et al. MLPerf Power: Benchmarking the Energy Efficiency of Machine Learning Systems from Microwatts to Megawatts for Sustainable AI. arXiv:2410.12032 (2024).  
**Першоджерело:** https://arxiv.org/abs/2410.12032  
**Інституція:** MLCommons / multi-organization consortium  
**Клас доказу:** `A2_PRIMARY_BENCHMARK`  
**Підтверджений факт:** MLPerf Power defines synchronized system-level performance and energy measurement rules and reports 1,841 reproducible measurements across 60 systems.  
**Значення для CWC:** Supports actual joules-per-workload measurement rather than inferring energy from parameter count or FLOPs alone.  
**Заборонене розширення твердження:** Energy comparisons remain workload, hardware, software-stack and measurement-boundary dependent.  
**Пов’язані claims:** CWC-CLM-008

### US-GOV-001 — National Institute of Standards and Technology

**Повне посилання:** National Institute of Standards and Technology. Artificial Intelligence Risk Management Framework (AI RMF 1.0), NIST AI 100-1 (2023).  
**Першоджерело:** https://doi.org/10.6028/NIST.AI.100-1  
**Інституція:** NIST  
**Клас доказу:** `S1_PRIMARY_STANDARD`  
**Підтверджений факт:** AI RMF structures risk work into Govern, Map, Measure and Manage functions and requires contextual, lifecycle-oriented risk treatment.  
**Значення для CWC:** Supports CWC governance, evidence boundaries, risk mapping and fail-closed release gates.  
**Заборонене розширення твердження:** AI RMF is a voluntary risk framework, not an empirical validation of any architecture.  
**Пов’язані claims:** CWC-CLM-008


## Китай / китайська дослідницька екосистема
### CN-MOE-001 — Dai, D

**Повне посилання:** Dai, D. et al. DeepSeekMoE: Towards Ultimate Expert Specialization in Mixture-of-Experts Language Models. arXiv:2401.06066 (2024).  
**Першоджерело:** https://arxiv.org/abs/2401.06066  
**Інституція:** DeepSeek-AI  
**Клас доказу:** `B1_PRIMARY_REPORT_CODE`  
**Підтверджений факт:** DeepSeekMoE uses fine-grained expert segmentation and shared-expert isolation; the authors report a 2B model comparable to a larger GShard baseline with less expert compute.  
**Значення для CWC:** Direct basis for shared experts plus fine-grained routed experts and explicit redundancy control.  
**Заборонене розширення твердження:** Expert specialization is measured within the reported tasks; it does not establish persistent expert identity, topology plasticity or CWC-level transfer.  
**Пов’язані claims:** CWC-CLM-002

### CN-MOE-002 — DeepSeek-AI

**Повне посилання:** DeepSeek-AI. DeepSeek-V2: A Strong, Economical, and Efficient Mixture-of-Experts Language Model. arXiv:2405.04434 (2024).  
**Першоджерело:** https://arxiv.org/abs/2405.04434  
**Інституція:** DeepSeek-AI  
**Клас доказу:** `B1_PRIMARY_REPORT_CODE`  
**Підтверджений факт:** DeepSeek-V2 combines DeepSeekMoE with Multi-head Latent Attention; the report states 236B total parameters, 21B activated per token, 128K context, 93.3% KV-cache reduction and higher generation throughput relative to DeepSeek 67B.  
**Значення для CWC:** Evidence for jointly reducing active expert compute and decode memory-bandwidth pressure.  
**Заборонене розширення твердження:** All percentages are source-reported against a specific internal baseline and stack; they must not be transferred to CWC without replication.  
**Пов’язані claims:** CWC-CLM-002, CWC-CLM-003, CWC-CLM-008

### CN-MOE-003 — DeepSeek-AI

**Повне посилання:** DeepSeek-AI. DeepSeek-V3 Technical Report. arXiv:2412.19437 (2024).  
**Першоджерело:** https://arxiv.org/abs/2412.19437  
**Інституція:** DeepSeek-AI  
**Клас доказу:** `B1_PRIMARY_REPORT_CODE`  
**Підтверджений факт:** DeepSeek-V3 reports 671B total and 37B activated parameters per token, MLA, DeepSeekMoE, auxiliary-loss-free load balancing and multi-token prediction.  
**Значення для CWC:** Prior art for large-scale sparse routing, router balancing without a conventional auxiliary loss and efficient decode architecture.  
**Заборонене розширення твердження:** A stable large-scale training run does not imply self-restructuring, causal expert modularity or independent validation of all cost claims.  
**Пов’язані claims:** CWC-CLM-002, CWC-CLM-008

### CN-ATTN-001 — Yuan, J

**Повне посилання:** Yuan, J. et al. Native Sparse Attention: Hardware-Aligned and Natively Trainable Sparse Attention. arXiv:2502.11089 (2025).  
**Першоджерело:** https://arxiv.org/abs/2502.11089  
**Інституція:** DeepSeek-AI / Peking University  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** NSA combines coarse token compression, fine-grained selection and local attention in an end-to-end trainable, hardware-aligned sparse mechanism; the authors report lifecycle speedups on 64K sequences while maintaining benchmark quality.  
**Значення для CWC:** Strong prior art for a hierarchical sparse route with explicit hardware co-design.  
**Заборонене розширення твердження:** NSA routes attention positions, not heterogeneous cognitive modules or persistent structural state.  
**Пов’язані claims:** CWC-CLM-001, CWC-CLM-003, CWC-CLM-008

### CN-DEPTH-001 — Liu, Y

**Повне посилання:** Liu, Y., Meng, F., Zhou, J., Chen, Y., & Xu, J. Faster Depth-Adaptive Transformers. AAAI 35(15), 13424–13432 (2021).  
**Першоджерело:** https://doi.org/10.1609/aaai.v35i15.17584  
**Інституція:** Beijing Jiaotong University / Tencent WeChat AI  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** The method predicts required word-level depth in advance from hardness signals rather than relying on a sequential halting unit; the authors report up to 7× speedup on classification tasks while preserving high accuracy.  
**Значення для CWC:** Prior art for executive depth selection based on estimated task hardness.  
**Заборонене розширення твердження:** The result is task-specific and does not implement multi-objective budget enforcement or topology rewiring.  
**Пов’язані claims:** CWC-CLM-004

### CN-DEPTH-002 — Yang, A

**Повне посилання:** Yang, A. et al. Qwen3 Technical Report. arXiv:2505.09388 (2025).  
**Першоджерело:** https://arxiv.org/abs/2505.09388  
**Інституція:** Alibaba Qwen Team  
**Клас доказу:** `B1_PRIMARY_REPORT_WEIGHTS`  
**Підтверджений факт:** Qwen3 unifies thinking and non-thinking modes and exposes a thinking-budget mechanism for latency–quality control during inference; the family includes dense and MoE variants.  
**Значення для CWC:** Direct prior art for externally constrained reasoning effort and mode selection.  
**Заборонене розширення твердження:** A token budget is not the same as learned allocation across FLOPs, memory, energy, bandwidth, experts and topology.  
**Пов’язані claims:** CWC-CLM-002, CWC-CLM-004

### CN-REASON-001 — DeepSeek-AI

**Повне посилання:** DeepSeek-AI. DeepSeek-R1: Incentivizing Reasoning Capability in LLMs via Reinforcement Learning. arXiv:2501.12948 (2025).  
**Першоджерело:** https://arxiv.org/abs/2501.12948  
**Інституція:** DeepSeek-AI  
**Клас доказу:** `B1_PRIMARY_REPORT_WEIGHTS`  
**Підтверджений факт:** The report shows that reinforcement learning can strongly alter reasoning behavior and documents both gains and failure modes such as readability and language mixing in the R1-Zero stage.  
**Значення для CWC:** Supports treating reasoning policy and verifier/reward design as trainable control problems rather than fixed prompting only.  
**Заборонене розширення твердження:** Benchmark reasoning gains do not define a correct general value function, do not prove robust out-of-distribution agency and do not imply topology adaptation.  
**Пов’язані claims:** CWC-CLM-004, CWC-CLM-010

### CN-MEM-001 — Wang, W

**Повне посилання:** Wang, W. et al. Augmenting Language Models with Long-Term Memory. arXiv:2306.07174 (2023).  
**Першоджерело:** https://arxiv.org/abs/2306.07174  
**Інституція:** Microsoft Research Asia  
**Клас доказу:** `B1_PRIMARY_REPORT_CODE`  
**Підтверджений факт:** LongMem freezes the backbone as a memory encoder and trains a residual side network for memory retrieval/reading; the authors report 65K long-form memory and gains on long-context and memory-augmented in-context learning tasks.  
**Значення для CWC:** Prior art for decoupled long-term memory that can be updated without rewriting the core model.  
**Заборонене розширення твердження:** The memory system is not a complete provenance-governed hierarchy and does not adapt persistent network topology.  
**Пов’язані claims:** CWC-CLM-005

### CN-MEM-002 — Zhong, W

**Повне посилання:** Zhong, W. et al. MemoryBank: Enhancing Large Language Models with Long-Term Memory. arXiv:2305.10250 (2023).  
**Першоджерело:** https://arxiv.org/abs/2305.10250  
**Інституція:** Chinese academic/corporate research team  
**Клас доказу:** `B2_PRIMARY_REPORT`  
**Підтверджений факт:** MemoryBank provides explicit storage, retrieval, update, reinforcement and forgetting rules for long-term conversational memory.  
**Значення для CWC:** Prior art for memory lifecycle operations, including selective forgetting.  
**Заборонене розширення твердження:** Its human-memory analogy and simulated-dialogue evaluation do not prove biological fidelity, general cognition or contamination resistance.  
**Пов’язані claims:** CWC-CLM-005

### CN-ATTN-002 — Ding, J

**Повне посилання:** Ding, J. et al. LongNet: Scaling Transformers to 1,000,000,000 Tokens. arXiv:2307.02486 (2023).  
**Першоджерело:** https://arxiv.org/abs/2307.02486  
**Інституція:** Microsoft Research Asia / Chinese partner university  
**Клас доказу:** `B2_PRIMARY_REPORT`  
**Підтверджений факт:** Dilated attention expands receptive fields exponentially with distance, yielding linear complexity and logarithmic dependency paths in the proposed construction.  
**Значення для CWC:** Prior art for hierarchical local-to-distant connectivity over very long sequences.  
**Заборонене розширення твердження:** The one-billion-token statement is an architectural scaling claim; it is not evidence of exact recall, bounded memory quality or CWC topology learning.  
**Пов’язані claims:** CWC-CLM-001, CWC-CLM-003

### CN-PLAST-001 — Guo, Y

**Повне посилання:** Guo, Y., Yao, A., & Chen, Y. Dynamic Network Surgery for Efficient DNNs. NeurIPS (2016).  
**Першоджерело:** https://arxiv.org/abs/1608.04493  
**Інституція:** Chinese research team  
**Клас доказу:** `A1_PEER_REVIEWED_PRIMARY`  
**Підтверджений факт:** Dynamic Network Surgery alternates connection pruning and splicing during training so incorrectly removed connections can return; the paper reports large compression factors without accuracy loss on its evaluated models.  
**Значення для CWC:** Prior art for reversible prune/regrow behavior and for rejecting irreversible one-shot pruning.  
**Заборонене розширення твердження:** Splicing weights is not semantic module growth, expert merge/split, episodic governance or safe autonomous self-modification.  
**Пов’язані claims:** CWC-CLM-006, CWC-CLM-010

### CN-MM-001 — Bai, S

**Повне посилання:** Bai, S. et al. Qwen2.5-VL Technical Report. arXiv:2502.13923 (2025).  
**Першоджерело:** https://arxiv.org/abs/2502.13923  
**Інституція:** Alibaba Qwen Team  
**Клас доказу:** `B1_PRIMARY_REPORT_WEIGHTS`  
**Підтверджений факт:** Qwen2.5-VL uses native dynamic-resolution vision processing, window attention and absolute time encoding for images, documents and long video; the report also demonstrates tool-oriented visual-agent tasks.  
**Значення для CWC:** Evidence for modality-dependent token budgets, local visual attention and temporal alignment.  
**Заборонене розширення твердження:** Tool use and multimodal benchmarks do not establish verified environment grounding or a unified adaptive topology.  
**Пов’язані claims:** CWC-CLM-003, CWC-CLM-007

### CN-MM-002 — Xu, J

**Повне посилання:** Xu, J. et al. Qwen2.5-Omni Technical Report. arXiv:2503.20215 (2025).  
**Першоджерело:** https://arxiv.org/abs/2503.20215  
**Інституція:** Alibaba Qwen Team  
**Клас доказу:** `B1_PRIMARY_REPORT_WEIGHTS`  
**Підтверджений факт:** Qwen2.5-Omni processes text, image, audio and video, aligns audio-video time, uses block-wise encoders and separates reasoning/text generation from streaming speech generation through a Thinker–Talker architecture.  
**Значення для CWC:** Prior art for typed multimodal encoders, cross-modal temporal alignment and specialized output modules.  
**Заборонене розширення твердження:** The architecture is designed, not self-rewired; multimodal integration does not by itself prove transfer or agency.  
**Пов’язані claims:** CWC-CLM-007, CWC-CLM-009

### CN-MM-003 — Bai, S

**Повне посилання:** Bai, S. et al. Qwen3-VL Technical Report. arXiv:2511.21631 (2025).  
**Першоджерело:** https://arxiv.org/abs/2511.21631  
**Інституція:** Alibaba Qwen Team  
**Клас доказу:** `B1_PRIMARY_REPORT_WEIGHTS`  
**Підтверджений факт:** Qwen3-VL reports dense and MoE variants, native 256K interleaved multimodal context, multi-level visual feature integration and explicit latency–quality trade-offs.  
**Значення для CWC:** Shows multimodality, MoE sparsity and deployment trade-offs can coexist in one model family.  
**Заборонене розширення твердження:** It does not provide CWC’s joint graph-memory-depth-topology controller or structural plasticity.  
**Пов’язані claims:** CWC-CLM-002, CWC-CLM-007, CWC-CLM-009

### CN-MM-004 — Wang, P

**Повне посилання:** Wang, P. et al. Qwen2-VL: Enhancing Vision-Language Model’s Perception of the World at Any Resolution. arXiv:2409.12191 (2024).  
**Першоджерело:** https://arxiv.org/abs/2409.12191  
**Інституція:** Alibaba Qwen Team  
**Клас доказу:** `B1_PRIMARY_REPORT_WEIGHTS`  
**Підтверджений факт:** Qwen2-VL maps variable-resolution inputs to variable numbers of visual tokens, making modality-side compute depend on input resolution.  
**Значення для CWC:** Prior art for adaptive input representation size and modality-aware resource allocation.  
**Заборонене розширення твердження:** Variable tokenization is not executive reasoning-depth control or persistent graph adaptation.  
**Пов’язані claims:** CWC-CLM-003, CWC-CLM-007

---

## 5. Claim-to-source matrix

### CWC-CLM-001 — `SUPPORTED_COMPONENT`

**Твердження:** Local clustering combined with sparse long-range/global links is a valid graph design family for reducing connection density while preserving short information paths.  
**Першоджерела:** US-TOP-001, US-TOP-002, US-ATTN-001, US-ATTN-002, CN-ATTN-001, CN-ATTN-002  
**Межа:** This supports a candidate topology family, not automatic emergence, universal optimality or biological equivalence.  
**Обов’язковий локальний доказ:** topology metrics against degree-matched controls, hardware-grounded wiring cost, task-quality ablation.

### CWC-CLM-002 — `SUPPORTED_COMPONENT`

**Твердження:** Conditional expert routing can increase model capacity while keeping per-token active computation sparse.  
**Першоджерела:** US-MOE-001, US-MOE-002, US-MOE-003, CN-MOE-001, CN-MOE-002, CN-MOE-003, CN-DEPTH-002, CN-MM-003  
**Межа:** Sparse activation may increase communication, memory and routing instability; it is not structural plasticity.  
**Обов’язковий локальний доказ:** activated-parameter accounting, all-to-all bytes, expert utilization entropy, quality-matched dense baseline.

### CWC-CLM-003 — `SUPPORTED_COMPONENT`

**Твердження:** Sparse and hierarchical attention can reduce long-sequence compute/memory relative to full attention.  
**Першоджерела:** US-ATTN-001, US-ATTN-002, CN-ATTN-001, CN-ATTN-002, CN-MOE-002, CN-MM-001, CN-MM-004  
**Межа:** Theoretical complexity does not guarantee wall-clock or energy benefit on a given kernel/hardware stack.  
**Обов’язковий локальний доказ:** wall-clock profiling, peak VRAM, joules, quality at matched context and hardware.

### CWC-CLM-004 — `SUPPORTED_COMPONENT`

**Твердження:** Inference effort can be allocated dynamically by token, layer, mode or reasoning budget.  
**Першоджерела:** US-DEPTH-001, US-DEPTH-002, CN-DEPTH-001, CN-DEPTH-002, CN-REASON-001  
**Межа:** Extra or adaptive compute does not guarantee monotonic quality and is not a complete value function.  
**Обов’язковий локальний доказ:** utility gain per incremental compute, hard budget compliance, early-exit error analysis, OOD evaluation.

### CWC-CLM-005 — `SUPPORTED_COMPONENT`

**Твердження:** Working, external and neural long-term memory mechanisms can be separated and updated through distinct control paths.  
**Першоджерела:** US-MEM-001, US-MEM-002, US-MEM-003, CN-MEM-001, CN-MEM-002  
**Межа:** Memory capacity, fidelity, provenance, contamination and forgetting remain separate empirical problems.  
**Обов’язковий локальний доказ:** retention curves, interference tests, provenance audit, deletion verification, contamination red-team.

### CWC-CLM-006 — `SUPPORTED_COMPONENT`

**Твердження:** Persistent network connectivity can be changed through grow, prune and regrow operations during training.  
**Першоджерела:** US-PLAST-001, US-PLAST-002, US-PLAST-003, CN-PLAST-001  
**Межа:** Existing results mainly optimize compression/training; they do not prove safe continual cognitive self-restructuring.  
**Обов’язковий локальний доказ:** operator-specific ablations, rollback test, structural oscillation test, transfer and forgetting metrics.

### CWC-CLM-007 — `SUPPORTED_COMPONENT`

**Твердження:** Language representations can be coupled with vision, audio, continuous state and action outputs in shared or coordinated model systems.  
**Першоджерела:** US-GROUND-001, US-GROUND-002, CN-MM-001, CN-MM-002, CN-MM-003, CN-MM-004  
**Межа:** Multimodal input is not sufficient for grounding; grounding requires causal linkage to observed state and verified action consequences.  
**Обов’язковий локальний доказ:** environment-state consistency, action success, counterfactual grounding tests, tool/result verification.

### CWC-CLM-008 — `METHODOLOGICAL_REQUIREMENT`

**Твердження:** Efficiency claims require workload-defined, hardware-normalized measurements of latency, throughput, memory, communication and energy.  
**Першоджерела:** US-MOE-003, US-MEASURE-001, US-MEASURE-002, US-GOV-001, US-TOP-002, CN-MOE-002, CN-MOE-003, CN-ATTN-001  
**Межа:** No single scalar captures all resource trade-offs; Pareto reporting is required.  
**Обов’язковий локальний доказ:** hardware manifest, power sampling protocol, quality constraint, confidence intervals, raw trace publication.

### CWC-CLM-009 — `PRIOR_ART_GAP_HYPOTHESIS`

**Твердження:** No source in this curated corpus jointly controls active module routing, hierarchical memory access, adaptive depth and persistent topology under one hard multi-resource budget.  
**Першоджерела:** US-MOE-001, US-ATTN-002, US-MEM-003, US-PLAST-003, US-GROUND-002, CN-MM-002, CN-MM-003  
**Межа:** Corpus non-observation is not proof of global non-existence. The claim remains HYPOTHESIS until a documented systematic prior-art review is frozen and externally challenged.  
**Обов’язковий локальний доказ:** search protocol hash, inclusion/exclusion log, expert review, updated novelty matrix.

### CWC-CLM-010 — `OPEN_RESEARCH_PROBLEM`

**Твердження:** Safe online structural adaptation requires utility estimation, stability criteria, bounded operators, rollback and evidence-gated promotion.  
**Першоджерела:** US-MEM-002, US-PLAST-001, CN-PLAST-001, CN-REASON-001  
**Межа:** The cited works demonstrate pieces or failure modes, not the complete CWC structural governance loop.  
**Обов’язковий локальний доказ:** counterfactual structural proposal evaluation, stability window, rollback witness, independent replay.

---

## 6. Канонічний висновок prior-art

### 6.1 Уже доведено окремо

Першоджерела підтверджують життєздатність таких окремих механізмів:

- локально-глобальна sparse connectivity;
- content-dependent sparse attention;
- sparse Mixture-of-Experts;
- compute/depth/thinking-budget control;
- working, external і neural long-term memory;
- grow/prune/regrow connectivity;
- мультимодальне представлення та action tokenization;
- системне вимірювання latency, throughput, memory, communication і energy.

### 6.2 Не доведено цим корпусом

Жодне включене першоджерело не демонструє одночасно:

\[
G_t=\Pi_	heta(x_t,M_t,S_t,B_t),
\qquad
S_{t+1}=\Phi(S_t,\Delta U_t,
ho_t,B_t)
\]

де один замкнений executive-контур:

1. вибирає активний гетерогенний підграф;
2. розподіляє depth і compute;
3. керує багаторівневою пам’яттю;
4. змінює persistent structural state;
5. виконує це під жорсткими FLOPs, VRAM, latency, energy та bandwidth budgets;
6. допускає structural promotion лише через stability, counterfactual evaluation і rollback evidence.

Це є **обґрунтованою межею поточного корпусу**, але не математичним доказом відсутності такої системи у всій світовій літературі.

### 6.3 Валідне формулювання новизни

> CWC висуває перевірювану гіпотезу про замкнену кооптимізацію активного графа, пам’яті, глибини та довготривалої структури під єдиним жорстким багаторесурсним контрактом. Оригінальність синтезу залишається `HYPOTHESIS` до замороженого systematic prior-art review, реалізації, ablation matrix, Pareto-доказу й незалежного відтворення.

### 6.4 Заборонені claims

На підставі цієї бібліографії заборонено стверджувати, що:

- CWC уже перевершив Transformer або MoE;
- CWC є моделлю мозку;
- small-world topology гарантовано виникне;
- sparse execution автоматично зменшує енергію;
- довший reasoning завжди підвищує точність;
- мультимодальність автоматично створює grounding;
- structural rewiring автоматично забезпечує continual learning;
- відсутність аналога у цьому корпусі доводить світову абсолютну новизну.

## 7. Протокол оновлення

Кожне нове джерело MUST мати унікальний ID, первинний URL, evidence tier, підтверджений факт, CWC mapping і boundary. Нове джерело MUST NOT автоматично підвищувати claim. Claim promotion дозволяється лише після локального evidence bundle.

## 8. Пошуковий журнал

**Дата зрізу:** 2026-07-15.  
**Первинні поверхні:** Nature, Neuron/Cell Press, JMLR, PMLR/ICML/CoRL, NeurIPS, AAAI, ACL/TACL, arXiv author reports, NIST, MLCommons.  
**Сімейства запитів:** small-world/wiring optimization; sparse attention; conditional computation/MoE; adaptive depth/test-time compute; working/long-term memory; grow-prune-regrow; multimodal embodiment/action; reproducible latency/energy benchmarking.  
**Обмеження:** пошук не охоплює закриті внутрішні системи, неопубліковані патенти, документи без індексації та неангломовні матеріали без доступного первинного запису.

⊛
