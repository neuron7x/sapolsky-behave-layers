# ADR-0004: Structural Plasticity Only at Declared Boundaries

Status: accepted

## Decision

Topology rewiring is allowed only between phases or inside an explicitly preregistered test-time adaptation protocol.

## Rationale

Uncontrolled online rewiring prevents deterministic evaluation and makes causal attribution impossible.
