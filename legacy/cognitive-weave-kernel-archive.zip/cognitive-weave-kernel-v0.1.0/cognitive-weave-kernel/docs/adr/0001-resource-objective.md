# ADR-0001: Multi-Resource Objective as Canonical Authority

Status: accepted for canonical candidate

## Decision

CWK SHALL optimize and report a metric vector rather than model quality alone. A normalized scalar objective may guide training, but release decisions use Pareto dominance and protected metric thresholds.

## Rationale

Optimizing only task loss can hide increased communication, memory or latency. Optimizing only FLOPs can move cost to memory traffic or synchronization. The architecture therefore treats resource use as first-class evidence.

## Consequences

Every component must expose telemetry. Benchmarks lacking resource accounting cannot validate the central thesis.
