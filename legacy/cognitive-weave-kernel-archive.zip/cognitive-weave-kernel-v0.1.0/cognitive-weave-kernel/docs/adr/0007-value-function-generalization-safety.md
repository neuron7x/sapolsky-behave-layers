# ADR-0007: Value Function — Generalization and Capability-Threshold Gating

Status: accepted

## Context

CWC-SPEC-001 §12.1 defines a utility vector `U = (Q_task, Q_transfer, Q_adapt, Q_robust, Q_agency)`.
`Q_task` is operationalized through baseline comparison (§15-16). `Q_transfer`, `Q_adapt`, `Q_robust`
and `Q_agency` were named but not operationally defined — a named-but-empty slot in a formal
objective is not a hypothesis, it is a placeholder. This ADR closes that gap using two external
reference points, neither of which is a CWC primary source and neither of which is treated as one.

**Sutskever's generalization thesis** (public statements, 2025-2026; not a peer-reviewed primary
source — see boundary below): the central bottleneck in current systems is not benchmark
performance but the gap between eval-shaped behavior and judgment in situations outside the
training distribution — what he calls a missing "value function" for generalization. A system
can memorize a task distribution while still failing basic judgment calls a human would not make
in a genuinely novel situation.

**Amodei's scaling-safety discipline** (Responsible Scaling Policy, public essays 2024-2026; not a
peer-reviewed primary source): two structural commitments matter here independent of any
particular safety conclusion. First, capability thresholds gate additional safety measures
*before* a more capable configuration is deployed, not after — a precondition, not a
post-hoc penalty. Second, values and preferences must themselves generalize, and verifying that
requires inspecting internal computation (mechanistic interpretability), not scoring external
behavior alone.

## Decision

`Q_transfer`, `Q_adapt`, `Q_robust` and `Q_agency` are operationally defined as follows. Each
definition is a measurement protocol, not a claim that CWC satisfies it.

### Q_transfer

```text
Q_transfer = perf(D_ood) - perf(D_id)   under identical B_t
```

Measured under a preregistered out-of-distribution task set disjoint from training and validation
splits. A positive `Q_transfer` with degraded `Q_task` is not a win; both must be reported.

### Q_adapt

Rate and stability of improvement under the Structural Plasticity Cycle (CHARTER §6.6,
CWC-SPEC-001 §10) when exposed to a task-distribution shift *within* an episode boundary, bounded
by the same rollback and provenance requirements already mandated for `Φ_ψ`. `Q_adapt` is reported
jointly with structural churn (§10, invariant 6) — fast adaptation achieved by unstable rewiring is
a fault, not a result.

### Q_robust

Not raw performance robustness — *behavioral* robustness under distribution shift: whether the
system's routing, memory-write and action decisions remain within the same declared safety
envelope (CHARTER §6.10 Claim Firewall boundaries, ARCHITECTURE §9 budget invariants) when inputs
move off-distribution. A model that stays accurate but silently exceeds `B_t` or writes
unprovenanced memory under shift fails `Q_robust` regardless of `Q_task`.

### Q_agency

Defined only for `action` nodes (CHARTER §6.8, CWC-SPEC-001 §5.6). `Q_agency` requires that every
action-node decision above a preregistered autonomy threshold produce a verifier trace
(CWC-SPEC-001 §5.5, `T_t` in §4.3) that is inspectable at the routing/activation level, not only
scored on outcome. An action that "worked" without an inspectable trace does not count toward
`Q_agency`.

## New invariant: Capability-Threshold Gate

Added to CHARTER Article 5 (architectural invariants) as invariant 11:

> **Capability-Threshold Gate:** any structural plasticity operator (§10: grow, split, merge) or
> routing configuration that increases `V_t` (active node count), `max_active_experts`, or
> `D_t` (depth ceiling) beyond a preregistered threshold MUST NOT be enabled for evaluation until
> `Q_robust` and `Q_agency` are measured at that threshold and pass their preregistered bounds.
> This is a precondition, not a post-hoc penalty term in `J` or `U−λC` — consistent with
> §3.1 Budget-first and Article 4's prohibition on scalar concealment.

This is structurally identical to Budget-first (§3.1): a ceiling checked before execution, not a
cost added after. The Capability-Threshold Gate extends that same discipline from resource budget
to behavioral-safety budget.

## Implementation

This ADR is reified, not left as prose: `schemas/value_function.schema.json` defines the
machine-checkable report contract, `src/cwk/value_function.py::evaluate_capability_threshold_gate`
enforces the semantic gate (threshold-crossing consistency, compute-matched `Q_transfer`, churn-bounded
`Q_adapt`, safety-envelope-clean and inspectable-trace-backed `Q_robust`/`Q_agency`), and
`scripts/check_value_function_report.py` / `make value-function-verify` expose it as a fail-closed
CLI and CI gate. A report claiming `gate_decision: PASS` while its own measured fields fail the
gate condition is rejected — the report cannot grade its own homework. See
`tests/test_value_function_gate.py`.

## Boundary

This ADR does not certify CWC's alignment, safety or generalization. It defines what would have to
be measured for `CWC-CLM-009` (prior-art gap hypothesis) and `CWC-CLM-010` (open research problem)
to move from `HYPOTHESIS` toward `OBSERVED` on the transfer/robustness/agency axes specifically.
Citing Sutskever's or Amodei's public statements as motivation is not the same as citing them as
evidence tier `A1`/`B1` sources in `docs/claim_source_matrix.json` — CLAIMS.md records these as
`UNSOURCED_DESIGN_CHOICE`, and research/CLAIM_POLICY.md's forbidden-transformation list applies:
a public essay does not become a peer-reviewed primary source by being well-argued. The gate
implementation validates internal consistency of a *reported* measurement; it cannot verify that
the underlying experiment (OOD split, safety-envelope check, verifier trace) was actually run
honestly — that remains an evidence-provenance requirement (CHARTER §6.9 Evidence Spine), not
something a JSON Schema can enforce.
