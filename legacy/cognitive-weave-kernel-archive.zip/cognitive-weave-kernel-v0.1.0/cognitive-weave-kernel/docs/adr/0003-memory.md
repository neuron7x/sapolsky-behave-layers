# ADR-0003: Provenance-Bounded Episodic Memory First

Status: accepted

## Decision

The first kernel uses a bounded key–value episodic memory with explicit writes. Trainable test-time memory is deferred until retrieval utility and state isolation are validated.

## Rationale

Introducing mutable neural parameters at inference would confound routing, memory and plasticity effects. A simpler memory provides a falsifiable baseline.
