# ADR-0002: Shared Expert plus Top-K Routed Experts

Status: accepted for reference implementation

## Decision

Each routed block contains one shared expert and multiple Top-K routed experts. The router may use a non-gradient load bias. Overflow triggers a declared fallback path.

## Alternatives rejected

- Top-1 only: simpler but fragile during early specialization.
- Fully dense experts: violates conditional-computation test.
- Hard expert exclusivity: risks knowledge fragmentation.

## Validation

Measure utilization entropy, overflow, route churn, shared-path contribution and task/resource outcomes.
