# ADR-0006: Local-First Causal Validation Before Scale

Status: accepted

## Decision

The canonical programme begins with locally executable models and synthetic causal tasks. Scaling is permitted only after component value is isolated.

## Rationale

Large-scale results can conceal confounds, make ablations unaffordable and transform architecture research into compute competition.
