# ADR-0005: Neuroscience as Constraint, Not Equivalence

Status: accepted

## Decision

Neuroscience sources motivate economy, modularity, hierarchy and plasticity hypotheses. No component may be described as a faithful brain implementation without direct mechanistic validation.
