# Local Execution Standard

## Supported start profile

- Python 3.11–3.13;
- CPU execution supported;
- CUDA optional;
- no network required for tests or smoke run after dependencies are installed;
- reference scale intended for a single workstation.

## Bootstrap

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[dev]'
make verify
```

## Determinism

The smoke runner fixes Python and PyTorch seeds and uses one CPU thread. Production experiments must additionally freeze accelerator, library, deterministic-algorithm and distributed settings.

## Evidence

```bash
python -m cwk.cli smoke \
  --config configs/smoke.yaml \
  --output evidence/runs/local-smoke
```

Inspect `manifest.json`, `environment.json`, `config.resolved.json` and `metrics.json` before treating the run as valid.

## Current implementation boundary

The repository validates architecture contracts and basic execution. It does not yet provide optimized sparse kernels, large-scale pretraining, external datasets or a validated advantage over baselines.
