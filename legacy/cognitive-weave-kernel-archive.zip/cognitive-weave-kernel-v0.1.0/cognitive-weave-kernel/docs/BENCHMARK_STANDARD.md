# Benchmark Standard

## Benchmark classes

### Mechanism benchmarks

Isolate one component. Use synthetic or controlled tasks where the required dependency is known.

### Integration benchmarks

Measure component interactions with factorial ablations. Report interaction effects, not only final model ranking.

### System benchmarks

Measure end-to-end quality, latency, throughput, memory and robustness on realistic workloads.

### Safety and governance benchmarks

Test evidence tampering, state leakage, invalid budgets, corrupted topology, malicious memory and tool-permission violations.

## Resource matching

Every comparison SHALL state which quantity is matched:

- total parameters;
- activated parameters;
- training FLOPs;
- inference FLOPs;
- wall time;
- accelerator-hours;
- memory capacity;
- data tokens.

“Efficient” is invalid without at least one matched comparison and the complete cost vector.

## Required distributions

Report median, confidence interval and tail behavior. For routing, report per-expert and per-group distributions rather than only averages.

## Minimum benchmark bundle

```text
protocol.yaml
frozen_config.yaml
data_manifest.json
baseline_matrix.csv
raw_metrics.jsonl
summary.json
plots/
failures.jsonl
environment.json
artifact_hashes.txt
```

## Contamination control

For public language benchmarks, document training-data uncertainty, use fresh or generated holdouts where possible, and avoid interpreting memorized answers as reasoning.
