# Interface Contracts

## Activation Budget Contract

Hard fields are ceilings. Soft fields are optimization targets. Components SHALL reject impossible contracts before execution.

```yaml
hard:
  active_experts: 2
  attention_density: 0.25
  memory_reads: 4
  memory_writes: 8
  depth: 12
  peak_memory_bytes: 4000000000
soft:
  p95_latency_ms: 100
  communication_bytes: 2000000
```

## Route Decision Contract

A route decision is valid only when:

- indices are in range;
- weights are finite, non-negative and sum to one per routed unit;
- selected count does not exceed budget;
- overflow and fallback are explicit;
- router and topology versions are recorded.

## Memory Contract

A memory read SHALL disclose query count, selected trace identifiers, similarity or retrieval score, total bytes and latency. A write SHALL disclose source, retention class and deletion policy. Evaluation state must be reset between independent samples unless continuity is the task.

## Topology Contract

A topology artifact contains:

```text
schema_version
node catalogue
edge catalogue
cost model
constraints
parent hash
current hash
created by
validation report
```

## Evidence Contract

An evidence bundle is complete only if all referenced artifacts exist and hash correctly. Logs are evidence but not a substitute for machine-readable metrics.
