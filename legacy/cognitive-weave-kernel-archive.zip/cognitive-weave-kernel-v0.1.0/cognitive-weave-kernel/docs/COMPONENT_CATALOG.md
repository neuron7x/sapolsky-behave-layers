# Component Catalogue

## C01 — World Coupling Port

**Responsibility:** translate external observations and actions into typed packets.  
**Inputs:** modality payload, source, permissions, time.  
**Outputs:** validated `CognitivePacket`.  
**Forbidden:** implicit tool permission, modality erasure, unaudited action.  
**Metrics:** validation failures, missing provenance, action rollback success.

## C02 — Input Encoder

**Responsibility:** map modality-specific packets into a shared computational width while retaining modality and source tags.  
**Failure modes:** representation collapse, token explosion, source-tag loss.  
**Acceptance:** deterministic shape, explicit mask, modality ablation report.

## C03 — Adaptive Cognitive Fabric

**Responsibility:** declare allowed communication and its cost.  
**State:** nodes, edge types, weights, coordinates, version, hash.  
**Failure modes:** disconnected task path, uncontrolled density, hidden topology mutation.  
**Metrics:** density, weighted path length, wiring proxy, communication bytes, robustness under edge removal.

## C04 — Sparse Communication Operator

**Responsibility:** execute communication constrained by the fabric.  
**Variants:** masked attention, block sparse attention, linear recurrent operator, graph message passing.  
**Acceptance:** semantic equivalence test, density accounting, backend disclosure.  
**Critical distinction:** algorithmic sparsity is not hardware speedup.

## C05 — Transit Governor

**Responsibility:** select experts and paths under budget.  
**Inputs:** token state, task state, budget, load state.  
**Outputs:** `RouteDecision`.  
**Failure modes:** collapse, oscillation, overflow, token drop, confidence miscalibration.  
**Metrics:** utilization entropy, route entropy, churn, overflow, fallback, mutual information with task factors.

## C06 — Shared Expert

**Responsibility:** provide universal residual computation and prevent complete fragmentation.  
**Acceptance:** always reachable, independently ablatable, capacity accounted.

## C07 — Routed Expert Bank

**Responsibility:** provide conditional specialized transformations.  
**Failure modes:** redundancy, dead experts, overspecialization, language or group routing collapse.  
**Metrics:** activation, intervention effect, representation similarity, transfer, worst-group utilization.

## C08 — Working Memory

**Responsibility:** preserve bounded active state within an episode.  
**Failure modes:** uncontrolled growth, leakage across samples, state aliasing.  
**Metrics:** bytes, read/write count, retention accuracy, reset correctness.

## C09 — Episodic Memory

**Responsibility:** store and retrieve source-bound traces.  
**Failure modes:** irrelevant retrieval, stale state, privacy retention, index drift.  
**Metrics:** recall, precision, counterfactual utility, latency, distraction cost, deletion verification.

## C10 — Persistent Memory

**Responsibility:** encode long-lived learned structure.  
**Variants:** slow weights, adapters, durable stores.  
**Rule:** persistent state changes require training or governed adaptation evidence.

## C11 — Structural Plasticity Controller

**Responsibility:** propose topology deltas.  
**Inputs:** edge utility, demand, robustness and budget.  
**Outputs:** reversible proposal.  
**Failure modes:** catastrophic disconnection, cyclic churn, topology overfit.  
**Metrics:** retained capability, adaptation speed, delta size, rollback success.

## C12 — Metacognitive Budget Governor

**Responsibility:** allocate compute, memory and route budget.  
**Inputs:** uncertainty, expected value, risk, remaining budget.  
**Outputs:** bounded `ActivationBudget`.  
**Failure modes:** always-maximal compute, premature stopping, reward hacking.  
**Metrics:** budget calibration, value-of-compute curve, regret against oracle budget.

## C13 — Telemetry Plane

**Responsibility:** capture per-pass resource and route data without modifying model semantics.  
**Rule:** missing telemetry invalidates resource claims.

## C14 — Evidence Spine

**Responsibility:** bind run identity to source, environment, data, topology and metrics.  
**Failure modes:** mutable artifacts, untracked data, missing hashes.  
**Acceptance:** schema pass and complete hash manifest.

## C15 — Claim Firewall

**Responsibility:** block unsupported statements.  
**Inputs:** claim candidate and evidence bundles.  
**Outputs:** pass/fail with explicit reasons.  
**Rule:** no manual override without a recorded statute exception, which itself invalidates scientific release status.
