# Implementation Notes

## Reference versus optimized execution

The sparse attention mask is executed through a standard PyTorch attention operator. It validates graph semantics and telemetry but may not reduce wall-clock cost because the backend can still use dense kernels. Any speed or energy claim requires a hardware-aware sparse kernel and measured comparison.

## Energy language

`active_expert_fraction`, attention density and wiring cost are proxies. They SHALL NOT be relabeled as joules. Measured energy requires declared hardware, sampling method, idle subtraction, warm-up, repetitions and uncertainty.

## Memory isolation

The episodic memory is session state and excluded from the model state dictionary. Persistent deployment must add authenticated storage, retention enforcement and deletion verification.

## Scaling rule

Do not scale parameter count before tests identify which component causes a gain. Scaling without causal isolation creates evidence debt.
