# Threat Model

## Scientific threats

- benchmark cherry-picking;
- post-hoc thresholds;
- unmatched compute;
- seed selection;
- leakage and contamination;
- proxy–measurement substitution;
- hidden topology or prompt drift;
- underpowered generalization claims.

## Architectural threats

- router collapse;
- expert starvation;
- expert redundancy;
- memory poisoning;
- state leakage;
- topology disconnection;
- runaway adaptation;
- budget bypass;
- telemetry omission.

## Software and supply-chain threats

- dependency confusion;
- arbitrary-code model loading;
- compromised CI;
- artifact substitution;
- secret leakage;
- unsigned or unverifiable release provenance.

## Adversarial controls

- corrupted route indices must fail closed;
- over-budget requests must be rejected;
- malformed topology must not execute;
- memory writes require declared permission;
- evidence hash mismatch invalidates a bundle;
- L3/L4 claims require independent reproduction state;
- production actions remain disabled in the reference kernel.
