# ⊛ Claims Ledger

**Identifier:** `CWC-CLAIMS-001`
**Author and Principal Architect:** Ярослав Василенко
**Evidence source:** `docs/claim_source_matrix.json` (`CWC-BIB-USCN-001`, 35 primary sources)
**Gate:** `make bibliography-verify` / `python scripts/check_claim_source_matrix.py`

This ledger binds every architecture claim in CHARTER.md and ARCHITECTURE.md to exactly one
`CWC-CLM-*` row in the evidence bibliography. No row here may assert a status stronger than the
`status` field recorded in `docs/claim_source_matrix.json`. Adding an architecture component
without a corresponding row, or citing a claim id that the bibliography gate does not know about,
is a release blocker.

| Claim | Status | Architecture component | Statement |
|---|---|---|---|
| `CWC-CLM-001` | SUPPORTED_COMPONENT | Adaptive Cognitive Fabric (CHARTER §6.1) | Local clustering plus sparse long-range/global links is a valid topology family for reducing connection density while preserving short information paths. |
| `CWC-CLM-002` | SUPPORTED_COMPONENT | Expert Ecology (CHARTER §6.4) | Conditional expert routing can increase model capacity while keeping per-token active computation sparse. |
| `CWC-CLM-003` | SUPPORTED_COMPONENT | Sparse Local/Global Communication (ARCHITECTURE §3, §5) | Sparse and hierarchical attention can reduce long-sequence compute/memory relative to full attention. |
| `CWC-CLM-004` | SUPPORTED_COMPONENT | Metacognitive Budget Governor (CHARTER §6.7) | Inference effort can be allocated dynamically by token, layer, mode or reasoning budget. |
| `CWC-CLM-005` | SUPPORTED_COMPONENT | Memory Stratigraphy (CHARTER §6.5) | Working, external and neural long-term memory mechanisms can be separated and updated through distinct control policies. |
| `CWC-CLM-006` | SUPPORTED_COMPONENT | Structural Plasticity Cycle (CHARTER §6.6) | Persistent network connectivity can be changed through grow, prune and regrow operations during training. |
| `CWC-CLM-007` | SUPPORTED_COMPONENT | World Coupling Port (CHARTER §6.8) | Language representations can be coupled with vision, audio, continuous state and action outputs in shared or coordinated latent spaces. |
| `CWC-CLM-008` | METHODOLOGICAL_REQUIREMENT | Evidence Spine (CHARTER §6.9), Article 4 cost normalization | Efficiency claims require workload-defined, hardware-normalized measurements of latency, throughput, memory and cost — not proxy FLOPs alone. Reified by `src/cwk/instrumentation/` (`FlopLedger`, `RoutingTrace`, `VRAMMeter`, `EnergySampler`, `RunMeter`): analytical FLOP/byte accounting plus roofline and MoE-capacity reports, with `overhead_report()` enforcing that measurement itself stays under a declared overhead budget (`max_overhead_fraction`) so instrumentation cannot be the thing that invalidates the latency it measures. See `tests/test_instrumentation.py`. |
| `CWC-CLM-009` | PRIOR_ART_GAP_HYPOTHESIS | Claim Firewall / NOVELTY_MATRIX.md | No source in the curated corpus jointly controls active module routing, hierarchical memory access, adaptive depth and persistent topology under one resource budget. This is the candidate novelty and remains a hypothesis, not a fact, until Article 7 falsification obligations are cleared. |
| `CWC-CLM-010` | OPEN_RESEARCH_PROBLEM | Structural Plasticity Cycle boundary (ADR-0004), CWC-SPEC-001 §10 | Safe online structural adaptation requires utility estimation, stability criteria, bounded operators and rollback — unresolved for in-episode (as opposed to between-episode) rewiring. |

## Unsourced design choices (ADR-0007)

Per the maintenance rule above, these rows are explicitly NOT bibliography-sourced claims. They
operationalize the previously-empty `Q_transfer`/`Q_adapt`/`Q_robust`/`Q_agency` slots in
CWC-SPEC-001 §12.1, motivated by Sutskever's public generalization thesis and Amodei's public
Responsible Scaling Policy / interpretability statements (2024-2026) — neither is a peer-reviewed
primary source, and neither appears in `docs/claim_source_matrix.json`.

**Reified, not just declared:** `schemas/value_function.schema.json` + `src/cwk/value_function.py`
(`evaluate_capability_threshold_gate`) + `scripts/check_value_function_report.py` +
`make value-function-verify` turn these five rows into a fail-closed, machine-checkable gate —
a report cannot mark its own `gate_decision` as `PASS` while its measured `q_robust`/`q_agency`
fields fail the Capability-Threshold Gate condition (CHARTER Article 5, invariant 11). See
`tests/test_value_function_gate.py` for both the compliant case and four independent rejection
cases.

| Row | Status | Component | Statement |
|---|---|---|---|
| `CWC-UDC-001` | UNSOURCED_DESIGN_CHOICE | Q_transfer (ADR-0007) | `perf(D_ood) - perf(D_id)` under identical `B_t`, preregistered OOD split disjoint from training/validation. |
| `CWC-UDC-002` | UNSOURCED_DESIGN_CHOICE | Q_adapt (ADR-0007) | Rate/stability of in-episode structural adaptation under Structural Plasticity Cycle, reported jointly with structural churn. |
| `CWC-UDC-003` | UNSOURCED_DESIGN_CHOICE | Q_robust (ADR-0007) | Behavioral robustness: routing/memory/action decisions stay within the declared safety envelope under distribution shift, independent of `Q_task`. |
| `CWC-UDC-004` | UNSOURCED_DESIGN_CHOICE | Q_agency (ADR-0007) | Action-node decisions above a preregistered autonomy threshold require an inspectable verifier trace, not outcome scoring alone. |
| `CWC-UDC-005` | UNSOURCED_DESIGN_CHOICE | Capability-Threshold Gate (CHARTER Article 5, invariant 11) | New plasticity operators or routing configurations above a preregistered threshold are gated by `Q_robust`/`Q_agency` measurement as a precondition, not a post-hoc penalty. |
| `CWC-UDC-006` | UNSOURCED_DESIGN_CHOICE | CWC-lite protocol (ROADMAP Phase 1, CHARTER Article 5 invariant 6) | Structural plasticity is deliberately deferred: the frozen `experiments/cwc_lite_pareto_v1.yaml` scopes the first confirmatory bakeoff to routing + token-level depth + KV-memory policy + hard budget (`topology_plasticity_enabled: false`), so a Pareto result is attributable to those four mechanisms before plasticity adds a fifth interacting variable. |

**Rationale for `CWC-UDC-006`**, from two non-bibliography-tier signals: (1) `karpathy/nanochat`'s own `moe3` branch (`dev/LOG.md`, 2026-02-19, "Mixture of Experts (negative)") — a DeepSeekV3-style router improved per-step validation loss but was a net wall-clock regression (MFU 46%→35%) from dispatch overhead at GPT-2 scale, confirmed by reading that branch directly, not by citation; (2) an external research survey the user supplied whose ~80 citation markers are unresolved placeholders and are explicitly NOT promoted to bibliography-tier evidence here — only its structural recommendation (fixed-topology adaptive-compute before topology self-rewrite) is used, as a design rationale, not a fact.

`scripts/check_cwc_lite_protocol.py` / `make cwc-lite-verify` enforces this as a fail-closed gate: `topology_plasticity_enabled: true`, a missing compute-equivalent baseline, a soft-penalty budget substitution, or a claim rule missing "non-worse"/"95"/"strictly better"/"hypervolume" are all rejected. See `tests/test_cwc_lite_protocol.py`.

## Boundary

This ledger is a routing table from architecture text to evidence, not a substitute for the
bibliography itself. Reading `CWC-CLM-009` and `CWC-CLM-010` as settled facts is a Claim Policy
violation (research/CLAIM_POLICY.md forbidden transformation: "benchmark improvement → general
intelligence" and its neighbors apply by the same logic to "hypothesis → fact").

## Maintenance rule

Any new architecture component introduced in CHARTER.md or ARCHITECTURE.md MUST either:

1. reference an existing `CWC-CLM-*` row above, or
2. be added to `docs/claim_source_matrix.json` with its own sourced claim, or
3. be explicitly marked `UNSOURCED_DESIGN_CHOICE` in this ledger — permitted, but never silently.

`make bibliography-verify` checks internal consistency of the matrix; it does not check that this
table stays in sync. That synchronization is manual and reviewed at each release gate (CHARTER
Article 8, CWC-SPEC-001 §21).
