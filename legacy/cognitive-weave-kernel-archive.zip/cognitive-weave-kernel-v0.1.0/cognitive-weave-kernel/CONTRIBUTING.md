# Contribution Protocol

1. Open an issue declaring whether the change is normative, architectural, experimental, operational or editorial.
2. For architecture changes, add an ADR before implementation.
3. Add tests that fail without the change.
4. Preserve deterministic seeds and baseline comparability.
5. Update schemas and migration notes when contracts change.
6. Never modify acceptance thresholds after observing benchmark outcomes.
7. Run `make verify` before submission.

A contribution may improve code while being rejected from the canonical architecture if it weakens observability, reversibility or falsifiability.
