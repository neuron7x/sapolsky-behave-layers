from __future__ import annotations

import argparse
from pathlib import Path

from cwk.validation import validate_claim_firewall


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("claim", type=Path)
    parser.add_argument("--evidence-root", type=Path, default=Path("evidence/runs"))
    parser.add_argument("--schema-root", type=Path, default=Path("schemas"))
    args = parser.parse_args()
    errors = validate_claim_firewall(args.claim, args.evidence_root, args.schema_root)
    if errors:
        print("\n".join(errors))
        raise SystemExit(1)
    print("CLAIM_FIREWALL_PASS")


if __name__ == "__main__":
    main()
