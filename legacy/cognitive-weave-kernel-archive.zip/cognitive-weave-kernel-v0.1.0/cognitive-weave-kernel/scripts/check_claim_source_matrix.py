#!/usr/bin/env python3
"""Fail-closed validator for the CWC bibliography and claim-source matrix."""
from __future__ import annotations

import json
import re
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
MATRIX = ROOT / "docs" / "claim_source_matrix.json"
BIB = ROOT / "docs" / "BIBLIOGRAPHY_US_CN.md"
ALLOWED_TIERS = {
    "A1_PEER_REVIEWED_PRIMARY",
    "A2_PRIMARY_BENCHMARK",
    "B1_PRIMARY_REPORT_CODE",
    "B1_PRIMARY_REPORT_WEIGHTS",
    "B2_PRIMARY_REPORT",
    "S1_PRIMARY_STANDARD",
}
ALLOWED_STATUS = {
    "SUPPORTED_COMPONENT",
    "METHODOLOGICAL_REQUIREMENT",
    "PRIOR_ART_GAP_HYPOTHESIS",
    "OPEN_RESEARCH_PROBLEM",
}
ID_RE = re.compile(r"^(US|CN)-[A-Z]+-\d{3}$")
CLAIM_RE = re.compile(r"^CWC-CLM-\d{3}$")


def fail(msg: str) -> None:
    raise SystemExit(f"bibliography-gate: FAIL: {msg}")


def main() -> None:
    if not MATRIX.is_file() or not BIB.is_file():
        fail("required files are missing")
    data = json.loads(MATRIX.read_text(encoding="utf-8"))
    sources = data.get("sources")
    claims = data.get("claims")
    if not isinstance(sources, list) or not sources:
        fail("sources must be a non-empty list")
    if not isinstance(claims, list) or not claims:
        fail("claims must be a non-empty list")
    if data.get("source_count") != len(sources):
        fail("source_count drift")
    if data.get("claim_count") != len(claims):
        fail("claim_count drift")

    source_ids: set[str] = set()
    for source in sources:
        sid = source.get("id")
        if not isinstance(sid, str) or not ID_RE.match(sid):
            fail(f"invalid source id: {sid!r}")
        if sid in source_ids:
            fail(f"duplicate source id: {sid}")
        source_ids.add(sid)
        if source.get("evidence_tier") not in ALLOWED_TIERS:
            fail(f"invalid evidence tier for {sid}")
        url = source.get("primary_url")
        if not isinstance(url, str) or urlparse(url).scheme != "https":
            fail(f"non-HTTPS or missing primary_url for {sid}")
        for field in ("citation", "fact", "cwc_use", "boundary"):
            if not isinstance(source.get(field), str) or len(source[field].strip()) < 12:
                fail(f"missing/weak {field} for {sid}")
        institution = source.get("institution")
        if not isinstance(institution, str) or len(institution.strip()) < 3:
            fail(f"missing/weak institution for {sid}")
        if sid not in BIB.read_text(encoding="utf-8"):
            fail(f"source {sid} absent from bibliography")

    claim_ids: set[str] = set()
    for claim in claims:
        cid = claim.get("id")
        if not isinstance(cid, str) or not CLAIM_RE.match(cid):
            fail(f"invalid claim id: {cid!r}")
        if cid in claim_ids:
            fail(f"duplicate claim id: {cid}")
        claim_ids.add(cid)
        if claim.get("status") not in ALLOWED_STATUS:
            fail(f"invalid status for {cid}")
        refs = claim.get("source_ids")
        if not isinstance(refs, list) or not refs:
            fail(f"claim {cid} has no sources")
        unknown = sorted(set(refs) - source_ids)
        if unknown:
            fail(f"claim {cid} references unknown sources: {unknown}")
        if not claim.get("boundary") or not claim.get("required_local_evidence"):
            fail(f"claim {cid} lacks boundary or local-evidence requirements")

    # Bidirectional closure: every source claim reference must exist and every
    # matrix claim must be mentioned by at least one source.
    source_claim_refs = {
        cid for source in sources for cid in source.get("claims", [])
    }
    if source_claim_refs != claim_ids:
        fail(
            f"claim closure drift: source_refs={sorted(source_claim_refs)} "
            f"matrix={sorted(claim_ids)}"
        )

    print(f"bibliography-gate: OK ({len(sources)} primary sources, {len(claims)} claims)")


if __name__ == "__main__":
    main()
