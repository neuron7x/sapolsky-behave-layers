from __future__ import annotations

import argparse
from pathlib import Path

from cwk.value_function import evaluate_capability_threshold_gate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("report", type=Path)
    parser.add_argument("--schema-root", type=Path, default=Path("schemas"))
    args = parser.parse_args()
    errors = evaluate_capability_threshold_gate(args.report, args.schema_root)
    if errors:
        print("\n".join(errors))
        raise SystemExit(1)
    print("CAPABILITY_THRESHOLD_GATE_PASS")


if __name__ == "__main__":
    main()
