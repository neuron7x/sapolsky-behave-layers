from __future__ import annotations

import json
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    required = [
        "CHARTER.md",
        "ARCHITECTURE.md",
        "research/FALSIFICATION_PROTOCOL.md",
        "research/SOURCE_REGISTER.yaml",
        "schemas/experiment.schema.json",
        "schemas/evidence.schema.json",
        "schemas/claim.schema.json",
        "schemas/cwc_lite_protocol.schema.json",
        "src/cwk/controller.py",
        "src/cwk/core.py",
        "src/cwk/cwc_lite.py",
        "src/cwk/instrumentation/meters.py",
        "src/cwk/instrumentation/trace.py",
        "tests/test_core.py",
        "tests/test_cwc_lite_architecture.py",
        "tests/test_instrumentation.py",
    ]
    missing = [path for path in required if not (ROOT / path).exists()]
    if missing:
        raise SystemExit(f"missing required files: {missing}")

    for schema_path in (ROOT / "schemas").glob("*.schema.json"):
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)

    charter = (ROOT / "CHARTER.md").read_text(encoding="utf-8")
    for phrase in (
        "Activation Budget Contract",
        "Evidence Spine",
        "Claim Firewall",
        "Negative-result retention",
    ):
        if phrase not in charter:
            raise SystemExit(f"charter invariant missing: {phrase}")
    print("REPOSITORY_VALIDATION_PASS")


if __name__ == "__main__":
    main()
