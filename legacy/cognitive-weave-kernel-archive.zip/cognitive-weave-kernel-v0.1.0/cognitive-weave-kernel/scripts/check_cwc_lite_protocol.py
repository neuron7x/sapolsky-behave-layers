from __future__ import annotations

import argparse
from pathlib import Path

from cwk.cwc_lite_protocol import validate_cwc_lite_protocol


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "protocol",
        type=Path,
        default=Path("experiments/cwc_lite_pareto_v1.yaml"),
        nargs="?",
    )
    parser.add_argument("--schema-root", type=Path, default=Path("schemas"))
    args = parser.parse_args()
    errors = validate_cwc_lite_protocol(args.protocol, args.schema_root)
    if errors:
        print("\n".join(errors))
        raise SystemExit(1)
    print("CWC_LITE_PROTOCOL_PASS")


if __name__ == "__main__":
    main()
