from __future__ import annotations

import json
import platform
import subprocess
from pathlib import Path

import torch


def main() -> None:
    record = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "pip_freeze": subprocess.check_output(
            ["python", "-m", "pip", "freeze"], text=True
        ).splitlines(),
    }
    Path("environment.lock.json").write_text(
        json.dumps(record, indent=2, sort_keys=True), encoding="utf-8"
    )
    print("environment.lock.json")


if __name__ == "__main__":
    main()
