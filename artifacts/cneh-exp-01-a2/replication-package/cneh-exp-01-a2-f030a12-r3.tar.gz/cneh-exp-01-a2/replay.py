#!/usr/bin/env python3
"""Execute existing CNEH engineering checks; never execute a blind cohort."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time

PACKAGE = Path(__file__).resolve().parent
COMMIT = "f030a12b145bd8b43876c9e2d8b268e820e92b87"
sys.dont_write_bytecode = True


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()


def strict_json(data):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError("duplicate JSON key")
            value[key] = item
        return value
    def reject(value):
        raise ValueError("nonfinite JSON constant: " + value)
    value = json.loads(data, object_pairs_hook=pairs, parse_constant=reject)
    canonical(value)
    return value


def selected(path):
    return (path.startswith("experiments/cneh_exp_01/") or path.startswith("cwc/causal/")
            or path == "cwc/__init__.py" or path.startswith("tests/test_cneh_exp_01")
            or path.startswith("tests/cneh_math/") or path in ("LICENSE", "SYSTEM.md", ".github/workflows/cneh-exp-01.yml",
            "docs/methodology/CWC_MASTER_METHODOLOGY.md"))


def verify_package(trusted_git=None):
    files = {}
    for path in PACKAGE.rglob("*"):
        if path.is_symlink():
            raise ValueError("package symlink forbidden")
        if path.is_file() and path.name != "SHA256SUMS":
            files[path.relative_to(PACKAGE).as_posix()] = digest(path.read_bytes())
        elif path.is_file() and path.parent != PACKAGE:
            files[path.relative_to(PACKAGE).as_posix()] = digest(path.read_bytes())
    manifest = {}
    for line in (PACKAGE / "SHA256SUMS").read_text(encoding="ascii").splitlines():
        sha, name = line.split("  ")
        if (name in manifest or Path(name).is_absolute() or ".." in Path(name).parts
                or len(sha) != 64 or any(c not in "0123456789abcdef" for c in sha)):
            raise ValueError("invalid package checksum entry")
        manifest[name] = sha
    if manifest != files:
        raise ValueError("package hash or file-membership mismatch")
    metadata = strict_json((PACKAGE / "SOURCE_MANIFEST.json").read_bytes())
    if metadata["canonical_commit"] != COMMIT:
        raise ValueError("unexpected canonical source commit")
    status = "HASH_INTEGRITY_ONLY_NOT_AUTHENTICATED"
    if trusted_git is not None:
        paths = subprocess.check_output(["git", "-C", str(trusted_git), "ls-tree", "-r", "--name-only", COMMIT], text=True).splitlines()
        expected = {p for p in paths if selected(p)}
        if expected != set(metadata["canonical_source_files_sha256"]):
            raise ValueError("canonical source roster mismatch")
        for path in sorted(expected):
            raw = subprocess.check_output(["git", "-C", str(trusted_git), "cat-file", "blob", COMMIT + ":" + path])
            if (PACKAGE / "source" / path).read_bytes() != raw:
                raise ValueError("canonical Git source mismatch: " + path)
        status = "CANONICAL_GIT_SOURCE_VERIFIED_AGAINST_CALLER_TRUSTED_CHECKOUT"
    source = PACKAGE / "source/experiments/cneh_exp_01"
    math_contract = strict_json((source / "math_qualification_contract.json").read_bytes())
    if digest((PACKAGE / "external/pr44-linear-reference.py").read_bytes()) != math_contract["pr44"]["sha256"]:
        raise ValueError("pinned PR44 source mismatch")
    bn_contract = strict_json((source / "bnsyn_integration_contract.json").read_bytes())
    bn = PACKAGE / "external/bnsyn"
    bn_paths = [bn / "LICENSE", bn / "pyproject.toml"] + [p for p in (bn / "src").rglob("*") if p.is_file()]
    bn_manifest = {p.relative_to(bn).as_posix(): digest(p.read_bytes()) for p in sorted(bn_paths)}
    if len(bn_manifest) != 118 or digest(canonical(bn_manifest)) != bn_contract["source"]["files_sha256"]:
        raise ValueError("pinned BN-Syn 118-file source mismatch")
    return metadata, status


def execute(command, cwd, env, out, name, records, expected=0):
    started = time.perf_counter()
    process = subprocess.Popen(command, cwd=cwd, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True, start_new_session=True)
    timeout = False
    try:
        stdout, stderr = process.communicate(timeout=120)
    except subprocess.TimeoutExpired:
        timeout = True
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            # The child may exit between timeout observation and group cleanup.
            pass
        stdout, stderr = process.communicate()
    for stream, text in (("stdout", stdout), ("stderr", stderr)):
        (out / f"{name}.{stream}.log").write_text(text, encoding="utf-8")
    record = {"name": name, "command": command, "cwd": str(cwd), "exit_code": process.returncode,
              "expected_exit": expected, "timed_out": timeout,
              "seconds": time.perf_counter() - started,
              "stdout_sha256": digest(stdout.encode()), "stderr_sha256": digest(stderr.encode())}
    records.append(record)
    if timeout or process.returncode != expected:
        raise RuntimeError(f"{name}: expected exit {expected}, observed {process.returncode}, timeout={timeout}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--trusted-git", type=Path)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--full", action="store_true", help="also run the existing 11+7 mutation gates")
    args = parser.parse_args()
    os.umask(0o022)
    metadata, authentication = verify_package(args.trusted_git)
    if args.verify_only:
        print(json.dumps({"package_integrity": "PASS", "source_authentication": authentication,
                          "canonical_commit": COMMIT, "scientific_promotion_authorized": False}))
        return 0
    if args.out is None:
        parser.error("--out is required for execution")
    out = args.out.resolve()
    if out.is_relative_to(PACKAGE):
        raise ValueError("write replay outputs outside the immutable package")
    out.mkdir(parents=True, exist_ok=False)
    source = out / "work-source"
    shutil.copytree(PACKAGE / "source", source)
    source_before = {p.relative_to(source).as_posix(): digest(p.read_bytes())
                     for p in source.rglob("*") if p.is_file()}
    if source_before != metadata["canonical_source_files_sha256"]:
        raise ValueError("runtime source copy differs from canonical package")
    scripts = source / "experiments/cneh_exp_01"
    reference = PACKAGE / "external/pr44-linear-reference.py"
    bn = PACKAGE / "external/bnsyn"
    python = str(Path(args.python).absolute()) if "/" in args.python else args.python
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", CNEH_PR44_REFERENCE=str(reference))
    env.pop("PYTHONPATH", None)
    records = []
    report = {"schema": "cneh-engineering-package-replay-v1", "status": "RUNNING",
              "canonical_commit": COMMIT, "source_authentication": authentication,
              "dependency_installation": "EXTERNAL_EXISTING_RUNTIME; no environment bundled or installed by replay",
              "independent_blind_replication": "REPLICATION_NOT_TESTED", "external_seed_commitment": "ABSENT",
              "external_execution_protocol": "BLOCKED_NOT_IMPLEMENTED", "scientific_promotion_authorized": False,
              "mode": "FULL" if args.full else "CORE", "commands": records,
              "execution_source": "BYTE_IDENTICAL_COPY_OUTSIDE_IMMUTABLE_PACKAGE",
              "source_copy_before_sha256": source_before}
    def run(name, script, *options, expected=0):
        execute([python, str(scripts / script), *map(str, options)], source, env, out, name, records, expected)
    try:
        runtime = "import sys,json,importlib.metadata as m; assert sys.version_info[:2]==(3,12); expected={'numpy':'2.4.1','scipy':'1.17.1','pydantic':'2.12.5'}; actual={k:m.version(k) for k in expected}; assert actual==expected,(actual,expected); print(json.dumps({'python':sys.version,'executable':sys.executable,'dependencies':actual}))"
        execute([python, "-c", runtime], source, env, out, "runtime", records)
        minimum = metadata["minimum_tests"]["stdlib"]
        unit = "import json,unittest; s=unittest.defaultTestLoader.discover('tests',pattern='test_cneh_exp_01*.py'); r=unittest.TextTestRunner(verbosity=2).run(s); print(json.dumps({'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skips':len(r.skipped)})); raise SystemExit(0 if r.wasSuccessful() and r.testsRun>=" + str(minimum) + " and not r.skipped and not r.expectedFailures and not r.unexpectedSuccesses else 1)"
        execute([python, "-c", unit], source, env, out, "stdlib-tests", records)
        run("a1-primary-verify", "run.py", "--out", PACKAGE / "raw-a1/primary", "--verify")
        run("primary-generate", "run.py", "--phase", "primary", "--out", out / "primary")
        run("primary-verify", "run.py", "--out", out / "primary", "--verify")
        if (out / "primary/primary.csv").read_bytes() != (PACKAGE / "raw-a1/primary/primary.csv").read_bytes():
            raise ValueError("PRIMARY differs from retained A1 raw rows")
        numerical = "import unittest; s=unittest.defaultTestLoader.discover('tests/cneh_math',pattern='qualification_cases.py'); r=unittest.TextTestRunner(verbosity=2).run(s); raise SystemExit(0 if r.wasSuccessful() and r.testsRun>=14 and not r.skipped and not r.expectedFailures and not r.unexpectedSuccesses else 1)"
        execute([python, "-c", numerical], source, env, out, "math-tests", records)
        run("math-generate", "math_qualification.py", "--reference", reference, "--out", out / "math.json")
        run("math-verify", "math_qualification.py", "--reference", reference, "--out", out / "math.json", "--verify")
        math_report = strict_json((out / "math.json").read_bytes())
        if len(math_report["checks"]) != 45 or not all(c["pass"] for c in math_report["checks"].values()):
            raise ValueError("missing or failing frozen numerical qualification checks")
        run("bnsyn-generate", "bnsyn_adapter.py", "--source", bn, "--out", out / "bnsyn")
        run("bnsyn-verify", "bnsyn_adapter.py", "--source", bn, "--out", out / "bnsyn", "--verify")
        # Host/platform/package metadata belongs to the original run; compare the
        # saved scientific-neutral trajectories, not pretend that host identities match.
        fresh = gzip.decompress((out / "bnsyn/traces.json.gz").read_bytes())
        a1 = gzip.decompress((PACKAGE / "raw-a1/bnsyn/traces.json.gz").read_bytes())
        if fresh != a1:
            raise ValueError("exact A1 neural trajectory replay differs; no portability claim")
        run("science-lock", "qualification.py", "--bundle", out / "primary", "--require-scientific-readiness", expected=2)
        run("metrology-generate", "metrology.py", "--out", out / "metrology")
        run("metrology-verify", "metrology.py", "--out", out / "metrology", "--verify")
        run("metrology-cost-lock", "metrology.py", "--out", out / "metrology", "--verify", "--require-qualified-cost", expected=2)
        if args.full:
            run("stdlib-mutations", "mutation_check.py", "--out", out / "stdlib-mutations")
            run("math-mutations", "math_mutation_check.py", "--reference", reference, "--out", out / "math-mutations")
        if args.full:
            for directory, required in (("stdlib-mutations", 11), ("math-mutations", 7)):
                mutation = strict_json((out / directory / "report.json").read_bytes())
                if (mutation["status"] != "PASS" or mutation["killed"] != required
                        or mutation["total"] != required or not mutation["source_unchanged_during_run"]):
                    raise ValueError("frozen mutation gate incomplete: " + directory)
        source_after = {}
        for path in source.rglob("*"):
            if path.is_symlink():
                raise ValueError("runtime source symlink forbidden")
            if path.is_file():
                source_after[path.relative_to(source).as_posix()] = digest(path.read_bytes())
        report["source_copy_after_sha256"] = {p: source_after.get(p) for p in source_before}
        if report["source_copy_after_sha256"] != source_before:
            raise ValueError("runtime source bytes changed")
        added = set(source_after) - set(source_before)
        allowed_caches = {
            "experiments/cneh_exp_01/__pycache__/run.cpython-312.pyc",
            "experiments/cneh_exp_01/__pycache__/hardware.cpython-312.pyc",
        }
        if not added <= allowed_caches:
            raise ValueError("unexpected runtime source additions: " + repr(sorted(added)))
        # Only these observed CPython 3.12 cache paths can be adjudicated. Recompile
        # the canonical bytes with the exact requested interpreter and filename;
        # compare the complete .pyc bytes, including its invalidation header.
        oracle = """import hashlib,importlib.util,json,pathlib,py_compile,sys,tempfile
root=pathlib.Path(sys.argv[1]); names=json.loads(sys.argv[2]); evidence=[]
with tempfile.TemporaryDirectory(prefix='cneh-cache-oracle-') as directory:
 for index,name in enumerate(names):
  cache=root/name; source=pathlib.Path(importlib.util.source_from_cache(str(cache)))
  expected=pathlib.Path(directory)/str(index)
  py_compile.compile(str(source),cfile=str(expected),dfile=str(source),doraise=True,invalidation_mode=py_compile.PycInvalidationMode.TIMESTAMP)
  actual_bytes=cache.read_bytes(); expected_bytes=expected.read_bytes()
  if actual_bytes!=expected_bytes: raise ValueError('cache does not reproduce from canonical source: '+name)
  evidence.append({'path':name,'sha256':hashlib.sha256(actual_bytes).hexdigest(),'expected_sha256':hashlib.sha256(expected_bytes).hexdigest(),'status':'EXACT_INTERPRETER_COMPILE_MATCH'})
print(json.dumps(evidence,sort_keys=True))
"""
        execute([python, "-I", "-B", "-c", oracle, str(source), json.dumps(sorted(added))],
                source, env, out, "runtime-cache-validation", records)
        report["runtime_cache_adjudication"] = strict_json((out / "runtime-cache-validation.stdout.log").read_bytes())
        report["runtime_source_unchanged"] = True
        metadata_after, authentication_after = verify_package(args.trusted_git)
        if metadata_after != metadata or authentication_after != authentication:
            raise ValueError("package changed during execution")
        report.update(status="PASS", retained_A1_primary_rows="EXACT_REPLAY", retained_A1_neural_traces="EXACT_REPLAY",
                      numerical_checks=45, frozen_mutation_gates="11+7_EXECUTED" if args.full else "NOT_RUN_CORE_MODE")
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        report.update(status="FAIL", error=str(error))
    (out / "replay-report.json").write_bytes(canonical(report))
    files = sorted(p for p in out.rglob("*") if p.is_file())
    (out / "SHA256SUMS").write_text("".join(f"{digest(p.read_bytes())}  {p.relative_to(out).as_posix()}\n" for p in files), encoding="ascii")
    print(json.dumps({"status": report["status"], "commands": len(records), "independent_blind_replication": "REPLICATION_NOT_TESTED", "scientific_promotion_authorized": False}))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
