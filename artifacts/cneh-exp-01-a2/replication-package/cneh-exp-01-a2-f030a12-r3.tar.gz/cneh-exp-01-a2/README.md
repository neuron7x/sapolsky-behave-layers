# CNEH-EXP-01 A2: автономний пакет інженерного replay

Джерело: `neuron7x/sapolsky-behave-layers`, commit `f030a12b145bd8b43876c9e2d8b268e820e92b87`.
Пакет містить точний `git archive` потрібної поверхні разом із canonical `SYSTEM.md`, pinned PR44 reference,
118 файлів BN-Syn, hash-locked залежності та незмінені внутрішні raw-виходи A1.
Секретних seeds, venv, credentials, скомпільованих бібліотек немає.

`SHA256SUMS` перевіряє цілісність, не автентичність. Для довіри звірте SHA256 архіву
через незалежний канал, перевірте `replay.py`, отримайте canonical Git commit із
довіреного джерела і передайте `--trusted-git`. Без цього replay явно пише
`HASH_INTEGRITY_ONLY_NOT_AUTHENTICATED`. Пакувальні файли не видаються за файли commit.

## Відтворення

Python 3.12, Linux. Вхідні файли незмінні; venv та результати створюються ПОЗА пакетом.
Канонічні файли копіюються в `--out/work-source`; кожен SHA перевіряється до і після.
Допустимі лише два фактично спостережені CPython 3.12 cache-файли `run` і `hardware`: їхні
повні байти мають збігтися з незалежним повторним compile точних source тим самим interpreter.
Інші додані файли, змінений source або cache з іншими байтами дають FAIL.
Архів має mode 0644, uid/gid 0, mtime 0; розпакування й виміри виконуються під umask 022.
Пакет не завантажує залежності та не встановлює їх автоматично.

```sh
python3.12 -m venv /tmp/cneh-replay-venv
/tmp/cneh-replay-venv/bin/python -m pip install --require-hashes --only-binary=:all: \
  -r source/experiments/cneh_exp_01/bnsyn-requirements.lock
python3.12 replay.py --verify-only --trusted-git /path/to/trusted/canonical-checkout
python3.12 replay.py --python /tmp/cneh-replay-venv/bin/python \
  --trusted-git /path/to/trusted/canonical-checkout \
  --out /tmp/cneh-replay-output --full
```

Наявний ізольований runtime з точними locked версіями також допустимий; його шлях,
Python і версії записуються. `--full` виконує обидва frozen каталоги: 11 stdlib та
7 numerical mutants. Без `--full` вони чесно позначаються `NOT_RUN_CORE_MODE`.
Core виконує 74 тести, PRIMARY replay, 14 numerical cases, 45 числових перевірок,
BN-Syn generation/replay, фактичний metrology generation/verify, очікуваний exit 2
для невалідного cost instrument та перевірку заборони наукового підвищення.
Metrology записує сирі ресурсні вектори цього запуску; вони не видаються за тотожні A1.

A1 `raw-a1/` походить із локальної інженерної перевірки commit
`12f3575d9adbc21755c70ec454440ae8b06ba0d4`, не від зовнішнього blinded оператора.
PRIMARY рядки та нейронні траси зіставляються точно. Історичні host/runtime поля
BN-звіту збережені, але не підміняються ідентичністю нової машини. Відмінність
binary64 replay означає FAIL; міжплатформова відтворюваність наперед не заявляється.

Успішний запуск створює `replay-report.json`, окремі stdout/stderr, коди виходу,
нові результати та власний `SHA256SUMS`. Результат — інженерний replay на цій машині.
`REPLICATION_NOT_TESTED`, `COST_INSTRUMENT_INVALID`, scientific promotion `false`
залишаються чинними. Цей пакет не виконує нову blind cohort.
