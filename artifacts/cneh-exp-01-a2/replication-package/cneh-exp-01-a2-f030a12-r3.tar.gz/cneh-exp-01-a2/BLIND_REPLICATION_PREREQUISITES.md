# Зовнішня blind replication: BLOCKED

Немає authenticated окремого оператора, зовнішнього seed commitment, chronology
attestation або виконаного blinded cohort. Їх не створює replay цього пакета.
Публічні PRIMARY/SMOKE seeds не можна перейменувати в blind replication.

Наявний `replication.py` готує commitment/reveal, запечатує bytes результату та
перевіряє hash consistency. Він НЕ запускає експеримент. `run.py` підтримує лише
SMOKE і frozen PRIMARY; виконуваного preregistered external-cohort/arm-blinding
протоколу тут немає. Це BLOCKED prerequisite, не прихована готовність.

Перед зовнішнім дослідом потрібні: незалежно засвідчений оператор і послідовність
публікацій; окремо переглянутий frozen execution protocol та відповідний executor;
визначена blind arm mapping; перевірена ресурсна паритетність; погоджений scope.
Протокол `CNEH-EXP-01` не може отримати перевагу над unrestricted faithful emulator.
Новий restricted-comparator claim потребує окремої preregistered lineage.

Нижче — лише операторські команди на вже наданих ним приватних даних. Ні seeds,
ні operator identity не заповнені цим пакетом. Не запускати execution-підстановки,
доки наведені prerequisites не закриті.

```sh
# Оператор сам створює приватний JSON список відповідно до frozen count/exclusions.
python3.12 source/experiments/cneh_exp_01/replication.py prepare \
  --seeds /operator-private/approved-seeds.json \
  --operator-id "$AUTHENTICATED_OPERATOR_ID" \
  --code-sha f030a12b145bd8b43876c9e2d8b268e820e92b87 \
  --out /operator-private/sealed-cohort

# Після окремо авторизованого зовнішнього виконання; його executor тут відсутній.
python3.12 source/experiments/cneh_exp_01/replication.py seal \
  --commitment /operator-private/sealed-cohort/commitment.json \
  --outputs /external-execution/raw-output \
  --out /operator-private/output-seal.json

# Hash consistency ніколи не підтверджує operator identity або chronology.
python3.12 source/experiments/cneh_exp_01/replication.py verify \
  --commitment /operator-private/sealed-cohort/commitment.json \
  --reveal /operator-private/sealed-cohort/private/reveal.json \
  --output-seal /operator-private/output-seal.json \
  --outputs /external-execution/raw-output \
  --require-independent
```

Остання команда має exit `2`: зовнішня незалежність не автентифікована. Публікувати
можна лише дозволений оператором commitment/outputs/reveal у затвердженому порядку;
пакет нічого нікому не надсилає. Приватний reveal не входить у цей архів.
